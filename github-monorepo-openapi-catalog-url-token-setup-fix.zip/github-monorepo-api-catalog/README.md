# GitHub Monorepo API Catalog

A local React, TypeScript, Vite, Flask, and Python API catalog that discovers OpenAPI documents from one GitHub monorepo.

## Discovery behavior

The backend scans the repository tree recursively and includes files whose names match, case-insensitively:

- `openapi.json`
- `openapi.yml`
- `openapi.yaml`

The files may appear at any directory depth. Every containing folder becomes a catalog group. The OpenAPI document supplies the API title, description, version, endpoints, request fields, examples, servers, tags, authentication schemes, and optional catalog metadata.

When GitHub reports that a recursive tree response is truncated, the provider walks every subtree explicitly so deeply nested specification files are still discovered.

## Supported OpenAPI metadata

Standard fields are read from `info`, `paths`, `components`, and related OpenAPI structures. These optional extensions improve catalog metadata:

```yaml
info:
  title: Payments API
  version: 2.0.0
  description: Payment processing operations
  x-owner-team: Payments Platform
  x-lifecycle: production
  x-domain: Payments
  x-support-channel: "#payments-api-support"
```

The parser supports OpenAPI JSON and YAML, including OpenAPI 2/Swagger-style body parameters. Local JSON Pointer references such as `#/components/schemas/Payment` are resolved. External relative `$ref` files are not bundled in this version.

## GitHub repository configuration

Only two required values are needed:

```env
GITHUB_REPOSITORY_URL=https://github.com/organization/platform-monorepo
GITHUB_ACCESS_TOKEN=your-token
```

Use the repository root URL, not a branch, folder, or file URL. The application accepts standard HTTPS clone URLs ending in `.git` and SSH clone URLs as well.

For `github.com`, the backend automatically uses `https://api.github.com`. For a GitHub Enterprise URL such as `https://github.example.com/organization/platform-monorepo`, it automatically uses `https://github.example.com/api/v3`.

The token must have read-only access to repository contents. It is stored only in the root `.env`, excluded by `.gitignore`, added to backend GitHub requests as a Bearer token, and never sent to the browser.

Optional settings remain available:

```env
GITHUB_SEARCH_ROOT=
GITHUB_OPENAPI_FILENAMES=openapi.json,openapi.yml,openapi.yaml
CATALOG_CACHE_TTL_SECONDS=900
```

## First-time Windows setup

Run:

```bat
setup.bat
```

Setup now asks only for the GitHub repository URL and access token. It parses the owner, repository, GitHub host, API endpoint, and default branch automatically. It then installs dependencies, verifies token-authenticated repository access, and runs the frontend production build.

The repository URL is entered normally, while the token prompt is hidden so the token is not echoed to the terminal.

Then start the local application:

```bat
start-dev.bat
```

The frontend remains at `http://127.0.0.1:5173`, and Flask remains at `http://127.0.0.1:8080`.

## API routes

- `GET /api/health`
- `GET /api/source-health`
- `GET /api/catalog`
- `GET /api/catalog?refresh=true`
- `GET /api/specs/{catalogId}`
- `GET /api/workspaces` — compatibility route returning repository folders

## Source layout

```text
backend/
  app.py
  catalog.py
  config.py
  github_client.py
frontend/
  src/
setup.bat
setup.ps1
start-dev.bat
start-dev.ps1
```

The frontend still consumes the same normalized catalog contract, so search, endpoint previews, operation navigation, nested request fields, theming, and the detailed API view do not depend on GitHub-specific response shapes.

## Versioned API names

Once an OpenAPI definition is loaded, the application extracts the first numeric segment from `info.version` and appends it as an uppercase major version, such as `Payments API V2`. If the title already contains `V2` or `Version 2`, it is not appended again.

## Token use and verification

When `GITHUB_ACCESS_TOKEN` is configured, the backend adds it to outbound GitHub API requests as an `Authorization: Bearer ...` header. The token is stored only in the root `.env`, which is ignored by Git, and is never returned to the browser. A token is required by this build so startup and refreshes always use authenticated access.

`start-dev.bat` verifies both the local Flask health endpoint and GitHub repository access before starting Vite. It reports whether access is token-authenticated or anonymous without revealing the token.

Run this at any time to re-check backend imports, GitHub access, retained UI features, TypeScript, and the Vite production build:

```bat
verify.bat
```

## Windows setup quoting fix

Setup and verification now call `backend/verify_installation.py` directly instead of passing Python programs through `python -c`. This prevents Windows PowerShell from stripping embedded quotes and also prevents the secondary null-value error when URL validation fails.
