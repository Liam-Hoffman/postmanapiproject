from __future__ import annotations

import base64
import email.utils
import hashlib
import json
import re
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import PurePosixPath
from typing import Any

import config


class GitHubAPIError(RuntimeError):
    def __init__(self, status: int | None, message: str, url: str = ""):
        self.status = status
        self.url = url
        super().__init__(message)


@dataclass(frozen=True)
class GitHubRepositoryLocation:
    owner: str
    repo: str
    web_url: str
    api_url: str

    @property
    def repository_url(self) -> str:
        return f"{self.web_url}/{self.owner}/{self.repo}"


def parse_repository_url(value: str) -> GitHubRepositoryLocation:
    """Parse a GitHub.com or GitHub Enterprise repository URL.

    Accepted examples:
      https://github.com/acme/platform-monorepo
      https://github.com/acme/platform-monorepo.git
      https://github.example.com/acme/platform-monorepo
      git@github.com:acme/platform-monorepo.git
      ssh://git@github.example.com/acme/platform-monorepo.git
    """
    raw = value.strip()
    if not raw:
        raise ValueError("GITHUB_REPOSITORY_URL must be configured in .env.")

    host = ""
    path = ""
    web_scheme = "https"

    scp_match = re.fullmatch(
        r"git@(?P<host>[^:]+):(?P<path>[^?#]+)",
        raw,
        flags=re.IGNORECASE,
    )
    if scp_match:
        host = scp_match.group("host")
        path = scp_match.group("path")
    else:
        parsed = urllib.parse.urlsplit(raw)
        if parsed.scheme.casefold() not in {"http", "https", "ssh", "git"}:
            raise ValueError(
                "GITHUB_REPOSITORY_URL must be an HTTPS, SSH, or Git repository URL."
            )
        if not parsed.hostname:
            raise ValueError("GITHUB_REPOSITORY_URL does not contain a valid host.")
        if parsed.query or parsed.fragment:
            raise ValueError(
                "Use the repository root URL without query parameters or fragments."
            )
        host = parsed.hostname
        path = parsed.path
        if parsed.scheme.casefold() in {"http", "https"}:
            web_scheme = parsed.scheme.casefold()

    segments = [
        urllib.parse.unquote(segment)
        for segment in path.strip("/").split("/")
        if segment
    ]
    if len(segments) != 2:
        raise ValueError(
            "Use the repository root URL, for example "
            "https://github.com/organization/repository. "
            "Branch, file, and folder URLs are not supported."
        )

    owner, repo = segments
    if repo.casefold().endswith(".git"):
        repo = repo[:-4]
    owner = owner.strip()
    repo = repo.strip()
    if not owner or not repo:
        raise ValueError("The repository URL must include both owner and repository name.")

    normalized_host = host.casefold()
    web_url = f"{web_scheme}://{host}".rstrip("/")
    api_url = (
        "https://api.github.com"
        if normalized_host in {"github.com", "www.github.com"}
        else f"{web_url}/api/v3"
    )
    if normalized_host == "www.github.com":
        web_url = "https://github.com"

    return GitHubRepositoryLocation(
        owner=owner,
        repo=repo,
        web_url=web_url,
        api_url=api_url,
    )


@dataclass(frozen=True)
class Workspace:
    """Compatibility model used by the existing frontend as a catalog group."""

    id: str
    name: str
    type: str = "folder"


class GitHubMonorepoClient:
    def __init__(
        self,
        repository_url: str,
        token: str,
    ):
        location = parse_repository_url(repository_url)
        self.owner = location.owner
        self.repo = location.repo
        self.web_url = location.web_url
        self.api_url = location.api_url
        self.repository_url = location.repository_url
        self.token = token.strip()
        self._repository_cache: dict[str, Any] | None = None

        if not self.token:
            raise ValueError(
                "GITHUB_ACCESS_TOKEN must be configured in .env. "
                "Use a token with read-only access to repository contents."
            )

    @property
    def repository_name(self) -> str:
        return f"{self.owner}/{self.repo}"

    def _headers(self, accept: str = "application/vnd.github+json") -> dict[str, str]:
        headers = {
            "Accept": accept,
            "User-Agent": "github-monorepo-api-catalog/1.0",
        }
        if config.GITHUB_API_VERSION:
            headers["X-GitHub-Api-Version"] = config.GITHUB_API_VERSION
        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"
        return headers

    @staticmethod
    def _retry_after(headers: Any, attempt: int) -> float:
        value = headers.get("Retry-After") if headers else None
        if value:
            try:
                return max(0.0, float(value))
            except ValueError:
                try:
                    target = email.utils.parsedate_to_datetime(value)
                    return max(0.0, target.timestamp() - time.time())
                except (TypeError, ValueError):
                    pass

        reset = headers.get("X-RateLimit-Reset") if headers else None
        if reset:
            try:
                return max(0.0, float(reset) - time.time())
            except ValueError:
                pass

        return min(30.0, float(2 ** attempt))

    def _request(
        self,
        path: str,
        *,
        accept: str = "application/vnd.github+json",
    ) -> bytes:
        url = f"{self.api_url}{path}"
        request = urllib.request.Request(
            url,
            headers=self._headers(accept),
            method="GET",
        )

        for attempt in range(config.GITHUB_MAX_RETRIES + 1):
            print(f"[GitHub] GET {url}", flush=True)
            try:
                with urllib.request.urlopen(
                    request,
                    timeout=config.GITHUB_REQUEST_TIMEOUT_SECONDS,
                ) as response:
                    return response.read()
            except urllib.error.HTTPError as exc:
                body = exc.read().decode("utf-8", errors="replace")
                retryable = exc.code in {429, 500, 502, 503, 504}
                if exc.code == 403:
                    remaining = exc.headers.get("X-RateLimit-Remaining")
                    retryable = remaining == "0"

                if retryable and attempt < config.GITHUB_MAX_RETRIES:
                    wait = (
                        self._retry_after(exc.headers, attempt)
                        + config.GITHUB_RETRY_BUFFER_SECONDS
                    )
                    print(
                        f"[GitHub] HTTP {exc.code}; retrying in {wait:.1f}s",
                        flush=True,
                    )
                    time.sleep(wait)
                    continue

                try:
                    payload = json.loads(body)
                    detail = payload.get("message") or body
                except json.JSONDecodeError:
                    detail = body or str(exc.reason)

                if exc.code == 404 and not self.token:
                    detail += (
                        " The repository may be private; configure GITHUB_TOKEN "
                        "with read access to repository contents."
                    )
                raise GitHubAPIError(
                    exc.code,
                    f"GitHub returned HTTP {exc.code}: {detail}",
                    url,
                ) from exc
            except urllib.error.URLError as exc:
                if attempt < config.GITHUB_MAX_RETRIES:
                    wait = min(10.0, float(2 ** attempt))
                    time.sleep(wait)
                    continue
                raise GitHubAPIError(
                    None,
                    f"Unable to reach GitHub: {exc.reason}",
                    url,
                ) from exc

        raise GitHubAPIError(None, "GitHub request retries were exhausted.", url)

    def _get_json(self, path: str) -> Any:
        raw = self._request(path)
        try:
            return json.loads(raw.decode("utf-8"))
        except json.JSONDecodeError as exc:
            raise GitHubAPIError(
                None,
                "GitHub returned an invalid JSON response.",
                f"{self.api_url}{path}",
            ) from exc

    def get_repository(self, force: bool = False) -> dict[str, Any]:
        if self._repository_cache is not None and not force:
            return dict(self._repository_cache)

        owner = urllib.parse.quote(self.owner, safe="")
        repo = urllib.parse.quote(self.repo, safe="")
        payload = self._get_json(f"/repos/{owner}/{repo}")
        if not isinstance(payload, dict):
            raise GitHubAPIError(None, "Unexpected GitHub repository response.")
        self._repository_cache = payload
        return dict(payload)

    def get_ref(self, repository: dict[str, Any] | None = None) -> str:
        repository = repository or self.get_repository()
        ref = str(repository.get("default_branch") or "").strip()
        if not ref:
            raise GitHubAPIError(
                None,
                f"GitHub did not return a default branch for {self.repository_name}.",
            )
        return ref

    def _tree(self, tree_sha_or_ref: str, recursive: bool) -> dict[str, Any]:
        owner = urllib.parse.quote(self.owner, safe="")
        repo = urllib.parse.quote(self.repo, safe="")
        tree_value = urllib.parse.quote(tree_sha_or_ref, safe="")
        suffix = "?recursive=1" if recursive else ""
        payload = self._get_json(
            f"/repos/{owner}/{repo}/git/trees/{tree_value}{suffix}"
        )
        if not isinstance(payload, dict):
            raise GitHubAPIError(None, "Unexpected GitHub tree response.")
        return payload

    @staticmethod
    def _matching_blob(entry: dict[str, Any], prefix: str = "") -> dict[str, Any] | None:
        path = str(entry.get("path") or "").strip("/")
        if prefix:
            path = f"{prefix}/{path}" if path else prefix
        if entry.get("type") != "blob" or not path:
            return None

        if PurePosixPath(path).name.casefold() not in config.GITHUB_OPENAPI_FILENAMES:
            return None
        if config.GITHUB_SEARCH_ROOT:
            root = config.GITHUB_SEARCH_ROOT.rstrip("/")
            if path != root and not path.startswith(root + "/"):
                return None

        return {
            "path": path,
            "sha": str(entry.get("sha") or ""),
            "size": entry.get("size"),
        }

    def _walk_tree(self, root_ref: str) -> list[dict[str, Any]]:
        """Traverse each subtree when GitHub marks a recursive tree as truncated."""
        matches: list[dict[str, Any]] = []
        stack: list[tuple[str, str]] = [("", root_ref)]
        visited: set[tuple[str, str]] = set()

        while stack:
            prefix, tree_sha = stack.pop()
            visit_key = (prefix, tree_sha)
            if visit_key in visited:
                continue
            visited.add(visit_key)

            payload = self._tree(tree_sha, recursive=False)
            entries = payload.get("tree") or []
            if not isinstance(entries, list):
                continue

            for entry in entries:
                if not isinstance(entry, dict):
                    continue
                entry_path = str(entry.get("path") or "").strip("/")
                full_path = (
                    f"{prefix}/{entry_path}" if prefix and entry_path else
                    prefix or entry_path
                )

                if entry.get("type") == "tree" and entry.get("sha"):
                    # If a search root is configured, skip unrelated top-level trees.
                    if config.GITHUB_SEARCH_ROOT:
                        root = config.GITHUB_SEARCH_ROOT.rstrip("/")
                        related = (
                            full_path == root
                            or root.startswith(full_path + "/")
                            or full_path.startswith(root + "/")
                        )
                        if not related:
                            continue
                    stack.append((full_path, str(entry["sha"])))
                    continue

                match = self._matching_blob(entry, prefix)
                if match:
                    matches.append(match)

        return matches

    def discover_openapi_specs(
        self,
        force: bool = False,
    ) -> tuple[dict[str, Any], str, list[tuple[Workspace, dict[str, Any]]]]:
        repository = self.get_repository(force=force)
        ref = self.get_ref(repository)

        recursive_tree = self._tree(ref, recursive=True)
        entries = recursive_tree.get("tree") or []
        truncated = bool(recursive_tree.get("truncated"))

        if truncated:
            print(
                "[GitHub] Recursive tree response was truncated; "
                "walking subtrees explicitly.",
                flush=True,
            )
            blobs = self._walk_tree(ref)
        else:
            blobs = []
            if isinstance(entries, list):
                for entry in entries:
                    if not isinstance(entry, dict):
                        continue
                    match = self._matching_blob(entry)
                    if match:
                        blobs.append(match)

        unique_blobs = {
            item["path"]: item
            for item in blobs
            if item.get("path") and item.get("sha")
        }

        discovered: list[tuple[Workspace, dict[str, Any]]] = []
        for path in sorted(unique_blobs, key=str.casefold):
            blob = unique_blobs[path]
            parent = str(PurePosixPath(path).parent)
            if parent == ".":
                parent = ""
            group_name = parent or f"{self.repo} root"
            group_id = hashlib.sha256(
                f"{self.repository_name}:{parent}".encode("utf-8")
            ).hexdigest()[:20]
            spec_id = hashlib.sha256(
                f"{self.repository_name}@{ref}:{path}".encode("utf-8")
            ).hexdigest()[:24]
            suffix = PurePosixPath(path).suffix.casefold().lstrip(".")
            source_url = (
                f"{self.repository_url}/blob/"
                f"{urllib.parse.quote(ref, safe='/')}/"
                f"{urllib.parse.quote(path, safe='/')}"
            )

            workspace = Workspace(
                id=group_id,
                name=group_name,
                type="github-folder",
            )
            spec = {
                "id": spec_id,
                "name": PurePosixPath(path).parent.name or self.repo,
                "description": f"OpenAPI specification discovered at {path}",
                "version": "",
                "type": "openapi",
                "fileFormat": suffix,
                "createdAt": repository.get("created_at"),
                "updatedAt": repository.get("pushed_at") or repository.get("updated_at"),
                "repository": self.repository_name,
                "sourcePath": path,
                "sourceUrl": source_url,
                "sourceRef": ref,
                "sourceSha": blob["sha"],
                "sourceSize": blob.get("size"),
            }
            discovered.append((workspace, spec))

        return repository, ref, discovered

    def get_spec_definition(self, spec: dict[str, Any]) -> str:
        sha = str(spec.get("sourceSha") or "").strip()
        if not sha:
            raise GitHubAPIError(
                None,
                f"Specification {spec.get('sourcePath') or spec.get('id')} has no blob SHA.",
            )

        owner = urllib.parse.quote(self.owner, safe="")
        repo = urllib.parse.quote(self.repo, safe="")
        blob_sha = urllib.parse.quote(sha, safe="")
        payload = self._get_json(
            f"/repos/{owner}/{repo}/git/blobs/{blob_sha}"
        )
        if not isinstance(payload, dict):
            raise GitHubAPIError(None, "Unexpected GitHub blob response.")

        content = payload.get("content")
        encoding = payload.get("encoding")
        if not isinstance(content, str):
            raise GitHubAPIError(
                None,
                f"GitHub returned no content for {spec.get('sourcePath')}.",
            )
        if encoding != "base64":
            raise GitHubAPIError(
                None,
                f"Unsupported GitHub blob encoding: {encoding or 'unknown'}.",
            )

        try:
            raw = base64.b64decode(content, validate=False)
            return raw.decode("utf-8-sig")
        except (ValueError, UnicodeDecodeError) as exc:
            raise GitHubAPIError(
                None,
                f"Unable to decode {spec.get('sourcePath')} as UTF-8.",
            ) from exc

    def health(self) -> dict[str, Any]:
        repository = self.get_repository()
        ref = self.get_ref(repository)
        return {
            "status": "ok",
            "provider": "github",
            "repository": self.repository_name,
            "repositoryUrl": self.repository_url,
            "ref": ref,
            "private": bool(repository.get("private")),
            "authenticated": bool(self.token),
        }
