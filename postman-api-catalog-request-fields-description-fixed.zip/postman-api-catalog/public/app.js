const state={apis:[],search:"",workspace:"",lifecycle:"",sort:"name",currentDetail:null};
const $=selector=>document.querySelector(selector);
const catalog=$("#catalog"),status=$("#status"),summary=$("#summary");
const text=value=>String(value??"");
const searchable=api=>[
  api.name,api.description,api.owner,api.lifecycle,api.workspace.name,
  ...(api.tags||[]),...(api.servers||[]),
  ...(api.operations||[]).flatMap(op=>[op.method,op.path,op.summary,op.operationId,...(op.tags||[])])
].join(" ").toLowerCase();

function stat(label,value){return `<div class="stat"><strong>${text(value)}</strong><span>${label}</span></div>`}
function formatDate(value){
  if(!value)return "Unknown";
  const date=new Date(value);
  return Number.isNaN(date.getTime())?value:new Intl.DateTimeFormat(undefined,{dateStyle:"medium"}).format(date);
}
function populateSelect(select,values){
  const first=select.firstElementChild;
  select.replaceChildren(first);
  [...new Set(values.filter(Boolean))].sort((a,b)=>a.localeCompare(b)).forEach(value=>{
    const option=document.createElement("option");
    option.value=value; option.textContent=value; select.append(option);
  });
}
function render(){
  const query=state.search.trim().toLowerCase();
  let items=state.apis.filter(api=>
    (!query||searchable(api).includes(query))&&
    (!state.workspace||api.workspace.id===state.workspace)&&
    (!state.lifecycle||api.lifecycle===state.lifecycle)
  );
  items.sort((a,b)=>{
    if(state.sort==="updated")return String(b.updatedAt||"").localeCompare(String(a.updatedAt||""));
    if(state.sort==="operations")return (b.operationCount??-1)-(a.operationCount??-1);
    return a.name.localeCompare(b.name);
  });
  catalog.replaceChildren();
  const template=$("#cardTemplate");
  items.forEach(api=>{
    const fragment=template.content.cloneNode(true);
    fragment.querySelector(".workspace-name").textContent=api.workspace.name;
    fragment.querySelector(".api-name").textContent=api.name;
    const cardDescription=api.catalogDescription??api.description;
    fragment.querySelector(".description").textContent=htmlToPlainText(cardDescription)||"Open this API to view its full definition.";
    fragment.querySelector(".lifecycle").textContent=api.detailsLoaded?api.lifecycle:"On demand";
    fragment.querySelector(".meta").textContent=[
      api.version?`v${api.version}`:"Version in definition",
      api.operationCount==null?"Operations load on open":`${api.operationCount} operations`,
      api.owner||"Owner loads on open",
      `Updated ${formatDate(api.updatedAt)}`
    ].join(" · ");
    const tags=fragment.querySelector(".tags");
    if(api.detailsLoaded){
      (api.tags||[]).slice(0,6).forEach(tag=>{
        const el=document.createElement("span");
        el.className="tag"; el.textContent=tag; tags.append(el);
      });
    }
    const button=fragment.querySelector(".view-button");
    button.textContent="View API Details";
    button.addEventListener("click",event=>{event.stopPropagation();showDetail(api,button)});
    const card=fragment.querySelector(".card");
    card.tabIndex=0;
    card.setAttribute("role","button");
    card.addEventListener("click",()=>showDetail(api,button));
    card.addEventListener("keydown",event=>{
      if(event.key==="Enter"||event.key===" "){event.preventDefault();showDetail(api,button)}
    });
    catalog.append(fragment);
  });
  status.textContent=`Showing ${items.length} of ${state.apis.length} APIs`;
}
function showDetailTab(tab){
  const specMode=tab==="spec";
  const overviewTab=$("#overviewTab");
  const specTab=$("#specTab");
  $("#detailBody").hidden=specMode;
  $("#specBody").hidden=!specMode;
  overviewTab.classList.toggle("active",!specMode);
  specTab.classList.toggle("active",specMode);
  overviewTab.setAttribute("aria-selected",String(!specMode));
  specTab.setAttribute("aria-selected",String(specMode));
  $(".dialog-content").scrollTop=0;
}
function htmlToPlainText(value){
  if(!value)return "";
  const normalized=String(value)
    .replace(/<br\s*\/?>/gi,"\n")
    .replace(/<\/p>/gi,"\n\n")
    .replace(/<\/li>/gi,"\n")
    .replace(/<li[^>]*>/gi,"• ");
  const parser=new DOMParser();
  const decoded=parser.parseFromString(normalized,"text/html").documentElement.textContent||"";
  return decoded.replace(/\n{3,}/g,"\n\n").trim();
}
function appendFormattedText(parent,value,className=""){
  const valueText=htmlToPlainText(value);
  if(!valueText)return;
  const block=document.createElement("div");block.className=className;
  valueText.split(/\n{2,}/).filter(Boolean).forEach(part=>{
    const p=document.createElement("p");p.textContent=part.trim();block.append(p);
  });
  parent.append(block);
}
function formatExample(value){return typeof value==="string"?value:JSON.stringify(value,null,2)}
function renderDetail(api){
  state.currentDetail=api;
  $("#specBody code").textContent=api.definitionText||"Specification content unavailable.";
  showDetailTab("overview");
  $("#detailWorkspace").textContent=api.workspace.name;
  $("#detailTitle").textContent=api.name;
  const body=$("#detailBody");body.replaceChildren();
  const summary=document.createElement("div");summary.className="detail-summary";
  [["Version",api.version||"Unspecified"],["Owner",api.owner||"Unspecified"],["Operations",api.operationCount??0],["Updated",formatDate(api.updatedAt)]].forEach(([label,value])=>{
    const item=document.createElement("div");item.className="detail-summary-item";
    const strong=document.createElement("strong");strong.textContent=label;
    const span=document.createElement("span");span.textContent=String(value);
    item.append(strong,span);summary.append(item);
  });body.append(summary);
  if(api.description){
    const section=document.createElement("section");section.className="detail-section";
    const h=document.createElement("h3");h.textContent="Description";section.append(h);
    appendFormattedText(section,api.description,"formatted-description");body.append(section);
  }
  if(!api.definitionParsed){const n=document.createElement("p");n.className="notice";n.textContent="The definition was returned as YAML or text. The full specification is still available in the Specification tab, but structured operation parsing requires JSON.";body.append(n)}
  if(api.servers?.length){
    const section=document.createElement("section");section.className="detail-section";
    const h=document.createElement("h3");h.textContent="Servers";
    const list=document.createElement("div");list.className="server-list";
    api.servers.forEach((server,index)=>{const row=document.createElement("div");row.className="server-item";const badge=document.createElement("span");badge.className="server-index";badge.textContent=String(index+1);const code=document.createElement("code");code.textContent=server;row.append(badge,code);list.append(row)});
    section.append(h,list);body.append(section);
  }
  const section=document.createElement("section");section.className="detail-section";
  const h=document.createElement("h3");h.textContent="Operations";section.append(h);
  if(!api.operations?.length){const p=document.createElement("p");p.textContent="No parsed operations were found.";section.append(p)}
  (api.operations||[]).forEach(op=>{
    const card=document.createElement("article");card.className="operation-card";
    const header=document.createElement("div");header.className="operation-header";
    const method=document.createElement("span");method.className="method";method.textContent=op.method;
    const path=document.createElement("code");path.className="operation-path";path.textContent=op.path;header.append(method,path);card.append(header);
    const title=document.createElement("div");title.className="operation-summary";title.textContent=op.summary||op.operationId||"No summary";card.append(title);
    if(op.description)appendFormattedText(card,op.description,"operation-description");
    if(op.requestFields?.length){
      const fieldsWrap=document.createElement("div");
      fieldsWrap.className="request-fields";
      const fieldsTitle=document.createElement("strong");
      fieldsTitle.textContent="Request fields";
      fieldsWrap.append(fieldsTitle);

      const tableWrap=document.createElement("div");
      tableWrap.className="request-fields-table-wrap";
      const table=document.createElement("table");
      table.className="request-fields-table";

      const thead=document.createElement("thead");
      const headerRow=document.createElement("tr");
      ["Field","In","Type","Required"].forEach(label=>{
        const th=document.createElement("th");
        th.textContent=label;
        headerRow.append(th);
      });
      thead.append(headerRow);

      const tbody=document.createElement("tbody");
      op.requestFields.forEach(field=>{
        const row=document.createElement("tr");

        const fieldCell=document.createElement("td");
        const fieldCode=document.createElement("code");
        fieldCode.textContent=field.path||field.name;
        fieldCell.append(fieldCode);
        if(field.description){
          const desc=document.createElement("div");
          desc.className="request-field-description";
          desc.textContent=htmlToPlainText(field.description);
          fieldCell.append(desc);
        }

        const locationCell=document.createElement("td");
        locationCell.textContent=field.location||"body";

        const typeCell=document.createElement("td");
        const typeCode=document.createElement("code");
        typeCode.textContent=field.type||"unknown";
        typeCell.append(typeCode);

        const requiredCell=document.createElement("td");
        const badge=document.createElement("span");
        badge.className=field.required?"field-required":"field-optional";
        badge.textContent=field.required?"Required":"Optional";
        requiredCell.append(badge);

        row.append(fieldCell,locationCell,typeCell,requiredCell);
        tbody.append(row);
      });

      table.append(thead,tbody);
      tableWrap.append(table);
      fieldsWrap.append(tableWrap);
      card.append(fieldsWrap);
    }

    if(op.requestBodyExample){
      const wrap=document.createElement("div");wrap.className="request-example";
      const exHeader=document.createElement("div");exHeader.className="request-example-header";
      const label=document.createElement("strong");label.textContent="Example request body";
      const type=document.createElement("span");type.textContent=op.requestBodyExample.contentType||"application/json";exHeader.append(label,type);
      const pre=document.createElement("pre");const code=document.createElement("code");code.textContent=formatExample(op.requestBodyExample.example);pre.append(code);wrap.append(exHeader,pre);card.append(wrap);
    } else {const p=document.createElement("p");p.className="no-request-body";p.textContent="No request body is defined for this operation.";card.append(p)}
    section.append(card);
  });body.append(section);
}
async function showDetail(api,button){
  $("#detailWorkspace").textContent=api.workspace.name;
  $("#detailTitle").textContent=api.name;
  showDetailTab("overview");
  $("#detailBody").innerHTML='<p class="notice">Loading this API definition from Postman…</p>';
  $("#detailDialog").showModal();

  if(api.detailsLoaded){
    renderDetail(api);
    return;
  }

  const previous=button.textContent;
  button.disabled=true;
  button.textContent="Loading…";
  try{
    const response=await fetch(`/api/specs/${encodeURIComponent(api.id)}`,{headers:{Accept:"application/json"}});
    const detail=await response.json();
    if(!response.ok)throw new Error(detail.details||detail.error||`HTTP ${response.status}`);
    if(api.catalogDescription===undefined)api.catalogDescription=api.description||"";
    Object.assign(api,detail,{detailsLoaded:true});
    renderDetail(api);
    render();
  }catch(error){
    $("#detailBody").innerHTML="";
    const notice=document.createElement("p");
    notice.className="notice";
    notice.textContent=`Unable to load this definition: ${error.message}`;
    $("#detailBody").append(notice);
  }finally{
    button.disabled=false;
    button.textContent=previous;
  }
}
async function load(refresh=false){
  $("#refreshButton").disabled=true;status.textContent="Loading workspace metadata…";
  try{
    const response=await fetch(`/api/catalog${refresh?"?refresh=true":""}`,{headers:{Accept:"application/json"}});
    const payload=await response.json();
    if(!response.ok)throw new Error(payload.details||payload.error||`HTTP ${response.status}`);
    state.apis=payload.apis||[];
    summary.textContent=`${payload.apiCount} APIs across ${payload.workspaceCount} accessible workspaces · loaded in ${payload.loadMilliseconds??0} ms`;
    $("#stats").innerHTML=[
      stat("APIs",payload.apiCount),
      stat("Workspaces",payload.workspaceCount),
      stat("Definitions loaded",0),
      stat("Workspace warnings",(payload.errors||[]).length)
    ].join("");
    populateSelect($("#workspaceFilter"),(payload.workspaces||[]).map(w=>w.id));
    [...$("#workspaceFilter").options].slice(1).forEach(option=>{
      const workspace=payload.workspaces.find(w=>w.id===option.value);if(workspace)option.textContent=workspace.name;
    });
    populateSelect($("#lifecycleFilter"),[]);
    render();
  }catch(error){status.textContent=`Unable to load catalog: ${error.message}`}
  finally{$("#refreshButton").disabled=false}
}
$("#searchInput").addEventListener("input",e=>{state.search=e.target.value;render()});
$("#workspaceFilter").addEventListener("change",e=>{state.workspace=e.target.value;render()});
$("#lifecycleFilter").addEventListener("change",e=>{state.lifecycle=e.target.value;render()});
$("#sortFilter").addEventListener("change",e=>{state.sort=e.target.value;render()});
$("#refreshButton").addEventListener("click",()=>load(true));
$("#closeDialog").addEventListener("click",()=>$("#detailDialog").close());
$("#themeButton").addEventListener("click",()=>{
  document.documentElement.classList.toggle("dark");
  localStorage.setItem("catalog-theme",document.documentElement.classList.contains("dark")?"dark":"light");
});
if(localStorage.getItem("catalog-theme")==="dark")document.documentElement.classList.add("dark");
load();

$("#overviewTab").addEventListener("click",()=>showDetailTab("overview"));
$("#specTab").addEventListener("click",()=>showDetailTab("spec"));
$("#copySpecButton").addEventListener("click",async()=>{
  const value=state.currentDetail?.definitionText||"";
  if(!value)return;
  try{
    await navigator.clipboard.writeText(value);
    $("#copySpecButton").textContent="Copied";
    setTimeout(()=>$("#copySpecButton").textContent="Copy spec",1200);
  }catch{
    $("#copySpecButton").textContent="Copy failed";
  }
});
