const state={apis:[],search:"",workspace:"",lifecycle:"",sort:"name"};
const $=selector=>document.querySelector(selector);
const catalog=$("#catalog"),status=$("#status"),summary=$("#summary");
const text=value=>String(value??"");
const searchable=api=>[
  api.name,api.description,api.owner,api.lifecycle,api.workspace.name,
  ...(api.tags||[]),...(api.servers||[]),
  ...(api.operations||[]).flatMap(op=>[op.method,op.path,op.summary,op.operationId,...(op.tags||[])])
].join(" ").toLowerCase();

function stat(label,value){return `<div class="stat"><strong>${text(value)}</strong><span>${label}</span></div>`}
function formatDate(value){
  if(!value)return "Unknown";
  const date=new Date(value);
  return Number.isNaN(date.getTime())?value:new Intl.DateTimeFormat(undefined,{dateStyle:"medium"}).format(date);
}
function populateSelect(select,values){
  const first=select.firstElementChild;
  select.replaceChildren(first);
  [...new Set(values.filter(Boolean))].sort((a,b)=>a.localeCompare(b)).forEach(value=>{
    const option=document.createElement("option");
    option.value=value; option.textContent=value; select.append(option);
  });
}
function render(){
  const query=state.search.trim().toLowerCase();
  let items=state.apis.filter(api=>
    (!query||searchable(api).includes(query))&&
    (!state.workspace||api.workspace.id===state.workspace)&&
    (!state.lifecycle||api.lifecycle===state.lifecycle)
  );
  items.sort((a,b)=>{
    if(state.sort==="updated")return String(b.updatedAt||"").localeCompare(String(a.updatedAt||""));
    if(state.sort==="operations")return b.operationCount-a.operationCount;
    return a.name.localeCompare(b.name);
  });
  catalog.replaceChildren();
  const template=$("#cardTemplate");
  items.forEach(api=>{
    const fragment=template.content.cloneNode(true);
    fragment.querySelector(".workspace-name").textContent=api.workspace.name;
    fragment.querySelector(".api-name").textContent=api.name;
    fragment.querySelector(".description").textContent=api.description||"No description provided.";
    fragment.querySelector(".lifecycle").textContent=api.lifecycle;
    fragment.querySelector(".meta").textContent=[
      api.version?`v${api.version}`:"Version unspecified",
      `${api.operationCount} operations`,
      api.owner||"Owner unspecified",
      `Updated ${formatDate(api.updatedAt)}`
    ].join(" · ");
    const tags=fragment.querySelector(".tags");
    (api.tags||[]).slice(0,6).forEach(tag=>{
      const el=document.createElement("span");
      el.className="tag"; el.textContent=tag; tags.append(el);
    });
    fragment.querySelector(".view-button").addEventListener("click",()=>showDetail(api));
    catalog.append(fragment);
  });
  status.textContent=`Showing ${items.length} of ${state.apis.length} APIs`;
}
function showDetail(api){
  $("#detailWorkspace").textContent=api.workspace.name;
  $("#detailTitle").textContent=api.name;
  const body=$("#detailBody");
  body.replaceChildren();
  const info=document.createElement("p");
  info.textContent=[
    api.version?`Version ${api.version}`:"Version unspecified",
    api.owner?`Owner: ${api.owner}`:"Owner unspecified",
    `${api.operationCount} operations`,
    `Updated ${formatDate(api.updatedAt)}`
  ].join(" · ");
  body.append(info);
  if(api.description){
    const p=document.createElement("p"); p.textContent=api.description; body.append(p);
  }
  if(!api.definitionParsed){
    const notice=document.createElement("p");
    notice.className="notice";
    notice.textContent="This definition was returned as YAML or unparsed text. The zero-dependency server intentionally does not include a YAML parser, so endpoint extraction is unavailable for this spec.";
    body.append(notice);
  }
  if(api.servers?.length){
    const p=document.createElement("p");
    p.textContent=`Servers: ${api.servers.join(", ")}`;
    body.append(p);
  }
  const heading=document.createElement("h3");
  heading.textContent="Operations"; body.append(heading);
  if(!api.operations.length){
    const p=document.createElement("p");
    p.textContent="No parsed operations were found."; body.append(p);
  }
  api.operations.forEach(op=>{
    const row=document.createElement("div"); row.className="operation";
    const method=document.createElement("span"); method.className="method"; method.textContent=op.method;
    const path=document.createElement("code"); path.textContent=op.path;
    const desc=document.createElement("span"); desc.textContent=op.summary||op.operationId||"No summary";
    row.append(method,path,desc); body.append(row);
  });
  $("#detailDialog").showModal();
}
async function load(refresh=false){
  $("#refreshButton").disabled=true;
  status.textContent="Loading catalog…";
  try{
    const response=await fetch(`/api/catalog${refresh?"?refresh=true":""}`,{headers:{Accept:"application/json"}});
    const payload=await response.json();
    if(!response.ok)throw new Error(payload.details||payload.error||`HTTP ${response.status}`);
    state.apis=payload.apis||[];
    summary.textContent=`${payload.apiCount} APIs across ${payload.workspaceCount} accessible workspaces`;
    $("#stats").innerHTML=[
      stat("APIs",payload.apiCount),
      stat("Workspaces",payload.workspaceCount),
      stat("Operations",state.apis.reduce((n,a)=>n+a.operationCount,0)),
      stat("Load warnings",(payload.errors||[]).length)
    ].join("");
    populateSelect($("#workspaceFilter"),(payload.workspaces||[]).map(w=>w.id));
    [...$("#workspaceFilter").options].slice(1).forEach(option=>{
      const workspace=payload.workspaces.find(w=>w.id===option.value);
      if(workspace)option.textContent=workspace.name;
    });
    populateSelect($("#lifecycleFilter"),state.apis.map(a=>a.lifecycle));
    render();
  }catch(error){
    status.textContent=`Unable to load catalog: ${error.message}`;
  }finally{
    $("#refreshButton").disabled=false;
  }
}
$("#searchInput").addEventListener("input",e=>{state.search=e.target.value;render()});
$("#workspaceFilter").addEventListener("change",e=>{state.workspace=e.target.value;render()});
$("#lifecycleFilter").addEventListener("change",e=>{state.lifecycle=e.target.value;render()});
$("#sortFilter").addEventListener("change",e=>{state.sort=e.target.value;render()});
$("#refreshButton").addEventListener("click",()=>load(true));
$("#closeDialog").addEventListener("click",()=>$("#detailDialog").close());
$("#themeButton").addEventListener("click",()=>{
  document.documentElement.classList.toggle("dark");
  localStorage.setItem("catalog-theme",document.documentElement.classList.contains("dark")?"dark":"light");
});
if(localStorage.getItem("catalog-theme")==="dark")document.documentElement.classList.add("dark");
load();
