from __future__ import annotations

import json
import threading
import time
from typing import Any

import config
from postman_client import PostmanAPIError, PostmanClient, Workspace

HTTP_METHODS = {
    "get", "post", "put", "patch", "delete", "head", "options", "trace"
}


def _parse_definition(payload: Any) -> tuple[dict[str, Any] | None, str]:
    value = payload
    if isinstance(payload, dict):
        for key in ("definition", "data", "content"):
            if key in payload:
                value = payload[key]
                break

    if isinstance(value, dict):
        return value, "json"

    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed, "json"
        except json.JSONDecodeError:
            return None, "yaml-or-text"

    return None, "unknown"


def _normalize_spec(
    spec: dict[str, Any],
    workspace: Workspace,
    definition_payload: Any,
) -> dict[str, Any]:
    definition, definition_format = _parse_definition(definition_payload)
    info = definition.get("info", {}) if definition else {}

    spec_id = str(spec.get("id") or spec.get("uid") or "")
    name = info.get("title") or spec.get("name") or "Unnamed API"
    description = info.get("description") or spec.get("description") or ""
    version = info.get("version") or ""

    operations: list[dict[str, Any]] = []
    tags: set[str] = set()
    servers: list[str] = []
    security_schemes: list[str] = []

    if definition:
        for server in definition.get("servers", []) or []:
            if isinstance(server, dict) and server.get("url"):
                servers.append(str(server["url"]))

        for tag in definition.get("tags", []) or []:
            if isinstance(tag, dict) and tag.get("name"):
                tags.add(str(tag["name"]))

        paths = definition.get("paths", {})
        if isinstance(paths, dict):
            for path, path_item in paths.items():
                if not isinstance(path_item, dict):
                    continue
                for method, operation in path_item.items():
                    if method.lower() not in HTTP_METHODS:
                        continue
                    operation = operation if isinstance(operation, dict) else {}
                    operation_tags = [
                        str(value) for value in operation.get("tags", []) or []
                    ]
                    tags.update(operation_tags)
                    responses = operation.get("responses", {})
                    operations.append(
                        {
                            "method": method.upper(),
                            "path": str(path),
                            "summary": operation.get("summary") or "",
                            "description": operation.get("description") or "",
                            "operationId": operation.get("operationId") or "",
                            "deprecated": bool(operation.get("deprecated", False)),
                            "tags": operation_tags,
                            "responseCodes": list(responses.keys())
                            if isinstance(responses, dict)
                            else [],
                        }
                    )

        components = definition.get("components", {})
        if isinstance(components, dict):
            schemes = components.get("securitySchemes", {})
            if isinstance(schemes, dict):
                security_schemes = list(schemes.keys())

    owner = (
        info.get("x-owner-team")
        or info.get("x-owner")
        or info.get("x-team")
        or ""
    )
    lifecycle = (
        info.get("x-lifecycle")
        or info.get("x-api-lifecycle")
        or "unspecified"
    )
    repository = (
        info.get("x-repository")
        or info.get("x-repository-url")
        or info.get("x-github")
        or ""
    )
    support = info.get("x-support-channel") or info.get("x-support") or ""

    return {
        "id": spec_id,
        "name": name,
        "description": description,
        "version": version,
        "type": spec.get("type") or "",
        "fileFormat": spec.get("fileFormat") or definition_format,
        "createdAt": spec.get("createdAt"),
        "updatedAt": spec.get("updatedAt"),
        "workspace": {
            "id": workspace.id,
            "name": workspace.name,
            "type": workspace.type,
        },
        "owner": owner,
        "lifecycle": lifecycle,
        "repository": repository,
        "support": support,
        "tags": sorted(tags, key=str.lower),
        "servers": servers,
        "securitySchemes": security_schemes,
        "operationCount": len(operations),
        "operations": operations,
        "definitionParsed": definition is not None,
        "definitionFormat": definition_format,
    }


class CatalogService:
    def __init__(self, client: PostmanClient):
        self.client = client
        self._lock = threading.Lock()
        self._cached: dict[str, Any] | None = None
        self._cached_at = 0.0

    def get_catalog(self, force: bool = False) -> dict[str, Any]:
        now = time.time()
        if (
            not force
            and self._cached is not None
            and now - self._cached_at < config.CACHE_TTL_SECONDS
        ):
            result = dict(self._cached)
            result["cache"] = {"hit": True, "ageSeconds": int(now - self._cached_at)}
            return result

        with self._lock:
            now = time.time()
            if (
                not force
                and self._cached is not None
                and now - self._cached_at < config.CACHE_TTL_SECONDS
            ):
                result = dict(self._cached)
                result["cache"] = {"hit": True, "ageSeconds": int(now - self._cached_at)}
                return result

            catalog = self._build_catalog()
            self._cached = catalog
            self._cached_at = time.time()
            result = dict(catalog)
            result["cache"] = {"hit": False, "ageSeconds": 0}
            return result

    def _build_catalog(self) -> dict[str, Any]:
        workspaces = self.client.get_workspaces()
        apis: list[dict[str, Any]] = []
        errors: list[dict[str, Any]] = []

        for workspace in workspaces:
            try:
                specs = self.client.get_specs_for_workspace(workspace.id)
            except PostmanAPIError as exc:
                errors.append(
                    {
                        "workspaceId": workspace.id,
                        "workspaceName": workspace.name,
                        "stage": "list-specs",
                        "error": str(exc),
                    }
                )
                continue

            for spec in specs:
                spec_id = str(spec.get("id") or spec.get("uid") or "")
                if not spec_id:
                    continue
                try:
                    definition = self.client.get_spec_definition(spec_id)
                    apis.append(_normalize_spec(spec, workspace, definition))
                except PostmanAPIError as exc:
                    fallback = _normalize_spec(spec, workspace, {})
                    fallback["definitionError"] = str(exc)
                    apis.append(fallback)
                    errors.append(
                        {
                            "workspaceId": workspace.id,
                            "workspaceName": workspace.name,
                            "specId": spec_id,
                            "stage": "get-definition",
                            "error": str(exc),
                        }
                    )

        apis.sort(
            key=lambda item: (
                item["name"].lower(),
                item["workspace"]["name"].lower(),
            )
        )

        return {
            "generatedAt": int(time.time()),
            "workspaceCount": len(workspaces),
            "apiCount": len(apis),
            "workspaces": [
                {"id": ws.id, "name": ws.name, "type": ws.type}
                for ws in workspaces
            ],
            "apis": apis,
            "errors": errors,
        }
