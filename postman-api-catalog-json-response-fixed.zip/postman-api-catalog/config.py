import os

POSTMAN_BASE_URL = os.environ.get("POSTMAN_BASE_URL", "https://api.postman.com").rstrip("/")
POSTMAN_API_KEY = os.environ.get("POSTMAN_API_KEY", "").strip()
HOST = os.environ.get("CATALOG_HOST", "127.0.0.1")
PORT = int(os.environ.get("CATALOG_PORT", "8080"))
CACHE_TTL_SECONDS = int(os.environ.get("CATALOG_CACHE_TTL_SECONDS", "900"))
REQUEST_TIMEOUT_SECONDS = int(os.environ.get("POSTMAN_REQUEST_TIMEOUT_SECONDS", "30"))
SPEC_PAGE_LIMIT = min(max(int(os.environ.get("POSTMAN_SPEC_PAGE_LIMIT", "100")), 1), 100)

WORKSPACE_ALLOWLIST = {
    value.strip()
    for value in os.environ.get("POSTMAN_WORKSPACE_ALLOWLIST", "").split(",")
    if value.strip()
}
