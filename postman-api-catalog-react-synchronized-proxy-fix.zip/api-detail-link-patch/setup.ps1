[CmdletBinding()]
param(
    [switch]$SkipInstall,
    [switch]$SkipBuild,
    [switch]$Start,
    [string]$PostmanApiKey
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

function Write-Step([string]$Message) {
    Write-Host "`n==> $Message" -ForegroundColor Cyan
}

function Require-Path([string]$Path, [string]$Description) {
    if (-not (Test-Path $Path)) {
        throw "$Description was not found at: $Path"
    }
}

function Require-Command([string]$Name, [string]$InstallHint) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "$Name was not found. $InstallHint"
    }
}

function Invoke-Native {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Command,

        [Parameter(ValueFromRemainingArguments = $true)]
        [string[]]$Arguments
    )

    & $Command @Arguments
    if ($LASTEXITCODE -ne 0) {
        $argumentText = $Arguments -join " "
        throw "Command failed with exit code ${LASTEXITCODE}: $Command $argumentText"
    }
}

function Get-VersionMajor([string]$VersionText) {
    $match = [regex]::Match($VersionText, '(\d+)')
    if (-not $match.Success) { return 0 }
    return [int]$match.Groups[1].Value
}

function Get-PythonCommand {
    foreach ($candidate in @("py", "python", "python3")) {
        if (Get-Command $candidate -ErrorAction SilentlyContinue) {
            return $candidate
        }
    }
    return $null
}

function Invoke-SystemPython {
    param(
        [Parameter(ValueFromRemainingArguments = $true)]
        [string[]]$Arguments
    )

    if ($script:PythonCommand -eq "py") {
        Invoke-Native "py" @("-3") @Arguments
    } else {
        Invoke-Native $script:PythonCommand @Arguments
    }
}

Write-Host "Postman API Catalog - first-time setup" -ForegroundColor Green

Write-Step "Checking project files"
Require-Path ".env.example" ".env.example"
Require-Path "backend\requirements.txt" "Backend requirements"
Require-Path "backend\run.py" "Backend entry point"
Require-Path "package.json" "Root package.json"
Require-Path "frontend\package.json" "Frontend package.json"

Write-Step "Checking prerequisites"
Require-Command "node" "Install Node.js 22 or newer, then rerun setup.bat."
Require-Command "npm" "Install NPM with Node.js, then rerun setup.bat."

$script:PythonCommand = Get-PythonCommand
if (-not $script:PythonCommand) {
    throw "Python was not found. Install Python 3.11 or newer and select 'Add Python to PATH', then rerun setup.bat."
}

$nodeVersion = (& node --version).Trim()
if ((Get-VersionMajor $nodeVersion) -lt 22) {
    throw "Node.js $nodeVersion is installed, but Node.js 22 or newer is required."
}

$pythonVersion = if ($script:PythonCommand -eq "py") {
    (& py -3 --version 2>&1).ToString().Trim()
} else {
    (& $script:PythonCommand --version 2>&1).ToString().Trim()
}

$pythonMatch = [regex]::Match($pythonVersion, '(\d+)\.(\d+)')
if (
    -not $pythonMatch.Success -or
    [int]$pythonMatch.Groups[1].Value -lt 3 -or
    (
        [int]$pythonMatch.Groups[1].Value -eq 3 -and
        [int]$pythonMatch.Groups[2].Value -lt 11
    )
) {
    throw "$pythonVersion is installed, but Python 3.11 or newer is required."
}

Write-Host "Node:   $nodeVersion"
Write-Host "NPM:    $((& npm --version).Trim())"
Write-Host "Python: $pythonVersion"

Write-Step "Preparing local environment configuration"
if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host "Created .env from .env.example"
} else {
    Write-Host ".env already exists; preserving its current values"
}

$currentEnv = Get-Content ".env" -Raw
$currentKey = ""
if ($currentEnv -match '(?m)^POSTMAN_API_KEY=(.*)$') {
    $currentKey = $Matches[1].Trim()
}

if (
    -not $PostmanApiKey -and
    (
        -not $currentKey -or
        $currentKey -eq "replace-with-your-postman-api-key"
    )
) {
    $secureKey = Read-Host "Enter your Postman API key (input is hidden)" -AsSecureString
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
    try {
        $PostmanApiKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
}

if ($PostmanApiKey) {
    $PostmanApiKey = $PostmanApiKey.Trim()
    if (-not $PostmanApiKey) {
        throw "The Postman API key cannot be empty."
    }

    $envText = Get-Content ".env" -Raw
    if ($envText -match '(?m)^POSTMAN_API_KEY=.*$') {
        $envText = [regex]::Replace(
            $envText,
            '(?m)^POSTMAN_API_KEY=.*$',
            "POSTMAN_API_KEY=$PostmanApiKey"
        )
    } else {
        $envText = $envText.TrimEnd() + "`r`nPOSTMAN_API_KEY=$PostmanApiKey`r`n"
    }

    Set-Content ".env" $envText -NoNewline -Encoding UTF8
    Write-Host "Saved the Postman API key to .env"
}

$finalEnv = Get-Content ".env" -Raw
if (
    $finalEnv -notmatch '(?m)^POSTMAN_API_KEY=.+$' -or
    $finalEnv -match '(?m)^POSTMAN_API_KEY=replace-with-your-postman-api-key\s*$'
) {
    throw "POSTMAN_API_KEY is not configured in .env."
}

$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"

if (-not $SkipInstall) {
    Write-Step "Creating the Python virtual environment"
    if (-not (Test-Path ".venv")) {
        Invoke-SystemPython "-m" "venv" ".venv"
    } else {
        Write-Host ".venv already exists; reusing it"
    }

    if (-not (Test-Path $VenvPython)) {
        throw "The Python virtual environment was not created correctly."
    }

    Write-Step "Installing backend dependencies"
    Invoke-Native $VenvPython "-m" "pip" "install" "--upgrade" "pip"
    Invoke-Native $VenvPython "-m" "pip" "install" "-r" "backend\requirements.txt"

    Write-Step "Verifying backend dependencies, including YAML support"
    Invoke-Native $VenvPython "-c" "import flask, dotenv, yaml; print('Backend imports verified: Flask, python-dotenv, PyYAML')"

    Write-Step "Installing root development dependencies"
    if (Test-Path "package-lock.json") {
        Invoke-Native "npm" "ci"
    } else {
        Invoke-Native "npm" "install"
    }

    Write-Step "Installing frontend dependencies"
    if (Test-Path "frontend\package-lock.json") {
        Invoke-Native "npm" "--prefix" "frontend" "ci"
    } else {
        Invoke-Native "npm" "--prefix" "frontend" "install"
    }
} else {
    Write-Host "Dependency installation skipped because -SkipInstall was supplied"
    Require-Path $VenvPython "Virtual-environment Python"
}

Write-Step "Verifying backend application imports"
Invoke-Native $VenvPython "-c" "import sys; sys.path.insert(0, 'backend'); import app, catalog; print('Backend application import verified')"

if (-not $SkipBuild) {
    Write-Step "Building the frontend to verify the installation"
    Invoke-Native "npm" "--prefix" "frontend" "run" "build"
} else {
    Write-Host "Frontend build verification skipped because -SkipBuild was supplied"
}

Write-Step "Setup complete"
Write-Host "Development site: http://localhost:5173"
$ConfiguredHost = "127.0.0.1"
$ConfiguredPort = "8080"
foreach ($line in Get-Content ".env") {
    if ($line -match '^\s*CATALOG_HOST=(.+?)\s*$') { $ConfiguredHost = $Matches[1].Trim() }
    if ($line -match '^\s*CATALOG_PORT=(.+?)\s*$') { $ConfiguredPort = $Matches[1].Trim() }
}
Write-Host "Backend API:      http://${ConfiguredHost}:${ConfiguredPort}"
Write-Host "Frontend proxy:   http://${ConfiguredHost}:${ConfiguredPort}"
Write-Host "Run start-dev.bat to start both services."

if ($Start) {
    Write-Step "Starting development servers"
    & "$ProjectRoot\start-dev.ps1"
}
