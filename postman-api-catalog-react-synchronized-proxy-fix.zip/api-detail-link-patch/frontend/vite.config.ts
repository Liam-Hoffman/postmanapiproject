import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig(({ mode }) => {
  // Load the same root .env file used by Flask so both services always agree.
  const env = loadEnv(mode, '..', '')
  const backendHost = env.CATALOG_HOST || '127.0.0.1'
  const backendPort = env.CATALOG_PORT || '8080'
  const apiTarget = env.VITE_API_TARGET || `http://${backendHost}:${backendPort}`

  return {
    envDir: '..',
    plugins: [react()],
    server: {
      host: '127.0.0.1',
      port: 5173,
      strictPort: true,
      proxy: {
        '/api': {
          target: apiTarget,
          changeOrigin: true,
        },
      },
    },
  }
})
