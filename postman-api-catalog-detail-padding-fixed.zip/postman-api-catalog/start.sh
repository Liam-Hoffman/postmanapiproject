#!/usr/bin/env sh
set -eu
if [ -z "${POSTMAN_API_KEY:-}" ]; then
  echo "POSTMAN_API_KEY is not set."
  echo 'export POSTMAN_API_KEY="PMAK-your-key"'
  exit 1
fi
python3 "$(dirname "$0")/server.py"
