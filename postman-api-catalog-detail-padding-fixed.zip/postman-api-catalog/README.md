# Postman API Catalog

A zero-`npm`, zero-`pip` internal API catalog built with Python's standard library and vanilla HTML/CSS/JavaScript.

## Postman request flow

1. `GET /workspaces`
2. For every accessible workspace:
   - `GET /specs?workspaceId={workspaceId}&limit=100`
   - Follow `meta.nextCursor` using the `cursor` query parameter
3. For every specification:
   - `GET /specs/{specId}/definitions`
4. Normalize the definitions into one `/api/catalog` payload.

The server never sends an `offset` query parameter to `/specs`.

## Requirements

- Python 3.10 or newer
- A Postman API key
- No Node.js, npm, Flask, FastAPI, or third-party Python libraries

## Windows PowerShell

```powershell
Expand-Archive .\postman-api-catalog.zip
cd .\postman-api-catalog
$env:POSTMAN_API_KEY = "PMAK-your-key"
.\start.ps1
```

Open `http://127.0.0.1:8080`.

## macOS or Linux

```bash
export POSTMAN_API_KEY="PMAK-your-key"
chmod +x start.sh
./start.sh
```

## Optional settings

```powershell
$env:POSTMAN_WORKSPACE_ALLOWLIST = "workspace-id-1,workspace-id-2"
$env:CATALOG_CACHE_TTL_SECONDS = "900"
$env:CATALOG_PORT = "8080"
```

When `POSTMAN_WORKSPACE_ALLOWLIST` is unset, all workspaces returned by the API key are queried.

## Local endpoints

- `GET /api/health`
- `GET /api/workspaces`
- `GET /api/catalog`
- `GET /api/catalog?refresh=true`

## OpenAPI metadata

```yaml
info:
  title: Customer API
  version: 1.0.0
  x-owner-team: Customer Platform
  x-lifecycle: production
  x-support-channel: "#customer-api-support"
  x-repository-url: "https://github.example.com/customer-api"
```

## YAML limitation

The application deliberately has no dependencies. JSON-formatted definitions are fully parsed. When Postman returns a YAML definition, the API still appears using Spec Hub metadata, but endpoint extraction is unavailable without a YAML parser.

## Troubleshooting

### `workspaceId is missing`

An older build called `/specs` globally. This package discovers workspaces first and always passes `workspaceId`.

### `/offset is invalid`

An older build used offset pagination. This package uses `cursor` and `meta.nextCursor`.

### Some workspaces show warnings

The API key may see a workspace while lacking permission to read one or more specs. Other workspaces continue loading, and the dashboard reports the warning count.


### `Expecting value: line 1 column 1`

An earlier build attempted `json.loads()` on every successful Postman response. This build:
- accepts raw YAML/text from `/specs/{specId}/definitions`
- detects empty successful responses
- reports the exact upstream Postman URL and response content type


## Progress logging and large catalogs

The console now logs every outbound Postman request and catalog progress.

For large catalogs, definition requests run concurrently. Adjust the worker count:

```powershell
$env:POSTMAN_DEFINITION_WORKERS = "8"
```

Use a lower value if your organization enforces strict rate limits.


## Fast-loading architecture

This build no longer downloads every definition during startup.

Initial page load:
1. Get accessible workspaces.
2. List specs for all workspaces in parallel.
3. Return lightweight catalog cards immediately.

When a user opens an API:
1. Fetch only that spec's complete definition.
2. Parse operations and metadata.
3. Cache the result in memory for later opens.

This reduces startup from approximately `workspaces + specs + every definition`
requests to approximately `workspaces + workspace spec-list pages`.

New endpoint:

- `GET /api/specs/{specId}` — load one definition on demand


## Workspace filtering

Workspaces whose name is exactly `My Workspace` (case-insensitive) are excluded.

## Postman API rate limiting

Postman documents a limit of 300 requests per minute per user/API key. This
application defaults to 240 requests per minute to leave headroom for other
Postman activity. It also reads Postman's rate-limit response headers and
automatically retries HTTP 429 responses.

Configuration:

```powershell
$env:POSTMAN_REQUESTS_PER_MINUTE = "240"
$env:POSTMAN_RATE_LIMIT_RETRIES = "5"
$env:POSTMAN_RATE_LIMIT_BUFFER_SECONDS = "1"
```

For a shared key or heavy parallel usage, reduce the local budget to 120–180.

## Specification viewer

Click anywhere on an API card. The definition is loaded on demand and cached.
Use the **Specification** tab to view the complete JSON/YAML source and
**Copy spec** to copy it.


## Personal workspace filtering

The catalog calls `GET /users` once and caches the team-user response. It extracts
the first and last token from each user's `name`, then excludes workspaces whose
name contains an exact matching token. Matching is case-insensitive and does not
use substrings. `My Workspace` and workspaces with zero specs are also excluded.

User cache duration defaults to the catalog cache duration and can be changed with:

```powershell
$env:POSTMAN_USER_CACHE_TTL_SECONDS = "900"
```

If the API key cannot access `GET /users`, the catalog continues loading and logs a
warning; only user-name filtering is disabled.


## Improved API details
- Converts HTML description markup such as `<br>` into readable paragraphs.
- Displays server URLs as a numbered, wrapping list.
- Shows explicit or schema-generated example request bodies for OpenAPI 3 and Swagger/OpenAPI 2 operations.


## Request field tables

Each operation now lists request-body fields with:

- Nested field path
- OpenAPI type and format
- Required or optional status
- Field description, when provided

Nested objects use dotted paths such as `customer.address.city`, while array items use paths such as `items[].sku`.


## Required-field and description fixes

- Card buttons always read `View API Details`.
- Catalog card descriptions are cleaned before display and no longer change after opening an API.
- Operation request fields now include body fields plus path, query, header, and cookie parameters.
- Required flags and schema types are shown for referenced and nested request schemas.


## Search within an API

The sticky API-detail header includes a search box. In Overview, it filters matching summary information, descriptions, servers, operations, parameters, request fields, and examples. In Specification, it checks the raw specification text.

Long card badges such as `Unspecified` are also prevented from shrinking or clipping.


## Sticky detail search correction

The `Search this API…` field is now physically nested inside the sticky detail-header container. It remains visible with the workspace name, API name, tabs, copy action, and close control while scrolling.


## Empty section headings during search

When searching inside an API, section wrappers are now hidden when none of their content matches. This prevents headings such as Description, Servers, Operations, or Request fields from appearing above an empty area.


## Correct detail-search placement

The main catalog header now scrolls normally and contains no API-detail search. The `Search this API…` input is located only inside the opened API dialog's sticky header, beneath the Overview, Specification, Copy spec, and Close controls.


## Detail view spacing

Added extra bottom padding to the API detail content so the final section is not clipped, plus additional bottom padding beneath the sticky-header search field.
