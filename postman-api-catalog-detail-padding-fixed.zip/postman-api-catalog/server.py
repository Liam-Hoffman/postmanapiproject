from __future__ import annotations

import json
import urllib.parse
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import config
from catalog import CatalogService
from postman_client import PostmanAPIError, PostmanClient

PUBLIC_DIR = Path(__file__).resolve().parent / "public"


class AppHandler(SimpleHTTPRequestHandler):
    service: CatalogService

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(PUBLIC_DIR), **kwargs)

    def _json(self, status: int, payload: object) -> None:
        body = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)

        if parsed.path == "/api/health":
            self._json(200, {"status": "ok"})
            return

        if parsed.path == "/api/catalog":
            print("[Server] Starting catalog load...", flush=True)
            params = urllib.parse.parse_qs(parsed.query)
            force = params.get("refresh", ["false"])[0].lower() in {
                "1", "true", "yes"
            }
            try:
                self._json(200, self.service.get_catalog(force=force))
            except (PostmanAPIError, ValueError) as exc:
                self._json(
                    502,
                    {"error": "Unable to load catalog", "details": str(exc), "upstreamUrl": getattr(exc, "url", "")},
                )
            except Exception as exc:
                self._json(
                    500,
                    {"error": "Unexpected catalog error", "details": str(exc)},
                )
            return


        if parsed.path.startswith("/api/specs/"):
            spec_id = urllib.parse.unquote(parsed.path[len("/api/specs/"):])
            params = urllib.parse.parse_qs(parsed.query)
            force = params.get("refresh", ["false"])[0].lower() in {
                "1", "true", "yes"
            }
            if not spec_id:
                self._json(400, {"error": "Missing specification ID"})
                return
            try:
                self._json(200, self.service.get_spec_detail(spec_id, force=force))
            except KeyError as exc:
                self._json(404, {"error": str(exc)})
            except PostmanAPIError as exc:
                self._json(
                    502,
                    {
                        "error": "Unable to load specification definition",
                        "details": str(exc),
                        "upstreamUrl": getattr(exc, "url", ""),
                    },
                )
            except Exception as exc:
                self._json(
                    500,
                    {"error": "Unexpected specification error", "details": str(exc)},
                )
            return

        if parsed.path == "/api/workspaces":
            try:
                workspaces = self.service.client.get_workspaces()
                self._json(
                    200,
                    {
                        "workspaces": [
                            {"id": ws.id, "name": ws.name, "type": ws.type}
                            for ws in workspaces
                        ]
                    },
                )
            except PostmanAPIError as exc:
                self._json(502, {"error": str(exc), "upstreamUrl": getattr(exc, "url", "")})
            return

        super().do_GET()


def main() -> None:
    if not config.POSTMAN_API_KEY:
        raise SystemExit(
            "POSTMAN_API_KEY is not set. See README.md for setup instructions."
        )

    client = PostmanClient(config.POSTMAN_API_KEY)
    AppHandler.service = CatalogService(client)
    server = ThreadingHTTPServer((config.HOST, config.PORT), AppHandler)
    print(f"Postman API Catalog: http://{config.HOST}:{config.PORT}")
    print("Press Ctrl+C to stop.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping server.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
