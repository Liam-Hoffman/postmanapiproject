$ErrorActionPreference = "Stop"

if (-not $env:POSTMAN_API_KEY) {
    Write-Host "POSTMAN_API_KEY is not set." -ForegroundColor Yellow
    Write-Host '$env:POSTMAN_API_KEY = "PMAK-your-key"'
    exit 1
}

python "$PSScriptRoot\server.py"
