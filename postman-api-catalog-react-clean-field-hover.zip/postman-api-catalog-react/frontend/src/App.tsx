import { useEffect, useMemo, useState } from 'react'
import { Navigate, Route, Routes, useLocation, useNavigate, useParams } from 'react-router-dom'
import { Sidebar } from './components/Sidebar'
import { ApiExplorer } from './components/ApiExplorer'
import { catalogApi } from './lib/api'
import { searchable } from './lib/text'
import type { ApiItem, CatalogPayload } from './types'

const CSAA_PREFIX = '[CSAA]'

function slugFor(api: ApiItem) { return `${api.name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'')}-${api.id}` }

export default function App() {
  const [payload, setPayload] = useState<CatalogPayload>({ apis: [], apiCount: 0, workspaceCount: 0 })
  const [search, setSearch] = useState('')
  const [workspace, setWorkspace] = useState('')
  const [sort, setSort] = useState('name')
  const [loading, setLoading] = useState(true)
  const [status, setStatus] = useState('Loading workspace metadata…')

  async function load(refresh = false) {
    setLoading(true); setStatus('Loading workspace metadata…')
    try {
      const data = await catalogApi.getCatalog(refresh)
      const apis = data.apis.filter(api => api.workspace?.name?.startsWith(CSAA_PREFIX))
      const workspaceMap = new Map(apis.map(api => [api.workspace.id, api.workspace]))
      setPayload({ ...data, apis, apiCount: apis.length, workspaceCount: workspaceMap.size, workspaces: [...workspaceMap.values()] })
      setStatus(`Showing ${apis.length} CSAA APIs`)
    } catch (error) { setStatus(error instanceof Error ? error.message : 'Unable to load catalog') }
    finally { setLoading(false) }
  }
  useEffect(() => { void load() }, [])

  const query = search.trim().toLowerCase()
  const searchMatches = useMemo(() => payload.apis.filter(api => !query || searchable(api).includes(query)), [payload.apis, query])
  const workspaces = useMemo(() => [...new Map(searchMatches.map(api => [api.workspace.id, api.workspace])).values()].sort((a,b) => a.name.localeCompare(b.name)), [searchMatches])
  useEffect(() => { if (workspace && !workspaces.some(w => w.id === workspace)) setWorkspace('') }, [workspace, workspaces])
  const items = useMemo(() => {
    const result = searchMatches.filter(api => !workspace || api.workspace.id === workspace)
    return [...result].sort((a,b) => sort === 'updated' ? String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')) : sort === 'operations' ? (b.operationCount ?? -1) - (a.operationCount ?? -1) : a.name.localeCompare(b.name))
  }, [searchMatches, workspace, sort])

  async function ensureDetails(api: ApiItem) {
    if (api.detailsLoaded) return api
    const detail = await catalogApi.getSpec(api.id)
    const merged = { ...api, ...detail, catalogDescription: api.catalogDescription ?? api.description, detailsLoaded: true }
    setPayload(current => ({ ...current, apis: current.apis.map(item => item.id === api.id ? merged : item) }))
    return merged
  }

  const summary = `${payload.apiCount} APIs across ${payload.workspaceCount} [CSAA] workspaces${payload.loadMilliseconds != null ? ` · loaded in ${payload.loadMilliseconds} ms` : ''}`
  const location = useLocation()
  const isCatalogHome = location.pathname === '/'
  return <div className={`catalog-shell app-shell ${isCatalogHome ? 'catalog-route' : 'detail-route'}`}>
    {isCatalogHome && <Sidebar summary={summary} search={search} workspace={workspace} sort={sort} workspaces={workspaces} apiCount={items.length} workspaceCount={workspaces.length} loading={loading} onSearch={setSearch} onWorkspace={setWorkspace} onSort={setSort} onRefresh={() => void load(true)} onTheme={() => { document.documentElement.classList.toggle('dark'); localStorage.setItem('catalog-theme', document.documentElement.classList.contains('dark') ? 'dark' : 'light') }} />}
    <Routes>
      <Route path="/" element={<CatalogHome items={items} status={status} slugFor={slugFor} />} />
      <Route path="/catalog/:apiSlug" element={<ApiRoute apis={payload.apis} ensureDetails={ensureDetails} />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  </div>
}

function CatalogHome({ items, status, slugFor }: { items: ApiItem[]; status: string; slugFor(api: ApiItem): string }) {
  const navigate = useNavigate()
  const grouped = useMemo(() => [...new Map(items.map(api => [api.workspace.id, { workspace: api.workspace, apis: [] as ApiItem[] }])).values()], [items])
  items.forEach(api => grouped.find(group => group.workspace.id === api.workspace.id)?.apis.push(api))
  return <main className="catalog-main">
    <div className="main-header sticky-topbar"><div><div className="eyebrow">Available APIs</div><h2>Browse the catalog</h2></div><p>{status} · {items.length} visible</p></div>
    <section className="workspace-groups">
      {grouped.map(group => <details className="workspace-group" key={group.workspace.id} open>
        <summary><span className="group-chevron">›</span><strong>{group.workspace.name}</strong><span className="workspace-count">{group.apis.length}</span></summary>
        <div className="api-list-table">
          <div className="api-list-header"><span>API</span><span>Description</span><span>Lifecycle</span><span>Operations</span><span>Owner</span><span>Updated</span></div>
          {group.apis.map(api => <button className="api-list-row" key={api.id} onClick={() => navigate(`/catalog/${slugFor(api)}`)}>
            <span className="api-list-name"><strong>{api.name}</strong></span>
            <span className="api-list-description">{api.catalogDescription || api.description || 'Open this API to view its definition.'}</span>
            <span><span className="lifecycle-pill">{api.lifecycle || 'On demand'}</span></span>
            <span>{api.operationCount ?? 'Load on open'}</span>
            <span>{api.owner || 'Load on open'}</span>
            <span>{api.updatedAt ? new Date(api.updatedAt).toLocaleDateString() : 'Unknown'}</span>
          </button>)}
        </div>
      </details>)}
      {!items.length && <p className="notice">No matching APIs were found.</p>}
    </section>
  </main>
}

function ApiRoute({ apis, ensureDetails }: { apis: ApiItem[]; ensureDetails(api: ApiItem): Promise<ApiItem> }) {
  const { apiSlug = '' } = useParams()
  const navigate = useNavigate()
  const location = useLocation()
  const id = apiSlug.split('-').at(-1) || ''
  const baseApi = apis.find(api => api.id === id) || apis.find(api => apiSlug.endsWith(api.id))
  const [api, setApi] = useState<ApiItem | null>(baseApi || null)
  const [loading, setLoading] = useState(Boolean(baseApi && !baseApi.detailsLoaded))
  const [error, setError] = useState('')
  useEffect(() => {
    if (!baseApi) return
    setApi(baseApi)
    if (baseApi.detailsLoaded) return
    setLoading(true); setError('')
    ensureDetails(baseApi).then(setApi).catch(err => setError(err instanceof Error ? err.message : 'Unable to load API')).finally(() => setLoading(false))
  }, [baseApi?.id])
  if (!baseApi && apis.length) return <Navigate to="/" replace />
  return <main className="catalog-main explorer-main">
    <div className="main-header sticky-topbar"><div><button className="text-button" onClick={() => navigate('/')}>← Catalog</button><div className="eyebrow">{api?.workspace.name || 'API'}</div><h2>{api?.name || 'Loading API…'}</h2></div><p>{location.hash ? 'Linked operation' : 'API reference'}</p></div>
    {loading && <p className="notice">Loading this API definition from Postman…</p>}
    {error && <p className="notice error">{error}</p>}
    {api && !loading && !error && <ApiExplorer api={api} />}
  </main>
}
