## Summary

Describe the catalog or deployment change.

## Validation

- [ ] `npm run lint`
- [ ] `npm run build`
- [ ] `verify.ps1 -SkipFrontendBuild` or equivalent backend verification
- [ ] Kubernetes manifests render with `kubectl kustomize`
- [ ] No `.env`, credentials, generated dependencies, or build output are committed

## Deployment impact

- [ ] No deployment impact
- [ ] API Catalog image/configuration
- [ ] Secrets Manager, DNS, certificate, or IAM change

Document rollout and rollback notes when deployment behavior changes.
