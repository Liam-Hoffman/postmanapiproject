# GitHub upload checklist

For the complete ownership and maintenance handoff, read
[`docs/project-handoff-guide.md`](docs/project-handoff-guide.md).

Before the first push:

1. Confirm `.env`, virtual environments, dependency folders, build output, and
   Python caches are ignored.
2. Run `bash scripts/ci-verify.sh` from Git Bash or WSL.
3. Run `npm run lint` and `npm run build`.
4. Run `.\verify.ps1 -SkipFrontendBuild` on Windows.
5. Render `kubectl kustomize deploy/eks`.
6. Review the ECR image, GitHub repository URL, internal hostname, ACM
   certificate ARN, and other environment placeholders.
7. Confirm the committed documentation matches the current routes,
   configuration, secrets, refresh behavior, and deployment process.

Never upload `.env`, GitHub access tokens, kubeconfig files, AWS access keys, or
other production credentials. If a real credential was previously committed,
rotate it; deleting it from the latest commit is not sufficient.

The runtime example expects the AWS Secrets Manager secret
`api-catalog-secrets` to synchronize to the Kubernetes Secret
`api-catalog-secrets` in the `api-catalog` namespace. It contains
`GITHUB_ACCESS_TOKEN` and `CATALOG_REFRESH_PASSWORD`.

The example `ExternalSecret` is not included in the Kustomize bundle. Confirm
the approved secret synchronizer creates the Kubernetes Secret before the first
application deployment.

The application has no login or authorization layer. Ensure the deployed ALB
is internal and reachable only through approved company network paths.
