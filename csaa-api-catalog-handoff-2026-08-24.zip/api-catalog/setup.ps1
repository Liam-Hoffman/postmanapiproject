[CmdletBinding()]
param(
    [switch]$SkipInstall,
    [switch]$SkipBuild,
    [switch]$SkipGitHubCheck,
    [switch]$Mock,
    [switch]$Start,
    [string]$GitHubRepositoryUrl,
    [Alias("GitHubToken")]
    [string]$GitHubAccessToken
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

function Write-Step([string]$Message) {
    Write-Host "`n==> $Message" -ForegroundColor Cyan
}

function Require-Path([string]$Path, [string]$Description) {
    if (-not (Test-Path $Path)) { throw "$Description was not found at: $Path" }
}

function Require-Command([string]$Name, [string]$InstallHint) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "$Name was not found. $InstallHint"
    }
}

function Invoke-Native {
    param(
        [Parameter(Mandatory = $true)][string]$Command,
        [Parameter(ValueFromRemainingArguments = $true)][string[]]$Arguments
    )
    & $Command @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Command failed with exit code ${LASTEXITCODE}: $Command $($Arguments -join ' ')"
    }
}

function Get-VersionMajor([string]$VersionText) {
    $match = [regex]::Match($VersionText, '(\d+)')
    if (-not $match.Success) { return 0 }
    return [int]$match.Groups[1].Value
}

function Get-PythonCommand {
    foreach ($candidate in @("py", "python", "python3")) {
        if (Get-Command $candidate -ErrorAction SilentlyContinue) { return $candidate }
    }
    return $null
}

function Invoke-SystemPython {
    param([Parameter(ValueFromRemainingArguments = $true)][string[]]$Arguments)
    if ($script:PythonCommand -eq "py") {
        Invoke-Native "py" @("-3") @Arguments
    } else {
        Invoke-Native $script:PythonCommand @Arguments
    }
}

function Get-EnvValue([string]$Name) {
    if (-not (Test-Path ".env")) { return "" }
    $pattern = "^\s*" + [regex]::Escape($Name) + "=(.*)$"
    foreach ($line in Get-Content ".env") {
        if ($line -match $pattern) { return $Matches[1].Trim() }
    }
    return ""
}

function Set-EnvValue([string]$Name, [string]$Value) {
    $envText = Get-Content ".env" -Raw
    $pattern = "(?m)^" + [regex]::Escape($Name) + "=.*$"
    $line = "$Name=$Value"
    if ($envText -match $pattern) {
        $envText = [regex]::Replace($envText, $pattern, [System.Text.RegularExpressions.MatchEvaluator]{ param($match) $line })
    } else {
        $envText = $envText.TrimEnd() + "`r`n$line`r`n"
    }
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText((Join-Path $ProjectRoot ".env"), $envText, $utf8NoBom)
}

Write-Host "GitHub Monorepo API Catalog - first-time setup" -ForegroundColor Green

Write-Step "Checking project files"
Require-Path ".env.example" ".env.example"
Require-Path "backend\requirements.txt" "Backend requirements"
Require-Path "backend\run.py" "Backend entry point"
Require-Path "backend\github_client.py" "GitHub provider"
Require-Path "backend\verify_installation.py" "Installation verification helper"
Require-Path "package.json" "Root package.json"
Require-Path "frontend\package.json" "Frontend package.json"

Write-Step "Checking prerequisites"
Require-Command "node" "Install Node.js 22 or newer, then rerun setup.bat."
Require-Command "npm" "Install NPM with Node.js, then rerun setup.bat."
$script:PythonCommand = Get-PythonCommand
if (-not $script:PythonCommand) {
    throw "Python was not found. Install Python 3.11 or newer and select 'Add Python to PATH'."
}

$nodeVersion = (& node --version).Trim()
if ((Get-VersionMajor $nodeVersion) -lt 22) {
    throw "Node.js $nodeVersion is installed, but Node.js 22 or newer is required."
}
$pythonVersion = if ($script:PythonCommand -eq "py") {
    (& py -3 --version 2>&1).ToString().Trim()
} else {
    (& $script:PythonCommand --version 2>&1).ToString().Trim()
}
$pythonMatch = [regex]::Match($pythonVersion, '(\d+)\.(\d+)')
if (-not $pythonMatch.Success -or [int]$pythonMatch.Groups[1].Value -lt 3 -or
    ([int]$pythonMatch.Groups[1].Value -eq 3 -and [int]$pythonMatch.Groups[2].Value -lt 11)) {
    throw "$pythonVersion is installed, but Python 3.11 or newer is required."
}
Write-Host "Node:   $nodeVersion"
Write-Host "NPM:    $((& npm --version).Trim())"
Write-Host "Python: $pythonVersion"

Write-Step "Preparing catalog configuration"
if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host "Created .env from .env.example"
} else {
    Write-Host ".env already exists; preserving existing values"
}

if ($Mock) {
    Set-EnvValue "CATALOG_SOURCE" "mock"
}
$CatalogSource = Get-EnvValue "CATALOG_SOURCE"
$UseMockCatalog = $CatalogSource -eq "mock"

if ($UseMockCatalog) {
    Write-Host "Mock catalog selected; GitHub credentials are not required." -ForegroundColor Green
} else {
$currentUrl = Get-EnvValue "GITHUB_REPOSITORY_URL"
if (-not $GitHubRepositoryUrl -and (
    -not $currentUrl -or $currentUrl -match 'organization/platform-monorepo'
)) {
    $GitHubRepositoryUrl = Read-Host "GitHub repository URL"
}
if ($GitHubRepositoryUrl) {
    Set-EnvValue "GITHUB_REPOSITORY_URL" $GitHubRepositoryUrl.Trim()
}

$currentToken = Get-EnvValue "GITHUB_ACCESS_TOKEN"
if (-not $GitHubAccessToken -and (
    -not $currentToken -or $currentToken -eq "replace-with-github-access-token"
)) {
    $secureToken = Read-Host "GitHub access token (input hidden)" -AsSecureString
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureToken)
    try {
        $GitHubAccessToken = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
}
if ($GitHubAccessToken) {
    Set-EnvValue "GITHUB_ACCESS_TOKEN" $GitHubAccessToken.Trim()
}

$finalUrl = Get-EnvValue "GITHUB_REPOSITORY_URL"
$finalToken = Get-EnvValue "GITHUB_ACCESS_TOKEN"
if (-not $finalUrl -or $finalUrl -match 'organization/platform-monorepo') {
    throw "GITHUB_REPOSITORY_URL must contain the repository root URL."
}
if (-not $finalToken -or $finalToken -eq "replace-with-github-access-token") {
    throw "GITHUB_ACCESS_TOKEN must contain a GitHub access token."
}
}

$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
if (-not $SkipInstall) {
    Write-Step "Creating the Python virtual environment"
    if (-not (Test-Path ".venv")) { Invoke-SystemPython "-m" "venv" ".venv" }
    Require-Path $VenvPython "Virtual-environment Python"

    Write-Step "Installing backend dependencies"
    Invoke-Native $VenvPython "-m" "pip" "install" "--upgrade" "pip"
    Invoke-Native $VenvPython "-m" "pip" "install" "-r" "backend\requirements.txt"
    Write-Step "Verifying backend dependencies"
    Invoke-Native $VenvPython "backend\verify_installation.py" "dependencies"

    Write-Step "Installing root development dependencies"
    if (Test-Path "package-lock.json") { Invoke-Native "npm" "ci" } else { Invoke-Native "npm" "install" }
    Write-Step "Installing frontend dependencies"
    if (Test-Path "frontend\package-lock.json") {
        Invoke-Native "npm" "--prefix" "frontend" "ci"
    } else {
        Invoke-Native "npm" "--prefix" "frontend" "install"
    }
} else {
    Write-Host "Dependency installation skipped because -SkipInstall was supplied"
    Require-Path $VenvPython "Virtual-environment Python"
}

Write-Step "Verifying backend imports"
Invoke-Native $VenvPython "backend\verify_installation.py" "imports"

if ($UseMockCatalog) {
    Write-Host "Repository URL and GitHub access checks skipped for mock catalog mode."
} else {
    Write-Step "Verifying repository URL"
    $canonicalOutput = & $VenvPython "backend\verify_installation.py" "repository-url"
    $canonicalExitCode = $LASTEXITCODE
    if ($canonicalExitCode -ne 0) {
        throw "The GitHub repository URL is invalid. Review the verification error above."
    }

    $canonicalLine = $canonicalOutput | Select-Object -Last 1
    if ($null -eq $canonicalLine -or [string]::IsNullOrWhiteSpace([string]$canonicalLine)) {
        throw "Repository URL verification returned no canonical URL."
    }
    $canonicalUrl = ([string]$canonicalLine).Trim()
    Write-Host "Repository: $canonicalUrl"

    if (-not $SkipGitHubCheck) {
        Write-Step "Verifying token-authenticated GitHub repository access"
        Invoke-Native $VenvPython "backend\verify_installation.py" "github-access"
    } else {
        Write-Host "GitHub access verification skipped because -SkipGitHubCheck was supplied"
    }
}

if (-not $SkipBuild) {
    Write-Step "Building the frontend to verify the installation"
    Invoke-Native "npm" "--prefix" "frontend" "run" "build"
} else {
    Write-Host "Frontend build verification skipped because -SkipBuild was supplied"
}

Write-Step "Setup complete"
if ($UseMockCatalog) {
    Write-Host "Catalog source:   local mock fixture"
} else {
    Write-Host "Repository:       $canonicalUrl"
}
Write-Host "Development site: http://127.0.0.1:5173"
Write-Host "Backend API:      http://127.0.0.1:8080"
Write-Host "Run start-dev.bat to start both services."

if ($Start) {
    Write-Step "Starting development servers"
    & "$ProjectRoot\start-dev.ps1"
}
