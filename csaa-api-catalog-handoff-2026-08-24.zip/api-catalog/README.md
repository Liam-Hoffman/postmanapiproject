# [CSAA] API Catalog

An internal React and Flask portal that discovers OpenAPI documents from one
GitHub or GitHub Enterprise repository and presents them as a searchable API
catalog.

## Start here

- New project owner: [Project Handoff Guide](docs/project-handoff-guide.md)
- Catalog user: [User Guide](docs/user-guide.md)
- Local developer: [Local Setup and Development](docs/local-development.md)
- API author: [OpenAPI Authoring Guide](docs/openapi-authoring-guide.md)
- EKS operator: [EKS Deployment](deploy/eks/README.md)
- Pipeline owner: [CodePipeline and CodeBuild](deploy/codepipeline/README.md)
- Support engineer: [Operations Runbook](docs/operations-runbook.md)
- Security reviewer: [Security Model](docs/security.md)
- All documentation: [Documentation Index](docs/README.md)

Before publishing or transferring the repository, use the
[GitHub Upload Checklist](GITHUB_UPLOAD_CHECKLIST.md).

## Quick local start with mock data

Windows PowerShell:

```powershell
.\setup.ps1 -Mock
.\start-dev.ps1
```

Open `http://127.0.0.1:5173`. Mock mode renders three sample APIs and does not
require GitHub credentials.

For GitHub-backed development, copy `.env.example` to `.env` and configure:

```env
CATALOG_SOURCE=github
GITHUB_REPOSITORY_URL=https://github.com/company/repository
GITHUB_ACCESS_TOKEN=<read-only token>
CATALOG_REFRESH_PASSWORD=<local refresh password>
```

Never commit `.env`.

## How it works

```text
Browser
  -> React UI
  -> Flask /api
  -> GitHub repository tree and blobs
  -> OpenAPI validation and normalization
  -> process-local in-memory cache
```

Production runs the compiled frontend and Flask API in one Gunicorn container.
EKS runs two pods behind an internal ALB. Every pod refreshes its cache at
`00:00`, `06:00`, `12:00`, and `18:00` UTC. Manual refresh requires a shared
password.

## Current security boundary

The application has no SSO, user session, or per-user authorization. Keep the
production ALB internal and restrict it through approved company networking.
Full raw OpenAPI source delivery is disabled until SSO and backend
authorization are implemented.

Production secrets are:

```text
GITHUB_ACCESS_TOKEN
CATALOG_REFRESH_PASSWORD
```

They are expected in the Kubernetes Secret `api-catalog-secrets`, synchronized
from the AWS Secrets Manager secret with the same name.

## Verification

```powershell
.\verify.ps1
kubectl kustomize deploy/eks
```

CI uses [buildspec.yml](buildspec.yml) to verify the source, build and push an
immutable ECR image, and generate `api-catalog-manifests.yaml` for the
CodePipeline V2 EKS deploy action.

