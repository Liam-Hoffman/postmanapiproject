from __future__ import annotations

import copy
import json
from datetime import datetime, timezone
from pathlib import Path
from types import SimpleNamespace
from typing import Any


MOCK_DATA_PATH = Path(__file__).with_name("mock_catalog.json")


class MockCatalogClient:
    repository_name = "local/mock-api-catalog"

    @staticmethod
    def health() -> dict[str, Any]:
        return {
            "status": "ok",
            "provider": "mock",
            "repository": MockCatalogClient.repository_name,
            "ref": "local",
            "authenticated": False,
        }


class MockCatalogService:
    """Serve deterministic fixtures through the production catalog contract."""

    def __init__(self, data_path: Path = MOCK_DATA_PATH):
        self.client = MockCatalogClient()
        with data_path.open(encoding="utf-8") as handle:
            fixture = json.load(handle)
        self._catalog = fixture["catalog"]
        self._specs = fixture["specs"]
        self._refresh: dict[str, Any] | None = None

    def get_catalog(
        self,
        force: bool = False,
        refresh_source: str | None = None,
    ) -> dict[str, Any]:
        if force or self._refresh is None:
            self._refresh = {
                "lastRefreshedAt": datetime.now(timezone.utc).isoformat(),
                "trigger": refresh_source or ("manual" if force else "initial"),
            }
        result = copy.deepcopy(self._catalog)
        for item in result["apis"]:
            detail = self._specs.get(item["id"], {})
            item["operations"] = copy.deepcopy(detail.get("operations") or [])
        result["cache"] = {"hit": not force, "ageSeconds": 0}
        result["refresh"] = copy.deepcopy(self._refresh)
        return result

    def get_spec_detail(self, spec_id: str, force: bool = False) -> dict[str, Any]:
        try:
            result = copy.deepcopy(self._specs[spec_id])
        except KeyError as exc:
            raise KeyError(f"Specification not found: {spec_id}") from exc
        # TODO: Remove this safeguard and restore raw-specification delivery only
        # after SSO is enabled, fully configured, and authorization is enforced.
        result.pop("definitionText", None)
        result["detailCacheHit"] = not force
        return result

    def get_groups(self) -> list[SimpleNamespace]:
        return [SimpleNamespace(**item) for item in self._catalog["workspaces"]]
