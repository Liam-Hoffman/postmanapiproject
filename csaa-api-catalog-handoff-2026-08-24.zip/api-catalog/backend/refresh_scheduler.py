from __future__ import annotations

import threading
from collections.abc import Callable
from datetime import datetime, time, timedelta, timezone, tzinfo
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError


class CatalogRefreshScheduler:
    """Run process-local catalog refreshes at configured wall-clock hours."""

    def __init__(
        self,
        refresh: Callable[[], Any],
        hours: tuple[int, ...],
        timezone_name: str,
    ) -> None:
        if not hours:
            raise ValueError("At least one catalog refresh hour is required.")
        if any(hour < 0 or hour > 23 for hour in hours):
            raise ValueError("Catalog refresh hours must be between 0 and 23.")

        resolved_timezone: tzinfo
        if timezone_name.casefold() in {"utc", "etc/utc", "z"}:
            resolved_timezone = timezone.utc
        else:
            try:
                resolved_timezone = ZoneInfo(timezone_name)
            except ZoneInfoNotFoundError as exc:
                raise ValueError(
                    f"Unknown catalog refresh timezone: {timezone_name}"
                ) from exc

        self._refresh = refresh
        self._hours = tuple(sorted(set(hours)))
        self._timezone = resolved_timezone
        self._timezone_name = timezone_name
        self._stop_event = threading.Event()
        self._thread: threading.Thread | None = None
        self._state_lock = threading.Lock()
        self._next_refresh_at: datetime | None = None
        self._last_refresh_at: datetime | None = None
        self._last_error = ""

    def start(self) -> None:
        if self._thread is not None and self._thread.is_alive():
            return
        self._thread = threading.Thread(
            target=self._run,
            name="catalog-refresh-scheduler",
            daemon=True,
        )
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()

    def next_refresh(self, now: datetime | None = None) -> datetime:
        current = now or datetime.now(self._timezone)
        if current.tzinfo is None:
            current = current.replace(tzinfo=self._timezone)
        else:
            current = current.astimezone(self._timezone)

        for day_offset in (0, 1):
            candidate_date = (current + timedelta(days=day_offset)).date()
            for hour in self._hours:
                candidate = datetime.combine(
                    candidate_date,
                    time(hour=hour),
                    tzinfo=self._timezone,
                )
                if candidate > current:
                    return candidate
        raise RuntimeError("Unable to calculate the next catalog refresh.")

    def status(self) -> dict[str, Any]:
        with self._state_lock:
            return {
                "enabled": True,
                "hours": list(self._hours),
                "timezone": self._timezone_name,
                "nextRefreshAt": (
                    self._next_refresh_at.isoformat()
                    if self._next_refresh_at
                    else None
                ),
                "lastRefreshAt": (
                    self._last_refresh_at.isoformat()
                    if self._last_refresh_at
                    else None
                ),
                "lastError": self._last_error or None,
            }

    def _run(self) -> None:
        while not self._stop_event.is_set():
            scheduled_at = self.next_refresh()
            with self._state_lock:
                self._next_refresh_at = scheduled_at

            print(
                "[Catalog] Next automatic refresh scheduled for "
                f"{scheduled_at.isoformat()}.",
                flush=True,
            )
            wait_seconds = max(
                (scheduled_at - datetime.now(self._timezone)).total_seconds(),
                0,
            )
            if self._stop_event.wait(wait_seconds):
                return

            try:
                self._refresh()
            except Exception as exc:
                with self._state_lock:
                    self._last_error = str(exc)
                print(
                    f"[Catalog] Automatic refresh failed: {exc}",
                    flush=True,
                )
            else:
                completed_at = datetime.now(self._timezone)
                with self._state_lock:
                    self._last_refresh_at = completed_at
                    self._last_error = ""
                print(
                    "[Catalog] Automatic refresh completed at "
                    f"{completed_at.isoformat()}.",
                    flush=True,
                )
