from __future__ import annotations

import hmac
import os
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

import config
from catalog import CatalogService
from github_client import GitHubAPIError, GitHubMonorepoClient
from mock_catalog import MockCatalogService
from refresh_scheduler import CatalogRefreshScheduler

BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIST = BASE_DIR.parent / "frontend" / "dist"


def create_app() -> Flask:
    app = Flask(__name__, static_folder=None)

    service: CatalogService | MockCatalogService | None = None
    service_error = ""
    try:
        if config.CATALOG_SOURCE == "mock":
            service = MockCatalogService()
        elif config.CATALOG_SOURCE != "github":
            service_error = "CATALOG_SOURCE must be either 'github' or 'mock'."
        elif config.GITHUB_REPOSITORY_URL and config.GITHUB_ACCESS_TOKEN:
            service = CatalogService(
                GitHubMonorepoClient(
                    repository_url=config.GITHUB_REPOSITORY_URL,
                    token=config.GITHUB_ACCESS_TOKEN,
                )
            )
        else:
            service_error = (
                "GITHUB_REPOSITORY_URL and GITHUB_ACCESS_TOKEN are not configured. "
                "Copy .env.example to .env and provide the repository URL and token."
            )
    except ValueError as exc:
        service_error = str(exc)

    refresh_scheduler: CatalogRefreshScheduler | None = None
    if service is not None and config.CATALOG_AUTO_REFRESH_ENABLED:
        try:
            refresh_scheduler = CatalogRefreshScheduler(
                refresh=lambda: service.get_catalog(
                    force=True,
                    refresh_source="automatic",
                ),
                hours=config.CATALOG_REFRESH_HOURS,
                timezone_name=config.CATALOG_REFRESH_TIMEZONE,
            )
            refresh_scheduler.start()
            app.extensions["catalog_refresh_scheduler"] = refresh_scheduler
        except ValueError as exc:
            service_error = str(exc)
            service = None

    def require_service() -> CatalogService:
        if service is None:
            raise ValueError(service_error or "Catalog source is not configured.")
        return service

    def manual_refresh_denial():
        configured_password = config.CATALOG_REFRESH_PASSWORD
        supplied_password = request.headers.get(
            "X-Catalog-Refresh-Password",
            "",
        )
        if not configured_password:
            return jsonify(
                {
                    "error": "Manual catalog refresh is unavailable",
                    "details": "A refresh password has not been configured.",
                }
            ), 503
        if not hmac.compare_digest(supplied_password, configured_password):
            return jsonify(
                {
                    "error": "Manual catalog refresh denied",
                    "details": "The refresh password is incorrect.",
                }
            ), 403
        return None

    @app.get("/api/health")
    def health():
        payload = {
            "status": "ok",
            "environment": os.getenv("APP_ENV", "development"),
            "provider": config.CATALOG_SOURCE,
        }
        if service is not None:
            payload["repository"] = service.client.repository_name
        payload["automaticRefresh"] = (
            refresh_scheduler.status()
            if refresh_scheduler is not None
            else {"enabled": False}
        )
        return jsonify(payload)

    @app.get("/api/source-health")
    def source_health():
        try:
            return jsonify(require_service().client.health())
        except (GitHubAPIError, ValueError) as exc:
            return jsonify(
                {
                    "status": "error",
                    "error": str(exc),
                    "upstreamUrl": getattr(exc, "url", ""),
                }
            ), 502

    @app.get("/api/catalog")
    def catalog():
        force = request.args.get("refresh", "false").lower() in {
            "1", "true", "yes"
        }
        if force and (denial := manual_refresh_denial()) is not None:
            return denial
        try:
            return jsonify(
                require_service().get_catalog(
                    force=force,
                    refresh_source="manual" if force else None,
                )
            )
        except (GitHubAPIError, ValueError) as exc:
            return jsonify(
                {
                    "error": "Unable to load GitHub catalog",
                    "details": str(exc),
                    "upstreamUrl": getattr(exc, "url", ""),
                }
            ), 502
        except Exception as exc:
            return jsonify(
                {
                    "error": "Unexpected catalog error",
                    "details": str(exc),
                }
            ), 500

    @app.get("/api/discovery")
    def discovery():
        force = request.args.get("refresh", "false").lower() in {
            "1", "true", "yes"
        }
        if force and (denial := manual_refresh_denial()) is not None:
            return denial
        try:
            catalog_payload = require_service().get_catalog(force=force)
            source = catalog_payload.get("source") or {}
            return jsonify(
                {
                    "apiCount": catalog_payload.get("apiCount", 0),
                    "workspaceCount": catalog_payload.get("workspaceCount", 0),
                    "source": source,
                    "discovery": source.get("discovery") or {},
                }
            )
        except (GitHubAPIError, ValueError) as exc:
            return jsonify(
                {
                    "error": "Unable to run GitHub discovery",
                    "details": str(exc),
                    "upstreamUrl": getattr(exc, "url", ""),
                }
            ), 502

    @app.get("/api/specs/<path:spec_id>")
    def spec_detail(spec_id: str):
        force = request.args.get("refresh", "false").lower() in {
            "1", "true", "yes"
        }
        if force and (denial := manual_refresh_denial()) is not None:
            return denial
        try:
            return jsonify(
                require_service().get_spec_detail(spec_id, force=force)
            )
        except KeyError as exc:
            return jsonify({"error": str(exc)}), 404
        except GitHubAPIError as exc:
            return jsonify(
                {
                    "error": "Unable to load GitHub specification",
                    "details": str(exc),
                    "upstreamUrl": getattr(exc, "url", ""),
                }
            ), 502
        except Exception as exc:
            return jsonify(
                {
                    "error": "Unexpected specification error",
                    "details": str(exc),
                }
            ), 500

    # Compatibility endpoint: frontend terminology is being kept stable.
    @app.get("/api/workspaces")
    def workspaces():
        try:
            values = require_service().get_groups()
            return jsonify(
                {
                    "workspaces": [
                        {"id": item.id, "name": item.name, "type": item.type}
                        for item in values
                    ]
                }
            )
        except (GitHubAPIError, ValueError) as exc:
            return jsonify(
                {
                    "error": str(exc),
                    "upstreamUrl": getattr(exc, "url", ""),
                }
            ), 502

    @app.get("/")
    @app.get("/<path:path>")
    def frontend(path: str = ""):
        if not FRONTEND_DIST.exists():
            return jsonify(
                {
                    "error": "Frontend build not found",
                    "details": (
                        "Run npm install and npm run build in frontend, "
                        "or use npm run dev for local development."
                    ),
                }
            ), 404
        candidate = FRONTEND_DIST / path
        if path and candidate.is_file():
            return send_from_directory(FRONTEND_DIST, path)
        return send_from_directory(FRONTEND_DIST, "index.html")

    return app


app = create_app()

if __name__ == "__main__":
    app.run(
        host=config.HOST,
        port=config.PORT,
        debug=os.getenv("APP_ENV", "development") == "development",
    )
