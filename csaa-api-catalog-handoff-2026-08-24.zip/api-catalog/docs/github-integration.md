# GitHub Integration

## Authentication

The backend sends:

```text
Authorization: Bearer <token>
```

The token never enters frontend state or responses.

For GitHub.com private repositories, use a fine-grained personal access token limited to the target repository with read-only Contents access when company policy permits it. GitHub documents read-level Contents permission for repository content access:

- [GitHub repository contents REST API](https://docs.github.com/en/rest/repos/contents)
- [Managing personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens)

Organization policy may require explicit approval before a token can access the repository.

For a shared long-running production deployment, consider replacing a personal token with a GitHub App installation token so access is not tied to one employee.

## Repository URL parsing

Supported examples:

```text
https://github.com/acme/docs
https://github.com/acme/docs.git
git@github.com:acme/docs.git
https://github.acme.com/acme/docs
```

Rejected examples include branch, directory, and file URLs. Configure only the repository root.

## GitHub.com API mapping

```text
Repository: https://github.com/acme/docs
API base:   https://api.github.com
```

## GitHub Enterprise API mapping

```text
Repository: https://github.acme.com/acme/docs
API base:   https://github.acme.com/api/v3
```

The ECS/network environment must be able to resolve and reach the enterprise host.

## Discovery APIs used

The implementation uses repository metadata, Git tree, and Git blob APIs.

High-level flow:

```text
GET repository metadata
GET recursive Git tree
GET individual Git blobs
```

The scanner uses the default branch returned by repository metadata.

## Recursive-tree truncation

GitHub can mark recursive tree responses as truncated. When that occurs, the implementation traverses subtrees one at a time and reconstructs full paths.

The discovery report records:

```text
recursiveTreeTruncated
traversalMode
totalTreeEntries
totalBlobs
```

## Candidate files

Candidate selection is extension-based:

```text
.json
.yml
.yaml
```

Filename patterns are not required.

## Content retrieval

Discovered files are retrieved using blob SHA. GitHub returns Base64 content, which the backend decodes as UTF-8 with BOM handling.

## Rate limiting and retries

The client retries:

- HTTP 429
- HTTP 500
- HTTP 502
- HTTP 503
- HTTP 504
- HTTP 403 when GitHub indicates zero remaining rate limit
- Selected URL/network errors

Configure retries using:

```env
GITHUB_MAX_RETRIES=3
GITHUB_RETRY_BUFFER_SECONDS=1
```

## Token rotation

Local:

1. Update `.env`
2. Stop the application
3. Restart the application
4. Run `verify.bat`

AWS EKS:

1. Update the Secrets Manager secret
2. Confirm External Secrets synchronized the Kubernetes Secret
3. Roll out the `api-catalog` Deployment because environment variables are read at pod start
4. Confirm `/api/source-health`
5. Confirm a catalog refresh
6. Revoke the old token after validation

The expected AWS and Kubernetes secret name is `api-catalog-secrets`. Updating
the AWS secret alone does not change environment variables in existing pods.

## Source links

The catalog builds links of the form:

```text
<repository-url>/blob/<default-branch>/<path>
```

Browser users need their own GitHub permission to open private source links.
