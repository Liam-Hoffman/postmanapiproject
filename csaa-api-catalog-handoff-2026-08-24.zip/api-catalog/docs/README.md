# [CSAA] API Catalog Documentation

This documentation is the operational and development handoff for the project.

## Recommended reading paths

| Audience | Read in this order |
|---|---|
| New project owner | [Project Handoff Guide](project-handoff-guide.md) → [Maintenance and Releases](maintenance.md) → [Operations Runbook](operations-runbook.md) |
| Catalog user | [User Guide](user-guide.md) |
| API author | [OpenAPI Authoring Guide](openapi-authoring-guide.md) → [GitHub Integration](github-integration.md) |
| Application developer | [Project Handoff Guide](project-handoff-guide.md) → [Local Development](local-development.md) → [Runtime Architecture](runtime-architecture.md) → [API Reference](api-reference.md) |
| EKS and pipeline engineer | [EKS Deployment](../deploy/eks/README.md) → [CodePipeline and CodeBuild](../deploy/codepipeline/README.md) → [Configuration Reference](configuration-reference.md) |
| Security reviewer | [Security Model](security.md) → [Runtime Architecture](runtime-architecture.md) |
| Support or on-call engineer | [Operations Runbook](operations-runbook.md) → [Troubleshooting](troubleshooting.md) |

## Complete document set

1. [Project Handoff Guide](project-handoff-guide.md)
2. [User Guide](user-guide.md)
3. [OpenAPI Authoring Guide](openapi-authoring-guide.md)
4. [Local Setup and Development](local-development.md)
5. [Runtime Architecture](runtime-architecture.md)
6. [Configuration Reference](configuration-reference.md)
7. [GitHub Integration](github-integration.md)
8. [Backend API Reference](api-reference.md)
9. [EKS Deployment](../deploy/eks/README.md)
10. [CodePipeline and CodeBuild](../deploy/codepipeline/README.md)
11. [Security Model](security.md)
12. [Operations Runbook](operations-runbook.md)
13. [Troubleshooting](troubleshooting.md)
14. [Maintenance and Releases](maintenance.md)

## Product summary

The catalog scans the default branch of a configured GitHub repository for
JSON and YAML OpenAPI documents. Each accepted document becomes one API row.
Users can search API metadata and endpoints, sort results, expand endpoint
previews, and open normalized operation documentation.

The application is read-only and has no database. GitHub remains the source of
truth. Catalog and detail caches are process-local and reconstructed after a
restart.

## Important limitations

- No SSO, application login, user sessions, or per-user authorization
- Full raw specification response and UI are intentionally disabled
- Internal network controls are required in production
- External relative and URL `$ref` values are not resolved
- Caches are not shared across EKS pods
- The default branch is scanned; there is no runtime branch selector
- Manual refresh uses a shared password and has no per-user audit identity
- There is no formal unit or integration test suite; the supplied verification
  scripts are build and smoke-validation helpers

## Keeping documentation current

Every behavioral change must update the relevant guide in the same pull
request. At minimum, configuration changes update `.env.example`, the EKS
configuration, and `configuration-reference.md`; route changes update
`api-reference.md`; operational changes update the runbook and troubleshooting
guide.
