# Security Model

## Trust boundaries

```text
Internal browser -> internal ALB/Ingress -> Flask -> GitHub API
```

The application has no authentication, authorization, or user-session layer.
Anyone who can reach the service can view the normalized catalog documentation.
Full raw specification delivery is currently disabled. Treat the service as
internal confidential documentation and make the ALB private.

Recommended controls:

- Approved private EKS networking
- Internal ALB with HTTPS only
- Private DNS and company VPN/routing
- ClusterIP service with no direct public pod exposure
- Security groups and network policies following company standards
- Controlled outbound access to GitHub
- Access logs and monitoring at the ALB/platform boundary

## GitHub token

The backend reads `GITHUB_ACCESS_TOKEN` from its environment and sends it only
to the configured GitHub API as a Bearer token. Never place it in frontend
source, browser storage, `VITE_*` variables, HTML, or client-side configuration.
Use a read-only token scoped to the required repository and store it in AWS
Secrets Manager through the approved Kubernetes secret integration.

Injected environment values require a pod rollout to change. Restrict access to
the secret source, Kubernetes Secret, pod execution, and deployment operations.

## Manual refresh password

Forced refreshes require `CATALOG_REFRESH_PASSWORD`, supplied in the
`X-Catalog-Refresh-Password` header. Store it in AWS Secrets Manager beside the
GitHub token. It is a shared operational safeguard, not identity authentication,
authorization, or a replacement for the internal network boundary. The backend
uses constant-time comparison and does not log the supplied header.

## Data sensitivity and logging

The catalog can expose internal API names, paths, schemas, examples, server
URLs, repository paths, owners, support channels, and security scheme names.
GitHub source URLs sent to the browser do not contain the backend token.

Do not log environment variables, credentials, or full request headers. Review
logs and error responses for internal hostnames, repository names, upstream
URLs, and parsing details.

## Known limitations

- No application-level identity, access checks, or user audit trail
- No per-API authorization
- No request-rate limiting in Flask
- Shared manual-refresh password has no per-user audit identity
- No Content Security Policy configuration
- In-memory caches are not shared across replicas
- External `$ref` content is not fetched

Run dependency and container vulnerability scanning, retain lockfiles, use
`npm ci`, and maintain a regular upgrade cadence before production use.
