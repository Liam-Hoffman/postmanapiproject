# Troubleshooting

## Setup fails with `NameError: name 'backend' is not defined`

Cause: an older build passed an inline Python expression through PowerShell and lost quotes.

Resolution:

- Use the current build
- Confirm `backend/verify_installation.py` exists
- Rerun `setup.bat`

## Setup reports a null-valued expression

This was a secondary error after failed repository URL parsing in an older script.

Use the current `setup.ps1`, which checks command output before calling string methods.

## Only some APIs appear

Run:

```bat
discovery-report.bat
```

Or:

```text
GET /api/discovery?refresh=true
```

Supply `X-Catalog-Refresh-Password` when calling the forced endpoint.

Review:

```text
ref
searchRoot
extensionCandidateCount
matchedSpecCount
rejectedFiles
excludedBySearchRootPaths
recursiveTreeTruncated
traversalMode
```

Common causes:

- File is not on the default branch
- Extension is not configured
- `GITHUB_SEARCH_ROOT` excludes the file
- Invalid JSON/YAML
- Missing OpenAPI marker
- Missing `info.title`
- Missing `paths`
- Git submodule content is not part of the parent repository tree

## GitHub returns 401

Check:

- Token was copied correctly
- Token has not expired
- Secret does not include surrounding quotes
- Token belongs to the correct GitHub host

Rotate the token when uncertain.

## GitHub returns 403

Possible causes:

- Organization policy blocks the token
- Fine-grained PAT is awaiting approval
- Organization authorization or token approval is required
- Rate limit exhausted
- Repository permission is missing

Check `/api/source-health` and GitHub organization policies.

## GitHub returns 404 for a private repository

GitHub often returns 404 when the caller lacks private repository access.

Check:

- Repository URL
- Owner and repository spelling
- Token repository selection
- Contents read permission

## GitHub Enterprise cannot be reached

Check:

- DNS from the runtime
- VPC/company network routes
- Firewall rules
- Enterprise TLS certificate trust
- API base URL mapping
- Proxy requirements

## `/api/health` works but catalog fails

`/api/health` is local-only. Check:

```text
/api/source-health
/api/discovery?refresh=true
```

The likely problem is GitHub access, parsing, or scanning.

## `/api/source-health` works but scan fails

Possible causes:

- Rate limiting during many blob requests
- Candidate file too large or invalid
- Unexpected GitHub API response
- Network timeout
- YAML parsing issue

Increase timeout carefully:

```env
GITHUB_REQUEST_TIMEOUT_SECONDS=60
```

Reduce concurrency:

```env
GITHUB_SCAN_WORKERS=4
```

## Endpoint search misses results

Check:

- Detail-loading progress completed
- Operation includes method/path/summary/description/operation ID/tag
- API is not excluded by API search
- Search term is not only in response schemas, which are not part of endpoint search text

## API name is incorrect

The title comes from `info.title`.

The displayed major version uses the first numeric segment from `info.version`.

Examples:

```text
2.7.1      → V2
v3-beta    → V3
2026-07-01 → V2026
```

Date-style versions therefore display the year as the major version.

## External schema fields are missing

External relative `$ref` files are not resolved.

Bundle the OpenAPI document or replace references with local JSON Pointers.

## Frontend shows `Frontend build not found`

Run:

```bash
npm --prefix frontend install
npm --prefix frontend run build
```

For local development, use `start-dev.bat` or `start-dev.sh`.

## Docker frontend dependency install fails

The Dockerfile uses `npm ci` and requires the committed
`frontend/package-lock.json` to match `frontend/package.json`. Run `npm install`
inside `frontend` only when intentionally changing dependencies, review the
lockfile diff, then rerun the production build.

## EKS pod or ALB target is unhealthy

Check:

- Container listens on `0.0.0.0:8080`
- Service targets the named `http` container port
- Ingress health path is `/api/health`
- ALB target type is `ip`
- Pod startup/readiness/liveness probe events
- Pod logs
- Gunicorn started successfully
- Secret and ConfigMap names exist

## Updated secret is not used

Environment variables are set when a pod starts. Restart or roll out the Deployment after updating the Kubernetes/external secret.

## Refresh appears inconsistent

Cause: independent caches in multiple EKS pods.

Resolution:

- Roll out/restart all pods
- Use one Gunicorn worker for simple deployments
- Add a shared cache in a future version

## Manual refresh returns `403`

The submitted password is missing or does not match
`CATALOG_REFRESH_PASSWORD` in that pod. Confirm the AWS secret contains the
correct key, External Secrets synchronized it, and the Deployment was rolled
out after the change.

Do not put the password in the query string. The UI sends it through
`X-Catalog-Refresh-Password`.

## Manual refresh returns `503`

`CATALOG_REFRESH_PASSWORD` is not configured in the backend environment. Check
that Kubernetes Secret `api-catalog-secrets` exists in namespace `api-catalog`
and contains both required keys. Do not print its values during diagnosis.

## Automatic refresh is disabled or reports an error

Inspect `/api/health` and pod logs. Confirm:

```env
CATALOG_AUTO_REFRESH_ENABLED=true
CATALOG_REFRESH_HOURS=0,6,12,18
CATALOG_REFRESH_TIMEZONE=UTC
```

An automatic-refresh failure leaves the previous successful cache in place.
GitHub network, token, rate-limit, parsing, and timezone configuration errors
are the most likely causes.

## Pod reports missing `api-catalog-secrets`

The Deployment uses a non-optional `secretRef`, so the container cannot start
until the Kubernetes Secret exists. Check the `ExternalSecret`, its
`ClusterSecretStore`, controller events, and the operator IAM permission to read
the AWS Secrets Manager secret `api-catalog-secrets`.
