# Runtime Architecture

## Component diagram

```mermaid
flowchart LR
    U[Browser user] -->|HTTPS or local HTTP| F[React/Vite frontend]
    F -->|/api requests| A[Flask application]
    A --> C[CatalogService]
    C --> G[GitHubMonorepoClient]
    G -->|Bearer token| GH[GitHub REST API]
    C --> P[OpenAPI parser and normalizer]
    C --> M[(In-memory catalog and detail caches)]
    A --> R[Scheduled refresh thread]
    R --> C
    A -->|Production static files| D[frontend/dist]
```

For the EKS hosting model:

```mermaid
flowchart LR
    E[Employees] --> ALB[Internal ALB / EKS Ingress]
    ALB --> EKS[EKS API Catalog pods]
    EKS --> GH[GitHub API]
    EKS --> SM[Kubernetes or external secrets]
    EKS --> CW[Cluster logging / CloudWatch]
    ECR[Amazon ECR] --> EKS
```


## Frontend

Technology:

- React
- TypeScript
- Vite
- React Router

Responsibilities:

- Dashboard and detailed documentation UI
- API metadata search
- Endpoint search
- Sorting
- Endpoint expansion
- Operation navigation
- Normalized API documentation display (raw specification display is disabled until SSO and authorization are enabled)
- Theme persistence

The frontend calls relative `/api` URLs. It never receives the GitHub token.

## Backend

Technology:

- Python
- Flask
- PyYAML
- Gunicorn in the Docker production image

Responsibilities:

- Runtime configuration
- GitHub authentication
- Repository-tree traversal
- JSON/YAML candidate selection
- OpenAPI validation
- Metadata and operation normalization
- Cache management
- Password-protected manual refresh
- Scheduled process-local refresh
- Health and diagnostics endpoints
- Static frontend serving in production

## GitHub discovery sequence

1. Parse the configured repository URL.
2. Determine:
   - Host
   - Owner
   - Repository
   - GitHub.com or GitHub Enterprise API base URL
3. Read repository metadata.
4. Use the repository default branch.
5. Request a recursive Git tree.
6. If GitHub marks the response as truncated, walk every subtree explicitly.
7. Select candidate files using configured extensions.
8. Apply `GITHUB_SEARCH_ROOT` when set.
9. Download each candidate by Git blob SHA.
10. Parse as JSON first, then YAML.
11. Validate that the document is OpenAPI/Swagger.
12. Normalize metadata and operations.
13. Cache catalog and detail results.

## OpenAPI validation

A candidate must be an object containing:

- `openapi`, or `swagger: "2.0"`
- `info`
- `info.title`
- `paths`

Invalid and non-OpenAPI files are recorded in the discovery report with a reason.

## Normalized data model

The backend presents the frontend with a provider-neutral catalog model. Important fields include:

```text
id
name
version
description
owner
lifecycle
domain
tags
servers
securitySchemes
operationCount
operations
sourcePath
sourceUrl
sourceRef
sourceSha
```

The UI does not consume raw GitHub tree or blob response shapes.

## Caching

`CatalogService` uses process-local memory:

- Catalog cache
- Detail cache
- Cache timestamp
- Spec index

Default TTL:

```text
900 seconds
```

A forced refresh rebuilds the catalog and replaces that process's detail cache
and spec index. Refresh metadata records the completion time and whether the
trigger was initial, manual, or automatic.

### Automatic refresh

When `CATALOG_AUTO_REFRESH_ENABLED=true`, each process starts one daemon thread.
It calculates the next configured wall-clock hour and calls
`get_catalog(force=True, refresh_source="automatic")`. Failures are logged and
the previous successful cache remains available.

The EKS manifest enables refresh at `00:00`, `06:00`, `12:00`, and `18:00` UTC.
The scheduler's next run, last successful automatic run, and last error appear
under `automaticRefresh` in `/api/health`.

Manual refresh is separate. Requests using `refresh=true` must provide
`CATALOG_REFRESH_PASSWORD` through `X-Catalog-Refresh-Password`.

### Production implication

Caches are not shared between:

- Gunicorn workers
- EKS pods
- Separate application instances

The current Dockerfile starts one Gunicorn worker with eight threads:

```text
--workers 1 --threads 8
```

Each EKS pod has an independent catalog cache, so repository refreshes and cache age can differ by pod. Implement a shared cache such as Redis if exact cross-pod cache consistency is required.

## Concurrency

OpenAPI candidate validation uses a bounded thread pool controlled by:

```env
GITHUB_SCAN_WORKERS=8
```

Allowed range:

```text
1 through 24
```

Higher values can reduce scan time but increase concurrent GitHub requests, CPU use, and memory use.

## Static serving

During development:

```text
Vite serves the frontend
Flask serves /api
```

In the Docker production image:

```text
Gunicorn runs Flask
Flask serves frontend/dist
Flask serves /api
```

Unknown frontend routes return `frontend/dist/index.html`, enabling React Router deep links.

## Network dependencies

The runtime needs outbound access to:

- GitHub.com API, or
- The configured GitHub Enterprise API endpoint

In EKS private networking, provide NAT, company routing, proxy configuration, or another approved egress path to GitHub.

## Persistence

The application has no database and stores no durable catalog state. Restarting the process clears all caches. GitHub remains the source of truth.


## Application access

The runtime has no application authentication, authorization, or user sessions.
The internal EKS network boundary is responsible for limiting who can reach the
catalog. The shared refresh password protects only forced refresh actions.
