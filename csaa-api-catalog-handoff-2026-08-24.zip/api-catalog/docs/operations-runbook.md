# Operations Runbook

## Service dependencies

- EKS workload and Kubernetes Service
- Internal ALB, private DNS, routing, and TLS
- GitHub repository and API
- GitHub access token
- Manual refresh password
- AWS Secrets Manager to Kubernetes Secret synchronization

The application has no login layer. The platform network boundary is the access
control, so a public or broadly reachable ALB is a release blocker.

## Health checks

- `GET /api/health` checks the local process and is used by Kubernetes and ALB.
- `GET /api/source-health` verifies GitHub repository visibility and token use.
- `GET /api/discovery?refresh=true` performs a complete scan diagnostic and
  requires `X-Catalog-Refresh-Password`.

Do not poll the latter two frequently because they call GitHub.

## Startup validation

1. Confirm the expected ready replicas and healthy ALB targets.
2. Confirm the ALB scheme is internal and network reachability is restricted.
3. Open `/api/health` and `/api/source-health`.
4. Confirm the expected API count.
5. Test API and endpoint search and open a detail view.
6. Confirm GitHub source links use the expected host and repository.
7. Confirm `/api/health` reports automatic refresh enabled with the expected
   hours and timezone.
8. Confirm the sidebar displays a last-refreshed time and trigger.

## Routine commands

```bash
kubectl -n api-catalog get deployment,pods,service,ingress,pdb
kubectl -n api-catalog rollout status deployment/api-catalog
kubectl -n api-catalog logs deployment/api-catalog --tail=200
kubectl -n api-catalog describe deployment api-catalog
```

Do not retrieve the Kubernetes Secret as YAML during normal diagnosis.

## GitHub token rotation

1. Create a replacement read-only token.
2. Confirm repository access.
3. Update the external secret source.
4. Roll out the Deployment.
5. Confirm `/api/source-health` and refresh the catalog.
6. Revoke the old token and record the rotation owner/date.

## Manual refresh-password rotation

1. Generate a replacement value.
2. Update `CATALOG_REFRESH_PASSWORD` in the AWS Secrets Manager secret
   `api-catalog-secrets`.
3. Wait for or force the approved secret synchronization.
4. Roll out the Deployment so pods receive the new environment value.
5. Confirm the old password fails and the new password succeeds.
6. Record the rotation owner and date without recording the password.

## Deployment and rollback

Verify, build, tag with the commit SHA, push to ECR, update the immutable image,
apply the manifests, and wait for:

```bash
kubectl -n api-catalog rollout status deployment/api-catalog
```

Then repeat startup validation. Roll back by restoring the previous immutable
image, applying the Deployment, and checking health and GitHub source access.

CodePipeline creates images tagged with the first 12 characters of the Git
commit SHA and produces `api-catalog-manifests.yaml`. Record the pipeline
execution and image URI for each release.

Recommended alarms include unavailable replicas, pod restarts, unhealthy ALB
targets, 5xx responses, response time, CPU/memory usage, and GitHub rate-limit
or 403 patterns.

## Capacity, cache, and recovery

The initial scan downloads and parses configured JSON/YAML candidates. Resource
use grows with repository size, candidate count, specification size, schema
complexity, scan worker count, and replica count.

Caches are in-memory per process. A refresh affects the process handling the
request. In EKS, every pod also forces its own refresh at `00:00`, `06:00`,
`12:00`, and `18:00` UTC. Check `/api/health` for each process's next refresh,
last successful refresh, and most recent scheduler error. Roll out all pods when
exact cache consistency is required outside that schedule.

There is no application database. Recovery uses the source repository, ECR
image, deployment manifests, external-secret configuration, GitHub repository,
and infrastructure configuration.

## Incident triage

1. Determine whether the failure is browser, ALB, pod, catalog, or GitHub source.
2. Check ALB targets and Kubernetes ready replicas.
3. Check `/api/health`; it does not call GitHub.
4. Check `/api/source-health` once; it does call GitHub.
5. Review recent deployment, secret-sync, and automatic-refresh events.
6. Preserve logs and the failed image URI before rollback.
7. Roll back if the last known immutable image is healthy and the failure began
   with a deployment.
