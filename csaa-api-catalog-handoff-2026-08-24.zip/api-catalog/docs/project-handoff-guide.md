# Project Handoff Guide

This is the primary guide for anyone taking ownership of the `[CSAA] API
Catalog`. Read it once from top to bottom, then use the linked reference guides
for detailed procedures.

## 1. What this project does

The catalog is an internal, read-only documentation portal for OpenAPI files
stored in one GitHub or GitHub Enterprise repository. It:

1. Reads the configured repository's default branch through the GitHub REST API.
2. Finds `.json`, `.yaml`, and `.yml` files recursively.
3. Parses each candidate and accepts only OpenAPI 3.x or Swagger 2.0 documents.
4. Normalizes API metadata and operations into a provider-neutral response.
5. Displays the APIs in a searchable React interface.

The catalog does not modify GitHub, execute documented APIs, provision users,
or store catalog data in a database.

## 2. Current security posture

The application does not currently implement SSO, user sessions, or per-user
authorization. Production access must be limited by an internal ALB, private
DNS, corporate routing or VPN, and approved security groups.

Full raw OpenAPI source delivery is disabled in both the backend response and
frontend renderer. Users can still see normalized documentation such as API
names, routes, request fields, examples, servers, owners, and security-scheme
names.

Manual repository refresh is protected by a shared password. This is only an
operational safeguard; it is not user authentication.

Read [Security Model](security.md) before changing exposure, authentication, or
secret handling.

## 3. Technology and runtime model

| Layer | Technology | Responsibility |
|---|---|---|
| Browser UI | React, TypeScript, React Router | Search, sorting, API list, endpoint previews, detailed API documentation |
| Development server | Vite | Serves the frontend locally and proxies `/api` to Flask |
| Backend | Python, Flask, PyYAML | Configuration, GitHub access, discovery, parsing, normalization, caching, APIs |
| Production server | Gunicorn | Runs one Flask worker with eight threads per container |
| Source of truth | GitHub REST API | Repository metadata, tree entries, and OpenAPI blob content |
| Container registry | Amazon ECR | Stores immutable application images |
| Runtime | Amazon EKS | Runs two catalog pods behind an internal ALB |
| Secrets | AWS Secrets Manager and Kubernetes Secret synchronization | Supplies the GitHub token and manual-refresh password |
| Delivery | GitHub, CodeConnections, CodeBuild, CodePipeline V2 | Verifies, builds, pushes, approves, and deploys releases |

Production serves the compiled React files and `/api` routes from the same
Flask/Gunicorn container on port `8080`.

## 4. Repository layout

```text
backend/
  app.py                    Flask application and HTTP routes
  catalog.py                OpenAPI parsing, normalization, cache, discovery service
  config.py                 Environment-variable configuration
  github_client.py          GitHub URL parsing and REST API client
  mock_catalog.py           Local fixture-backed service
  mock_catalog.json         Renderable sample catalog data
  refresh_scheduler.py      Process-local scheduled refresh thread
  verify_installation.py    Setup and diagnostic checks

frontend/
  src/App.tsx               Routes, catalog state, list, preview behavior
  src/components/Sidebar.tsx
                             Branding, search, sort, refresh, theme controls
  src/components/ApiExplorer.tsx
                             Detailed API and operation renderer
  src/lib/                  API calls, search helpers, display helpers
  src/styles.css            Application styling and responsive layout

deploy/eks/                 Kubernetes namespace, workload, service, ingress, PDB
deploy/codepipeline/        CodePipeline and CodeBuild instructions
docs/                       Product, developer, security, and operations guides
scripts/ci-verify.sh        Release-artifact and credential safety checks

Dockerfile                  Multi-stage production image
buildspec.yml               CodeBuild verify/build/push/artifact workflow
.env.example                Complete local configuration template
setup.*                     First-time dependency and configuration setup
start-dev.*                 Local backend/frontend startup
verify.*                    Local verification suite
discovery-report.*          Repository discovery diagnostic
```

Generated folders such as `.venv`, `node_modules`, `frontend/dist`, Python
caches, `.env`, and release ZIPs must not be committed.

## 5. Five-minute local evaluation with mock data

This path requires no GitHub token.

Windows PowerShell:

```powershell
.\setup.ps1 -Mock
.\start-dev.ps1
```

Alternatively, set these values in `.env`:

```env
CATALOG_SOURCE=mock
CATALOG_AUTO_REFRESH_ENABLED=false
CATALOG_REFRESH_PASSWORD=choose-a-local-password
```

Open:

```text
http://127.0.0.1:5173
```

Expected result: Payments, Customer Profile, and Inventory sample APIs render.
The backend is available at `http://127.0.0.1:8080`.

## 6. Local development with GitHub data

Prerequisites:

- Node.js 22 or newer
- npm
- Python 3.11 or newer
- Read access to the source repository
- A read-only GitHub token approved by company policy

Run `setup.bat` on Windows or `./setup.sh` on Linux/macOS. Configure:

```env
CATALOG_SOURCE=github
GITHUB_REPOSITORY_URL=https://github.com/company/repository
GITHUB_ACCESS_TOKEN=<read-only token>
CATALOG_REFRESH_PASSWORD=<local manual-refresh password>
```

Never commit `.env`. Start the application with `start-dev.bat` or
`./start-dev.sh` and use the same local URL shown above.

Detailed instructions: [Local Setup and Development](local-development.md).

## 7. How repository discovery works

The discovery pipeline is:

```text
Repository URL
  -> GitHub repository metadata and default branch
  -> recursive Git tree
  -> explicit subtree traversal if GitHub truncates the tree
  -> extension filtering
  -> optional GITHUB_SEARCH_ROOT filtering
  -> blob download by SHA
  -> JSON/YAML parse
  -> OpenAPI validation
  -> metadata and operation normalization
  -> process-local cache
```

A candidate is accepted only when it contains an OpenAPI version marker,
`info.title`, and a `paths` object. Filenames do not determine acceptance.

Local `$ref` pointers such as `#/components/schemas/Payment` are resolved.
External file and URL references are not resolved; specifications using them
should be bundled before publishing.

Detailed behavior: [GitHub Integration](github-integration.md) and
[OpenAPI Authoring Guide](openapi-authoring-guide.md).

## 8. Data and refresh behavior

Catalog and detail data are held in memory. There is no database. Each Gunicorn
process and EKS pod owns an independent cache.

EKS configuration currently uses:

```env
CATALOG_CACHE_TTL_SECONDS=21600
CATALOG_AUTO_REFRESH_ENABLED=true
CATALOG_REFRESH_HOURS=0,6,12,18
CATALOG_REFRESH_TIMEZONE=UTC
```

Each pod refreshes itself at `00:00`, `06:00`, `12:00`, and `18:00` UTC. A
successful refresh retains metadata identifying it as automatic or manual. The
sidebar displays the last refresh time and trigger returned by the pod serving
that request.

Manual refresh sends `CATALOG_REFRESH_PASSWORD` in the
`X-Catalog-Refresh-Password` header. All API requests using `refresh=true`
enforce the same password. The browser does not store the password.

Because caches are process-local, one manual refresh updates only the pod that
handles it. The scheduled refresh runs independently in every pod. Use a shared
cache in a future version if exact cross-pod consistency becomes necessary.

## 9. Configuration and secrets

Non-secret production configuration lives in
`deploy/eks/configmap.yaml`. Production secrets must be injected as environment
variables through the Kubernetes Secret named `api-catalog-secrets` in the
`api-catalog` namespace.

The expected AWS Secrets Manager secret is also named:

```text
api-catalog-secrets
```

It contains:

```text
GITHUB_ACCESS_TOKEN
CATALOG_REFRESH_PASSWORD
```

The example `ExternalSecret` maps that AWS secret to the Kubernetes Secret. It
requires External Secrets Operator, a `ClusterSecretStore` named
`aws-secrets-manager`, and an IAM role allowed to read the AWS secret.

Complete variable list: [Configuration Reference](configuration-reference.md).

## 10. Common code changes

### Change the catalog home page

- Layout and list behavior: `frontend/src/App.tsx`
- Sidebar controls: `frontend/src/components/Sidebar.tsx`
- Styling: `frontend/src/styles.css`
- Search text: `frontend/src/lib/text.ts`
- Display names and operation anchors: `frontend/src/lib/catalog.ts`

### Change detailed API rendering

Edit `frontend/src/components/ApiExplorer.tsx`. Raw-spec rendering is commented
out deliberately. Do not restore it until SSO is enabled and the backend detail
endpoint performs authorization.

### Change accepted OpenAPI metadata

Edit normalization in `backend/catalog.py`, then update:

- `frontend/src/types.ts`
- Search helpers when the new field should be searchable
- `backend/mock_catalog.json`
- API and authoring documentation

### Change GitHub behavior

Edit `backend/github_client.py`. Preserve retry handling, GitHub.com versus
Enterprise URL behavior, tree-truncation fallback, token confidentiality, and
diagnostic reporting.

### Add or change configuration

Update all of the following:

1. `backend/config.py`
2. `.env.example`
3. `deploy/eks/configmap.yaml` or the secret documentation
4. `docs/configuration-reference.md`
5. Relevant setup, deployment, and runbook instructions

### Change the production image

Update the pinned base-image references in `Dockerfile`, rebuild, run the full
verification suite, scan the resulting image, and deploy using a new immutable
tag. Never reuse a tag for different image content.

## 11. Verification before every pull request

Windows:

```powershell
.\verify.ps1
kubectl kustomize deploy/eks
```

Useful focused commands:

```powershell
npm run lint
npm run build
.\.venv\Scripts\python.exe -m compileall -q backend
```

Git Bash or CI:

```bash
bash scripts/ci-verify.sh
npm run lint
npm run build
python -m compileall -q backend
```

For UI changes, test light and dark themes, desktop and narrow layouts, keyboard
focus, search, row disclosures, API navigation, and direct deep links.

For parser changes, test mock data plus at least one real OpenAPI JSON file and
one YAML file. Run `discovery-report.bat` when discovery behavior changes.

The repository does not currently contain a formal automated unit or integration
test suite. `verify.ps1` and `scripts/ci-verify.sh` provide compile, import,
credential-safety, feature-marker, and production-build checks; they do not
replace the manual UI, API, and deployment smoke tests above. Adding backend
route/parser tests and frontend component tests is a recommended next step.

## 12. CodePipeline and EKS release flow

The intended release flow is:

```text
GitHub CodeConnection
  -> CodeBuild verification
  -> Docker image build
  -> immutable image push to ECR
  -> generated api-catalog-manifests.yaml artifact
  -> manual approval
  -> CodePipeline V2 EKS deploy action
  -> smoke test
```

The first deployment requires these platform resources before the pods can
become ready:

- ECR repository named `api-catalog`
- EKS cluster and deploy-role access entry
- `api-catalog` namespace
- Internal ALB support through AWS Load Balancer Controller or EKS Auto Mode
- Internal hostname and matching ACM certificate
- GitHub egress from the pods
- AWS secret synchronization producing `api-catalog-secrets`
- ECR pull permission for the EKS workload infrastructure

`buildspec.yml` replaces the exact placeholder image in
`deploy/eks/deployment.yaml`. Do not casually change that placeholder without
updating the substitution command.

Complete procedures: [CodePipeline and CodeBuild](../deploy/codepipeline/README.md)
and [EKS Deployment](../deploy/eks/README.md).

## 13. Production operation

Primary checks:

```text
GET /api/health
GET /api/source-health
GET /api/catalog
```

`/api/health` does not call GitHub. `/api/source-health` does and should not be
polled aggressively. Forced discovery also calls GitHub extensively.

Monitor:

- Ready and unavailable replicas
- Pod restarts and OOM events
- ALB healthy targets and 5xx responses
- Application response time
- GitHub 401, 403, 429, timeout, and 5xx responses
- Automatic-refresh errors in `/api/health` and logs
- ECR and dependency vulnerability findings
- Secret-sync status and token expiration

Detailed procedures: [Operations Runbook](operations-runbook.md) and
[Troubleshooting](troubleshooting.md).

## 14. Maintenance schedule

Suggested cadence:

| Frequency | Work |
|---|---|
| Each change | Run verification, update docs, review generated manifests |
| Monthly | Review dependency alerts, image findings, logs, and GitHub rate limits |
| Quarterly | Upgrade dependencies and base images in a test branch; exercise rollback |
| Token policy cadence | Rotate GitHub token and refresh password, then roll out pods |
| Annually or after platform changes | Review network boundary, IAM, ALB, TLS, secret synchronization, and recovery procedure |

Preserve committed lockfiles and use `npm ci` for reproducible installs. Review
dependency changes rather than deleting lockfiles to solve upgrade conflicts.

## 15. Backup, recovery, and rollback

There is no application database to back up. Durable sources are:

- Git repository and history
- GitHub OpenAPI source repository
- ECR image history
- AWS Secrets Manager secret
- EKS and pipeline infrastructure configuration
- Internal DNS and ACM configuration

To roll back, redeploy the previous immutable ECR image through the pipeline or
restore the preceding Deployment revision, then verify health, GitHub access,
catalog rendering, and internal routing.

If every pod is lost, redeployment reconstructs the catalog from GitHub.

## 16. New-owner handoff checklist

- [ ] Can clone and run mock mode locally
- [ ] Can run the full verification suite
- [ ] Knows the source GitHub repository and owning team
- [ ] Knows the EKS cluster, namespace, AWS account, and Region
- [ ] Can locate the ECR repository and CodePipeline
- [ ] Can locate the `api-catalog-secrets` AWS secret without viewing values unnecessarily
- [ ] Knows who owns External Secrets Operator and the `ClusterSecretStore`
- [ ] Knows the internal hostname, ACM certificate, and ALB/network owner
- [ ] Can inspect pod, ingress, pipeline, and application logs
- [ ] Can rotate the GitHub token and roll out pods
- [ ] Can deploy and roll back an immutable image
- [ ] Understands that SSO and raw-spec access are intentionally absent
- [ ] Has recorded support, escalation, and on-call ownership outside this repository
