# Configuration Reference

Configuration is read from process environment variables. Local scripts load the root `.env`.

## Catalog provider

### `CATALOG_SOURCE`

Selects the runtime provider:

```env
CATALOG_SOURCE=github
```

Allowed values are `github` and `mock`. Mock mode reads
`backend/mock_catalog.json` and does not require GitHub credentials.

## Required GitHub values

### `GITHUB_REPOSITORY_URL`

Repository root URL.

Examples:

```env
GITHUB_REPOSITORY_URL=https://github.com/company/documentation-repo
GITHUB_REPOSITORY_URL=https://github.company.com/company/documentation-repo
```

The application automatically determines the REST API base URL.

### `GITHUB_ACCESS_TOKEN`

Token used for backend GitHub API requests.

```env
GITHUB_ACCESS_TOKEN=github_pat_...
```

`GITHUB_TOKEN` remains a backwards-compatible alias when `GITHUB_ACCESS_TOKEN` is empty.

Do not expose either variable to Vite or browser code.

## GitHub scan settings

### `GITHUB_SEARCH_ROOT`

Optional repository directory prefix.

```env
GITHUB_SEARCH_ROOT=services/apis
```

An empty value scans the full repository tree.

### `GITHUB_SPEC_EXTENSIONS`

Comma-separated candidate extensions.

Default:

```env
GITHUB_SPEC_EXTENSIONS=.json,.yml,.yaml
```

Values without a leading period are normalized.

### `GITHUB_SCAN_WORKERS`

Number of concurrent candidate-validation workers.

Default:

```env
GITHUB_SCAN_WORKERS=8
```

Minimum: `1`  
Maximum: `24`

### `GITHUB_API_VERSION`

GitHub REST API version header.

Default:

```env
GITHUB_API_VERSION=2022-11-28
```

Review this value against the GitHub environment's supported API versions before changing it.

### `GITHUB_REQUEST_TIMEOUT_SECONDS`

Timeout for one GitHub request.

Default:

```env
GITHUB_REQUEST_TIMEOUT_SECONDS=30
```

Minimum: `1`

### `GITHUB_MAX_RETRIES`

Maximum retry count for retryable responses.

Default:

```env
GITHUB_MAX_RETRIES=3
```

Minimum: `0`  
Maximum: `8`

Retryable cases include:

- HTTP 429
- Selected 5xx responses
- Rate-limited HTTP 403
- Network failures

### `GITHUB_RETRY_BUFFER_SECONDS`

Additional delay added to retry timing.

Default:

```env
GITHUB_RETRY_BUFFER_SECONDS=1
```

Minimum: `0`

## Application settings

### `APP_ENV`

Environment label returned by `/api/health`.

Local default:

```env
APP_ENV=development
```

Docker production value:

```env
APP_ENV=production
```

### `CATALOG_HOST`

Flask bind host.

Local default:

```env
CATALOG_HOST=127.0.0.1
```

Container value:

```env
CATALOG_HOST=0.0.0.0
```

### `CATALOG_PORT`

Backend port.

Default:

```env
CATALOG_PORT=8080
```

### `CATALOG_CACHE_TTL_SECONDS`

Process-local catalog cache duration.

Default:

```env
CATALOG_CACHE_TTL_SECONDS=900
```

Set to `0` to disable time-based reuse, although each request may then trigger an expensive repository scan.

### Automatic catalog refresh

EKS enables an automatic forced refresh in every pod at the configured hours.
Defaults:

```env
CATALOG_AUTO_REFRESH_ENABLED=false
CATALOG_REFRESH_HOURS=0,6,12,18
CATALOG_REFRESH_TIMEZONE=UTC
```

The EKS ConfigMap uses `CATALOG_CACHE_TTL_SECONDS=21600` to align normal cache
expiry with this six-hour schedule.

`CATALOG_REFRESH_HOURS` accepts comma-separated wall-clock hours from `0` to
`23`. The timezone must be an IANA timezone name available in the container,
such as `UTC` or `America/New_York`. Keep the feature enabled in EKS so every
replica refreshes its process-local cache.

### `CATALOG_REFRESH_PASSWORD`

Required to use any API route with `refresh=true`. The frontend requests this
value only when a user selects **Refresh catalog**, sends it in the
`X-Catalog-Refresh-Password` header, and does not retain it.

```env
CATALOG_REFRESH_PASSWORD=replace-with-refresh-password
```

Treat this value as a secret. Keep it in the ignored local `.env` during
development and inject it from AWS Secrets Manager in EKS.

## Development-only frontend setting

### `VITE_API_TARGET`

Optional Vite proxy target.

Default behavior:

```text
http://<CATALOG_HOST>:<CATALOG_PORT>
```

Example:

```env
VITE_API_TARGET=http://127.0.0.1:8080
```

Do not put secrets in any `VITE_*` variable because Vite variables can be bundled into frontend assets.

## Example local `.env`

```env
APP_ENV=development
CATALOG_SOURCE=github

GITHUB_REPOSITORY_URL=https://github.com/company/documentation-repo
GITHUB_ACCESS_TOKEN=github_pat_replace_me
GITHUB_SEARCH_ROOT=
GITHUB_SPEC_EXTENSIONS=.json,.yml,.yaml
GITHUB_SCAN_WORKERS=8
GITHUB_API_VERSION=2022-11-28
GITHUB_REQUEST_TIMEOUT_SECONDS=30
GITHUB_MAX_RETRIES=3
GITHUB_RETRY_BUFFER_SECONDS=1

CATALOG_HOST=127.0.0.1
CATALOG_PORT=8080
CATALOG_CACHE_TTL_SECONDS=900
CATALOG_AUTO_REFRESH_ENABLED=false
CATALOG_REFRESH_HOURS=0,6,12,18
CATALOG_REFRESH_TIMEZONE=UTC
CATALOG_REFRESH_PASSWORD=replace-with-refresh-password
```

## Example EKS environment configuration

Normal environment variables:

```text
APP_ENV=production
CATALOG_HOST=0.0.0.0
CATALOG_PORT=8080
CATALOG_SOURCE=github
GITHUB_REPOSITORY_URL=https://github.com/company/documentation-repo
GITHUB_SPEC_EXTENSIONS=.json,.yml,.yaml
GITHUB_SCAN_WORKERS=8
CATALOG_CACHE_TTL_SECONDS=21600
CATALOG_AUTO_REFRESH_ENABLED=true
CATALOG_REFRESH_HOURS=0,6,12,18
CATALOG_REFRESH_TIMEZONE=UTC
```

Secret injection:

```text
AWS Secrets Manager secret: api-catalog-secrets
  GITHUB_ACCESS_TOKEN
  CATALOG_REFRESH_PASSWORD

Kubernetes namespace: api-catalog
Kubernetes Secret: api-catalog-secrets
```


## Application access

The application has no authentication or session configuration. Restrict hosted access with the internal ALB, private DNS, routing, security groups, VPN, or other company-approved network controls.
