#!/usr/bin/env bash
set -euo pipefail

secret_pattern='AKIA[0-9A-Z]{16}|ghp_[A-Za-z0-9]{36}|github_pat_[A-Za-z0-9_]{70,}|-----BEGIN (RSA |EC |OPENSSH )?PRIVATE KEY-----'

if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  if git ls-files --error-unmatch .env >/dev/null 2>&1; then
    echo "ERROR: .env is tracked by Git. Remove it before building." >&2
    exit 1
  fi

  tracked_files="$(git ls-files)"
  if printf '%s\n' "$tracked_files" | grep -E '(^|/)(node_modules|dist|__pycache__|\.venv)(/|$)' >/dev/null; then
    echo "ERROR: generated dependencies, build output, or virtual environments are tracked." >&2
    exit 1
  fi

  if git grep -I -n -E "$secret_pattern" -- . \
    ':(exclude)docs/**' ':(exclude)README.md' ':(exclude)deploy/**/*.example.yaml'; then
    echo "ERROR: a credential-like value was found in a tracked production file." >&2
    exit 1
  fi
else
  if [[ -e .env ]]; then
    echo "ERROR: the source artifact contains .env." >&2
    exit 1
  fi

  if find . -type d \( -name node_modules -o -name dist -o -name __pycache__ -o -name .venv \) -print -quit | grep -q .; then
    echo "ERROR: the source artifact contains generated dependencies, build output, or a virtual environment." >&2
    exit 1
  fi

  if grep -RInE "$secret_pattern" . \
    --exclude='*.example.yaml' \
    --exclude-dir=.git \
    --exclude-dir=docs; then
    echo "ERROR: a credential-like value was found in the source artifact." >&2
    exit 1
  fi
fi

required_files=(
  Dockerfile
  buildspec.yml
  deploy/eks/kustomization.yaml
)

for required_file in "${required_files[@]}"; do
  if [[ ! -f "$required_file" ]]; then
    echo "ERROR: required release file is missing: $required_file" >&2
    exit 1
  fi
done

echo "Repository safety checks passed."
