# CodePipeline and CodeBuild Guide

The intended delivery path is:

```text
GitHub CodeConnection
  -> CodeBuild verify/build/push
  -> manual approval
  -> CodePipeline V2 Amazon EKS deploy
  -> smoke test
```

The repository supplies `buildspec.yml` and Kubernetes manifests. It does not
create the AWS pipeline, IAM roles, EKS cluster, ECR repository, artifact
bucket, DNS, certificate, or secret infrastructure.

## 1. Prerequisites

- Existing EKS cluster and approved target namespace
- ECR repository named `api-catalog`
- CodeConnections GitHub App connection restricted to this repository
- CodePipeline artifact bucket
- Privileged Linux CodeBuild project
- CodeBuild service role
- CodePipeline service role or dedicated EKS action role
- EKS access entry for the deploy identity
- Runtime secret synchronization completed before the first deploy
- Internal ALB, private DNS, ACM, and network ownership established

Keep these resources in the same Region unless the company has deliberately
designed cross-account or cross-Region artifact and deployment roles.

## 2. Source stage

Configure:

```text
Provider: GitHub via AWS CodeConnections
Repository: this application repository
Branch: approved deployment branch, normally main
Output artifact: SourceArtifact
Change detection: enabled
```

Restrict the GitHub App installation to this repository. The CodeConnection is
for pipeline source retrieval and is separate from `GITHUB_ACCESS_TOKEN`, which
the running catalog uses to read the OpenAPI source repository.

Do not add the runtime GitHub token to the source action.

## 3. ECR repository

Create `api-catalog` with:

- Immutable tags
- Scan on push
- Encryption according to company policy
- Lifecycle policy for old unreferenced images

The build tags images with the first 12 characters of
`CODEBUILD_RESOLVED_SOURCE_VERSION`.

## 4. CodeBuild project

Configure:

```text
Source: CodePipeline
Buildspec: buildspec.yml
Environment: current AWS-managed Linux image
Privileged mode: enabled
Output artifact: BuildArtifact
```

The image must provide Bash, Docker, Node.js 22, Python 3.13, AWS CLI, and
`kubectl`. If the selected managed image does not include a compatible
`kubectl`, install a pinned version in the build environment before using this
buildspec.

Plaintext build variables:

```text
AWS_ACCOUNT_ID=<deployment account ID>
ECR_REPOSITORY=api-catalog
```

CodeBuild supplies `AWS_DEFAULT_REGION`. Neither runtime secret belongs in
CodeBuild:

```text
GITHUB_ACCESS_TOKEN
CATALOG_REFRESH_PASSWORD
```

### CodeBuild role responsibilities

Grant only what is needed for:

- CloudWatch build logs
- Reading source and writing build artifacts in the pipeline bucket
- `ecr:GetAuthorizationToken`
- ECR layer upload, image push, and necessary image inspection actions scoped
  to the `api-catalog` repository where supported

CodeBuild does not need access to the runtime Secrets Manager secret.

## 5. What `buildspec.yml` does

Install phase:

1. Installs root npm dependencies with `npm ci`.
2. Installs frontend dependencies with `npm ci`.
3. Installs backend Python requirements.

Pre-build phase:

1. Validates required AWS variables.
2. Runs `scripts/ci-verify.sh` to reject tracked secrets and generated files.
3. Runs frontend lint and build.
4. Compiles Python and checks installed dependencies.
5. Authenticates Docker to ECR.
6. Calculates immutable image tag and URI.

Build phase:

1. Builds the multi-stage Docker image.
2. Adds revision/version OCI labels.
3. Pushes the image to ECR.

Post-build phase:

1. Copies `deploy/eks` into the pipeline artifact.
2. Replaces the exact placeholder image with the immutable ECR URI.
3. Renders Kustomize output to `api-catalog-manifests.yaml`.
4. Produces `imageDetail.json` for downstream tooling.

Build output layout:

```text
api-catalog-manifests.yaml
imageDetail.json
deploy/eks/...
```

If the image-placeholder replacement or Kustomize rendering fails, do not
bypass the check manually; correct the source or buildspec.

## 6. Approval stage

Add manual approval between build and production deployment. The approver
should review:

- Commit and pull request
- Verification results
- Image URI and scan result
- Rendered manifest artifact
- Configuration, secret-name, IAM, ingress, and resource changes
- Rollback image URI

## 7. EKS deploy stage

Use a CodePipeline V2 Amazon EKS action:

```text
Deployment tool: Kubectl
Cluster name: <target cluster>
Input artifact: BuildArtifact
Manifest file: api-catalog-manifests.yaml
Namespace: leave blank because resources specify api-catalog
```

For a private EKS API endpoint, configure the action with approved VPC subnets
and security groups that can reach the cluster and pipeline artifact services.

The deploy identity needs:

- IAM permissions required by the EKS action, including cluster description
- An EKS access entry
- Kubernetes permissions for the resources in the rendered manifest

The manifest currently includes the cluster-scoped Namespace resource. For
strict namespace-only access, have the platform team pre-create the namespace
and remove `namespace.yaml` from the pipeline bundle.

## 8. Smoke-test stage

Use an approved VPC-connected build or test action capable of reaching the
internal hostname. Verify:

```text
GET /api/health              -> 200
GET /api/source-health       -> 200
GET /api/catalog             -> expected non-zero API count
GET /                        -> [CSAA] API Catalog HTML
```

Also verify the Kubernetes rollout and ALB target health. Do not use forced
discovery as a high-frequency smoke test because it downloads repository files.

## 9. Pipeline role separation

A practical same-account model is:

- CodePipeline role: orchestrates actions and uses the GitHub connection
- CodeBuild role: logs, artifacts, and ECR build/push only
- EKS deploy action role: cluster description and Kubernetes deployment access
- External Secrets role: reads only AWS secret `api-catalog-secrets`
- EKS workload infrastructure role: pulls the ECR image

Do not combine all responsibilities into one administrator role.

## 10. First pipeline run

Before releasing the first execution:

1. Confirm AWS secret `api-catalog-secrets` contains both required keys.
2. Confirm Kubernetes Secret `api-catalog-secrets` exists in namespace `api-catalog`.
3. Confirm ConfigMap repository URL is correct.
4. Confirm internal hostname and ACM ARN are correct.
5. Confirm EKS deploy access entry and Kubernetes permissions.
6. Confirm pod egress to GitHub and image pull from ECR.
7. Confirm the CodeBuild image has all required tools.
8. Run the pipeline and inspect every stage output.
9. Complete EKS and application validation from the deployment guide.

## 11. Rollback

Keep every deployment tied to an immutable image URI. To roll back:

1. Select the last known-good Git commit and ECR image.
2. Run the approved rollback pipeline or redeploy its manifest artifact.
3. Wait for Kubernetes rollout completion.
4. Repeat smoke tests.
5. Preserve failed execution logs and image metadata.

Never rebuild an old tag and assume it is equivalent to the original image.

## 12. Pipeline troubleshooting

### Docker daemon unavailable

Confirm the CodeBuild project uses Linux and privileged mode.

### ECR login or push denied

Check `AWS_ACCOUNT_ID`, Region, repository name, and CodeBuild role ECR actions.

### `kubectl: command not found`

Use a managed build image containing `kubectl` or install a pinned version in a
controlled install step.

### Image placeholder not replaced

The exact placeholder in `deployment.yaml` no longer matches `buildspec.yml`.
Update both together and verify the rendered artifact.

### EKS deploy action cannot connect

Check pipeline type V2, cluster name, `eks:DescribeCluster`, VPC configuration
for a private endpoint, EKS access entry, and Kubernetes permissions.

### Pods remain pending or fail startup

Check capacity, image pull, ConfigMap, Kubernetes Secret, security context,
resource requests, GitHub egress, and pod events. Continue with the
[EKS Deployment Guide](../eks/README.md) and
[Troubleshooting](../../docs/troubleshooting.md).
