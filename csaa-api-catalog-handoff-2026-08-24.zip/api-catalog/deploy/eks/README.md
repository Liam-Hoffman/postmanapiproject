# EKS Deployment Guide

This guide covers the Kubernetes side of deploying the `[CSAA] API Catalog`.
The pipeline build and deploy-action configuration is documented in
[CodePipeline and CodeBuild](../codepipeline/README.md).

## Security requirement

The application has no SSO, user session, or per-user authorization. The ALB
must remain internal and reachable only through approved company networking,
private DNS, routing, VPN, and security groups.

Full raw OpenAPI source delivery is disabled. Normalized internal API metadata,
routes, fields, examples, owners, and server URLs remain visible to anyone who
can reach the application.

## Resources in this directory

| File | Purpose |
|---|---|
| `namespace.yaml` | Creates namespace `api-catalog` |
| `serviceaccount.yaml` | Pod service account; Kubernetes API token mounting is disabled |
| `configmap.yaml` | Non-secret runtime configuration |
| `deployment.yaml` | Two replicas, probes, security context, resources, and image placeholder |
| `service.yaml` | Internal ClusterIP service on port 80 |
| `ingress-alb.yaml` | Internal HTTPS ALB ingress |
| `pdb.yaml` | Keeps at least one replica available during voluntary disruption |
| `external-secret.example.yaml` | Optional AWS Secrets Manager synchronization example |
| `secret.example.yaml` | Development-only Kubernetes Secret shape; never add real values |
| `kustomization.yaml` | Production manifest bundle used by CodeBuild |

The example secret files are deliberately not included in `kustomization.yaml`.
Secret synchronization is platform-specific and must be established before the
first application deployment.

## Required platform resources

- Existing EKS cluster in the intended AWS account and Region
- Worker nodes, Fargate, or EKS Auto Mode capacity
- ECR repository named `api-catalog`
- ECR image-pull permissions for the workload infrastructure
- AWS Load Balancer Controller or the corresponding EKS Auto Mode capability
- Internal DNS hostname
- Matching ACM certificate in the ALB Region
- Private subnets and approved security groups
- Outbound HTTPS and DNS access from pods to GitHub or GitHub Enterprise
- CodePipeline deploy-role EKS access entry
- Approved AWS Secrets Manager to Kubernetes Secret integration

## Runtime names

```text
Kubernetes namespace:       api-catalog
Deployment:                 api-catalog
Service:                    api-catalog
Ingress:                    api-catalog
AWS Secrets Manager secret: api-catalog-secrets
Kubernetes Secret:          api-catalog-secrets
Kubernetes ConfigMap:       api-catalog-config
```

## Required secrets

Create the AWS Secrets Manager secret `api-catalog-secrets` with two key/value
pairs:

```text
GITHUB_ACCESS_TOKEN=<read-only repository token>
CATALOG_REFRESH_PASSWORD=<shared manual-refresh password>
```

Using the AWS-managed KMS key `aws/secretsmanager` is appropriate for typical
same-account deployments unless company policy requires a customer-managed key.
Cross-account retrieval requires separate key and resource-policy planning.

Do not place secret values in Git, the ConfigMap, CodeBuild plaintext variables,
pipeline artifacts, container build arguments, or any `VITE_*` variable.

### External Secrets Operator path

The provided `external-secret.example.yaml` expects:

- External Secrets Operator installed in the cluster
- A `ClusterSecretStore` named `aws-secrets-manager`
- Operator workload identity allowed to read AWS secret `api-catalog-secrets`

Apply it after the namespace exists:

```bash
kubectl apply -f deploy/eks/namespace.yaml
kubectl apply -f deploy/eks/external-secret.example.yaml
```

Verify synchronization without printing secret values:

```bash
kubectl -n api-catalog get externalsecret api-catalog-secrets
kubectl -n api-catalog get secret api-catalog-secrets
```

If the EKS team uses the Secrets Store CSI Driver or another approved method,
adapt the workload integration while preserving the final Kubernetes Secret
name and keys expected by `deployment.yaml`.

## Configure the manifests

### Catalog source

Edit `configmap.yaml`:

```yaml
GITHUB_REPOSITORY_URL: https://github.com/company/documentation-repo
```

Optionally narrow scanning:

```yaml
GITHUB_SEARCH_ROOT: services/apis
```

The production provider must remain:

```yaml
CATALOG_SOURCE: github
```

### Internal hostname and certificate

Edit `ingress-alb.yaml`:

```yaml
alb.ingress.kubernetes.io/certificate-arn: <real ACM certificate ARN>
```

And:

```yaml
host: <real internal DNS hostname>
```

Keep:

```yaml
alb.ingress.kubernetes.io/scheme: internal
alb.ingress.kubernetes.io/target-type: ip
```

### Container image placeholder

The committed Deployment intentionally contains:

```text
123456789012.dkr.ecr.us-east-1.amazonaws.com/api-catalog:REPLACE_WITH_IMMUTABLE_TAG
```

`buildspec.yml` replaces this exact string inside the build artifact. Do not
change it without updating and testing the buildspec substitution.

## Refresh configuration

The EKS ConfigMap enables process-local automatic refresh:

```env
CATALOG_CACHE_TTL_SECONDS=21600
CATALOG_AUTO_REFRESH_ENABLED=true
CATALOG_REFRESH_HOURS=0,6,12,18
CATALOG_REFRESH_TIMEZONE=UTC
```

Every pod refreshes independently at `00:00`, `06:00`, `12:00`, and `18:00`
UTC. A failed scheduled refresh keeps the previous successful cache. Check the
`automaticRefresh` object in `/api/health` for the next run and latest error.

Manual refresh is protected by `CATALOG_REFRESH_PASSWORD`. All routes using
`refresh=true` enforce the password supplied through
`X-Catalog-Refresh-Password`.

## Deploy-role access

Use an EKS access entry for the IAM role used by the CodePipeline EKS action.
For least privilege, have the platform team pre-create `api-catalog` and grant
the role permissions only within that namespace.

The current Kustomize bundle includes `namespace.yaml`. A role restricted only
to namespaced resources may be unable to apply that cluster-scoped Namespace
resource. Choose one controlled model:

1. Allow the deploy role to manage this namespace resource; or
2. Have the platform team own the namespace and remove `namespace.yaml` from the
   pipeline Kustomize bundle.

Do not grant cluster-admin permanently just to avoid designing namespace-scoped
deployment access.

## First deployment order

1. Confirm cluster capacity, load-balancer support, egress, certificate, and DNS ownership.
2. Create ECR repository `api-catalog`.
3. Create AWS secret `api-catalog-secrets`.
4. Create namespace `api-catalog` if platform-owned.
5. Establish secret synchronization and confirm Kubernetes Secret `api-catalog-secrets` exists.
6. Update repository URL, hostname, and certificate placeholders.
7. Render and review manifests.
8. Run CodePipeline through build, approval, and EKS deploy.
9. Wait for the Deployment rollout.
10. Complete or verify private DNS aliasing to the internal ALB.
11. Run the validation checklist below.

If the Kubernetes Secret does not exist, pods cannot start because the
Deployment uses a non-optional `secretRef`.

## Manual deployment for validation

The production path should use CodePipeline. An authorized operator can perform
a controlled manual validation after replacing the image placeholder:

```bash
kubectl kustomize deploy/eks
kubectl apply -k deploy/eks
kubectl -n api-catalog rollout status deployment/api-catalog
```

Never apply the committed image placeholder to production.

## Post-deployment validation

```bash
kubectl -n api-catalog get deployment,pods,service,ingress,pdb
kubectl -n api-catalog rollout status deployment/api-catalog
kubectl -n api-catalog logs deployment/api-catalog --tail=200
```

Confirm:

- Two pods are ready
- ALB targets are healthy
- Ingress scheme is internal
- HTTPS certificate and private DNS name are correct
- `/api/health` reports `provider: github`
- `/api/health` reports automatic refresh enabled and the correct schedule
- `/api/source-health` reports authenticated repository access
- Catalog API count and UI data are expected
- API and endpoint searches work
- Manual refresh rejects a wrong password and accepts the configured password
- GitHub source links point to the intended repository

## Secret rotation

Updating AWS Secrets Manager does not replace environment variables already
loaded by running pods.

1. Update the relevant key in AWS secret `api-catalog-secrets`.
2. Confirm the Kubernetes Secret synchronized.
3. Roll out the Deployment.
4. Confirm `/api/source-health` or manual refresh behavior.
5. Revoke the previous credential after successful validation.

## Rollback

Prefer immutable image rollback:

1. Identify the last known-good ECR image URI and digest.
2. Redeploy that image through the approved pipeline or update the Deployment.
3. Wait for rollout completion.
4. Repeat health, source, UI, and ALB validation.
5. Preserve the failed image, pipeline execution, and logs for investigation.

Kubernetes rollout history can assist diagnosis, but the release record should
always retain the exact immutable ECR image URI.

## Ownership checklist

Record these owners in the company system of record:

- Application code and API catalog product
- Source OpenAPI repository
- EKS cluster and namespace
- CodePipeline, CodeBuild, and ECR
- External secret integration and IAM
- Internal ALB, DNS, certificate, and networking
- GitHub token lifecycle
- Operational escalation and on-call response

