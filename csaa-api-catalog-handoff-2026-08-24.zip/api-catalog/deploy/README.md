# Deployment Assets

Start with the [Project Handoff Guide](../docs/project-handoff-guide.md) for the
complete system context.

- [`eks/`](eks/) contains the Kubernetes manifests and EKS deployment guide.
- [`codepipeline/`](codepipeline/) documents GitHub, CodeBuild, ECR, and EKS pipeline configuration.

The application has no authentication layer. The EKS Ingress/ALB terminates TLS and forwards traffic, so keep it internal and apply company network-access controls.
