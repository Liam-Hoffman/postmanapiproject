import type { ApiItem, CatalogPayload } from '../types'

async function getJson<T>(url: string, extraHeaders: Record<string, string> = {}): Promise<T> {
  const response = await fetch(url, {
    headers: { Accept: 'application/json', ...extraHeaders },
    credentials: 'same-origin',
  })

  let payload: Record<string, unknown>
  try {
    payload = await response.json() as Record<string, unknown>
  } catch {
    payload = {}
  }

  if (!response.ok) {
    throw new Error(
      String(payload.details || payload.error || `HTTP ${response.status}`),
    )
  }
  return payload as T
}

export const catalogApi = {
  getCatalog: (refresh = false, refreshPassword = '') => getJson<CatalogPayload>(
    `/api/catalog${refresh ? '?refresh=true' : ''}`,
    refresh ? { 'X-Catalog-Refresh-Password': refreshPassword } : {},
  ),
  getSpec: (id: string) => getJson<ApiItem>(`/api/specs/${encodeURIComponent(id)}`),
}
