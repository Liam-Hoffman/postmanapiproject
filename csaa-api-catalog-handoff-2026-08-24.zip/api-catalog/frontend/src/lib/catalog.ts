import type { ApiItem, Operation } from '../types'

export function apiDisplayName(api: ApiItem): string {
  const name = api.name || 'Unnamed API'
  const majorVersion = String(api.version || '').trim().match(/\d+/)?.[0]
  if (!majorVersion) return name
  if (
    new RegExp(`\\bv\\s*${majorVersion}\\b`, 'i').test(name) ||
    new RegExp(`\\bversion\\s*${majorVersion}\\b`, 'i').test(name)
  ) return name
  return `${name} V${majorVersion}`
}

export function apiSlug(api: ApiItem): string {
  const name = apiDisplayName(api)
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')
  return `${name}-${api.id}`
}

export function operationAnchor(operation: Operation, index: number): string {
  const label = operation.operationId || operation.summary || operation.path || String(index)
  return `${operation.method.toLowerCase()}-${label
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')}`
}

export function operationSearchText(operation: Operation): string {
  return [
    operation.method,
    operation.path,
    operation.summary,
    operation.description,
    operation.operationId,
    ...(operation.tags || []),
    ...(operation.requestFields || []).flatMap(field => [
      field.path,
      field.name,
      field.description,
      field.type,
    ]),
  ].filter(Boolean).join(' ').toLowerCase()
}

export function matchingOperations(api: ApiItem, query: string): Operation[] {
  if (!query) return []
  return (api.operations || []).filter(operation => operationSearchText(operation).includes(query))
}

export function lifecycleTone(lifecycle?: string): string {
  const value = String(lifecycle || 'unspecified').trim().toLowerCase()
  if (['production', 'stable', 'active', 'ga'].includes(value)) return 'production'
  if (['beta', 'preview', 'experimental'].includes(value)) return 'beta'
  if (['deprecated', 'retired', 'sunset'].includes(value)) return 'deprecated'
  return 'draft'
}

export function providerLabel(provider?: string): string {
  if (provider === 'mock') return 'local mock data'
  if (provider === 'github') return 'GitHub'
  return provider || 'the configured source'
}
