# Postman API Catalog — React + Python

An internal API catalog with a React/TypeScript/Vite frontend and a Python/Flask backend. The backend keeps the Postman API key private, filters employee workspaces, applies rate limiting, caches catalog data, and lazily loads full API definitions.

## Local development

### Requirements

- Node.js 22+ with NPM
- Python 3.11+
- A Postman API key

### Setup

From the repository root, install the root development runner and frontend packages:

```bash
npm install
npm run install:frontend
```

Then:

1. Copy `.env.example` to `.env` and set `POSTMAN_API_KEY`.
2. Install backend dependencies:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r backend/requirements.txt
```

3. Install frontend dependencies:

```bash
cd frontend
npm install
```

4. Run both development servers from the repository root:

```bash
npm run dev
```

Or run them separately. Run the backend from the repository root:

```bash
python backend/run.py
```

5. In another terminal, run the frontend:

```bash
cd frontend
npm run dev
```

Open `http://localhost:5173`. Vite proxies `/api` requests to `http://127.0.0.1:8080`.

Windows users can also run `./start-dev.ps1`. macOS/Linux users can run `./start-dev.sh`.

## Production-style local test

Build the React application and let Flask serve it:

```bash
cd frontend
npm run build
cd ..
python backend/run.py
```

Open `http://localhost:8080`.

## Docker test

```bash
docker compose up --build
```

Open `http://localhost:8080`.

## AWS-ready deployment path

The included multi-stage Dockerfile builds the React frontend and runs Flask behind Gunicorn. The image can be pushed to Amazon ECR and deployed to ECS Fargate behind an Application Load Balancer. In AWS, inject the Postman key from Secrets Manager rather than committing `.env`.

Ordinary web-app users do not need access to the AWS account. Authentication can later be added at the Application Load Balancer using your company OIDC provider, or through Cognito for SAML federation. Local development remains independent of SSO.

## Project layout

```text
backend/             Flask API and Postman integration
frontend/            React + TypeScript + Vite application
Dockerfile           Production container build
docker-compose.yml   Local production-style container test
.env.example         Local configuration template
```

## Frontend behavior retained

- Stripe-inspired left sidebar
- Main API search
- Search-aware workspace dropdown
- Workspace, lifecycle, and sorting controls
- Stable API cards
- Lazy detail loading
- Detail search
- Overview and specification tabs
- Request fields and generated request examples
- No request-body warning for GET, HEAD, OPTIONS, or TRACE
- Dark theme


## Operation and field navigation

- Operations are grouped in a fixed HTTP-method order and each method group can be collapsed.
- Required request fields use a red left accent, red asterisk, and explicit Required badge.
- Object and array-object request fields can be expanded to reveal nested properties.
- Searching inside an API automatically reveals nested matching field content.

## Documentation explorer redesign

The React frontend now uses React Router and a denser documentation-oriented layout:

- Only workspaces whose names start with `[CSAA]` are included in the catalog.
- The main sidebar and catalog header remain sticky while API rows scroll.
- APIs are grouped into collapsible workspace sections instead of large cards.
- Each API has a route such as `/catalog/payment-api-<id>`, so browser history, bookmarks, and shared links work.
- API pages use a split pane with a sticky operation navigation tree and reference content.
- Operations remain consistently grouped and collapsible by HTTP method.
- Individual operations have URL fragments that can be copied and shared.
- Nested object fields remain expandable, and required fields retain red emphasis.

During local development, Vite handles route fallback automatically. In production, the Flask fallback route returns `index.html` for application routes, so direct links work in Docker and ECS as well.

## Navigation cleanup

- Removed the lifecycle dropdown from the main catalog sidebar.
- The catalog sidebar now focuses on API search, `[CSAA]` workspace filtering, sorting, scope, and counts.
- The global catalog sidebar is hidden on individual API routes so it does not compete with the API-specific operation search.
- API routes use the operation navigator as their only left-side navigation.
- Sticky main headers now use a safe viewport offset, full border, and rounded corners to prevent clipping at the top of the page.


## Reduced field hover noise

API request-field rows no longer highlight on mouse hover. Visual hover feedback is limited to explicitly interactive object-expansion controls, while required-field emphasis remains unchanged.


## Detail-page sticky header fix

The detailed API view now reserves space below its sticky top header. Operation sections and URL-fragment targets use matching scroll offsets, so headings and content remain visible rather than scrolling underneath the header.


## Enhanced API detail navigation

The detailed API view now includes a prominent Back to Catalog button, breadcrumb context, and a compact API summary above the operation navigation. The summary and operation tree stay visible together on desktop while the main specification content scrolls independently.
