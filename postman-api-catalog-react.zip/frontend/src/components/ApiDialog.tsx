import { useEffect, useMemo, useState } from 'react'
import type { ApiItem, Operation } from '../types'
import { formatDate, htmlToText } from '../lib/text'

function operationText(op: Operation) {
  return [op.method, op.path, op.summary, op.description, op.operationId, ...(op.tags || []), ...(op.requestFields || []).flatMap(f => [f.path, f.name, f.location, f.type, f.description])].filter(Boolean).join(' ').toLowerCase()
}

export function ApiDialog({ api, loading, error, onClose }: { api: ApiItem | null; loading: boolean; error: string; onClose(): void }) {
  const [tab, setTab] = useState<'overview' | 'spec'>('overview')
  const [search, setSearch] = useState('')
  useEffect(() => { setTab('overview'); setSearch('') }, [api?.id])
  const query = search.trim().toLowerCase()
  const operations = useMemo(() => (api?.operations || []).filter(op => !query || operationText(op).includes(query)), [api, query])
  if (!api) return null

  return <div className="dialog-backdrop" role="presentation" onMouseDown={e => { if (e.target === e.currentTarget) onClose() }}>
    <section className="detail-dialog" role="dialog" aria-modal="true" aria-label={`${api.name} details`}>
      <header className="detail-header">
        <div><div className="eyebrow">{api.workspace.name}</div><h2>{api.name}</h2></div>
        <div className="detail-actions">
          <button className={tab === 'overview' ? 'active' : 'secondary'} onClick={() => setTab('overview')}>Overview</button>
          <button className={tab === 'spec' ? 'active' : 'secondary'} onClick={() => setTab('spec')}>Specification</button>
          <button className="secondary" onClick={() => navigator.clipboard.writeText(api.definitionText || '')}>Copy spec</button>
          <button className="secondary" onClick={onClose}>Close</button>
        </div>
        <input type="search" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search this API…" />
      </header>
      <div className="detail-content">
        {loading && <p className="notice">Loading this API definition from Postman…</p>}
        {error && <p className="notice error">{error}</p>}
        {!loading && !error && tab === 'spec' && <pre className="spec"><code>{api.definitionText || 'Specification unavailable.'}</code></pre>}
        {!loading && !error && tab === 'overview' && <>
          <div className="detail-summary">
            <div><strong>Version</strong><span>{api.version || 'Unspecified'}</span></div>
            <div><strong>Owner</strong><span>{api.owner || 'Unspecified'}</span></div>
            <div><strong>Operations</strong><span>{api.operationCount ?? 0}</span></div>
            <div><strong>Updated</strong><span>{formatDate(api.updatedAt)}</span></div>
          </div>
          {api.description && (!query || htmlToText(api.description).toLowerCase().includes(query)) && <section><h3>Description</h3><p>{htmlToText(api.description)}</p></section>}
          {!!api.servers?.filter(s => !query || s.toLowerCase().includes(query)).length && <section><h3>Servers</h3><div className="server-list">{api.servers.filter(s => !query || s.toLowerCase().includes(query)).map(s => <code key={s}>{s}</code>)}</div></section>}
          <section><h3>Operations</h3>{operations.length === 0 ? <p>No matching operations were found.</p> : operations.map((op, i) => <article className="operation" key={`${op.method}-${op.path}-${i}`}>
            <div className="operation-title"><span className="method">{op.method}</span><code>{op.path}</code></div>
            <h4>{op.summary || op.operationId || 'No summary'}</h4>
            {op.description && <p>{htmlToText(op.description)}</p>}
            {!!op.requestFields?.length && <div className="table-wrap"><table><thead><tr><th>Field</th><th>In</th><th>Type</th><th>Required</th></tr></thead><tbody>{op.requestFields.map((f, n) => <tr key={`${f.path || f.name}-${n}`}><td><code>{f.path || f.name}</code>{f.description && <small>{htmlToText(f.description)}</small>}</td><td>{f.location || 'body'}</td><td><code>{f.type || 'unknown'}</code></td><td>{f.required ? 'Required' : 'Optional'}</td></tr>)}</tbody></table></div>}
            {op.requestBodyExample ? <div className="example"><strong>Example request body</strong><pre><code>{typeof op.requestBodyExample.example === 'string' ? op.requestBodyExample.example : JSON.stringify(op.requestBodyExample.example, null, 2)}</code></pre></div> : !['GET','HEAD','OPTIONS','TRACE'].includes(op.method.toUpperCase()) && <p className="muted">No request body is defined for this operation.</p>}
          </article>)}</section>
        </>}
      </div>
    </section>
  </div>
}
