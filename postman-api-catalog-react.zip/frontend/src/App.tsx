import { useEffect, useMemo, useState } from 'react'
import { ApiCard } from './components/ApiCard'
import { ApiDialog } from './components/ApiDialog'
import { Sidebar } from './components/Sidebar'
import { catalogApi } from './lib/api'
import { searchable } from './lib/text'
import type { ApiItem, CatalogPayload } from './types'

export default function App() {
  const [payload, setPayload] = useState<CatalogPayload>({ apis: [], apiCount: 0, workspaceCount: 0 })
  const [search, setSearch] = useState('')
  const [workspace, setWorkspace] = useState('')
  const [lifecycle, setLifecycle] = useState('')
  const [sort, setSort] = useState('name')
  const [loading, setLoading] = useState(true)
  const [status, setStatus] = useState('Loading workspace metadata…')
  const [selected, setSelected] = useState<ApiItem | null>(null)
  const [detailLoading, setDetailLoading] = useState(false)
  const [detailError, setDetailError] = useState('')

  async function load(refresh = false) {
    setLoading(true); setStatus('Loading workspace metadata…')
    try {
      const data = await catalogApi.getCatalog(refresh)
      setPayload(data); setStatus(`Showing ${data.apiCount} APIs`)
    } catch (error) { setStatus(error instanceof Error ? error.message : 'Unable to load catalog') }
    finally { setLoading(false) }
  }
  useEffect(() => { void load() }, [])

  const query = search.trim().toLowerCase()
  const searchMatches = useMemo(() => payload.apis.filter(api => (!query || searchable(api).includes(query)) && (!lifecycle || api.lifecycle === lifecycle)), [payload.apis, query, lifecycle])
  const workspaces = useMemo(() => [...new Map(searchMatches.map(api => [api.workspace.id, api.workspace])).values()].sort((a,b) => a.name.localeCompare(b.name)), [searchMatches])
  useEffect(() => { if (workspace && !workspaces.some(w => w.id === workspace)) setWorkspace('') }, [workspace, workspaces])
  const items = useMemo(() => {
    const result = searchMatches.filter(api => !workspace || api.workspace.id === workspace)
    return [...result].sort((a,b) => sort === 'updated' ? String(b.updatedAt || '').localeCompare(String(a.updatedAt || '')) : sort === 'operations' ? (b.operationCount ?? -1) - (a.operationCount ?? -1) : a.name.localeCompare(b.name))
  }, [searchMatches, workspace, sort])
  const lifecycles = useMemo(() => [...new Set(payload.apis.map(api => api.lifecycle).filter((v): v is string => Boolean(v)))].sort(), [payload.apis])

  async function openApi(api: ApiItem) {
    setSelected(api); setDetailError('')
    if (api.detailsLoaded) return
    setDetailLoading(true)
    try {
      const detail = await catalogApi.getSpec(api.id)
      const merged = { ...api, ...detail, catalogDescription: api.catalogDescription ?? api.description, detailsLoaded: true }
      setPayload(current => ({ ...current, apis: current.apis.map(item => item.id === api.id ? merged : item) }))
      setSelected(merged)
    } catch (error) { setDetailError(error instanceof Error ? error.message : 'Unable to load API') }
    finally { setDetailLoading(false) }
  }

  const summary = `${payload.apiCount} APIs across ${payload.workspaceCount} accessible workspaces${payload.loadMilliseconds != null ? ` · loaded in ${payload.loadMilliseconds} ms` : ''}`
  return <div className="catalog-shell">
    <Sidebar summary={summary} search={search} workspace={workspace} lifecycle={lifecycle} sort={sort} workspaces={workspaces} lifecycles={lifecycles} apiCount={items.length} workspaceCount={workspaces.length} loading={loading} onSearch={setSearch} onWorkspace={setWorkspace} onLifecycle={setLifecycle} onSort={setSort} onRefresh={() => void load(true)} onTheme={() => { document.documentElement.classList.toggle('dark'); localStorage.setItem('catalog-theme', document.documentElement.classList.contains('dark') ? 'dark' : 'light') }} />
    <main><div className="main-header"><div><div className="eyebrow">Available APIs</div><h2>Browse the catalog</h2></div><p>{status} · {items.length} visible</p></div>
      <section className="catalog-grid">{items.map(api => <ApiCard key={api.id} api={api} onOpen={openApi} />)}</section>
    </main>
    <ApiDialog api={selected} loading={detailLoading} error={detailError} onClose={() => setSelected(null)} />
  </div>
}
