import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import App from './App'
import './styles.css'

if (localStorage.getItem('catalog-theme') === 'dark') document.documentElement.classList.add('dark')
createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>)
