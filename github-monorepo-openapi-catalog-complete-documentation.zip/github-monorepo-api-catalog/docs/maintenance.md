# Maintenance and Releases

## Source layout

```text
backend/
  app.py
  catalog.py
  config.py
  github_client.py
  run.py
  verify_installation.py

frontend/
  src/
  package.json
  vite.config.ts

docs/
  README.md
  ...

Dockerfile
docker-compose.yml
setup.bat
setup.ps1
setup.sh
start-dev.bat
start-dev.ps1
start-dev.sh
verify.bat
verify.ps1
discovery-report.bat
discovery-report.ps1
```

## Change workflow

1. Start from the latest cumulative build.
2. Make backend and frontend changes.
3. Update documentation when behavior changes.
4. Run backend syntax/import checks.
5. Run frontend TypeScript build.
6. Run GitHub access verification.
7. Run discovery diagnostics.
8. Build Docker image.
9. Smoke test local UI.
10. Package or deploy an immutable revision.

## Required verification

Windows:

```bat
verify.bat
```

Manual:

```bash
python -m compileall -q backend
python backend/verify_installation.py dependencies
python backend/verify_installation.py imports
python backend/verify_installation.py github-access
npm --prefix frontend run build
```

## Recommended release checks

- [ ] API search works
- [ ] Endpoint search works
- [ ] Endpoint search does not auto-expand rows
- [ ] API names and versions render correctly
- [ ] Source paths are visible
- [ ] Endpoint counts align
- [ ] Table header remains fixed
- [ ] Detailed API view loads
- [ ] Raw specification view loads
- [ ] GitHub source link is correct
- [ ] Refresh works
- [ ] Dark theme works
- [ ] Token is absent from frontend assets and API payloads
- [ ] Discovery report is accurate
- [ ] Docker health check succeeds

## Dependency policy

Current frontend dependencies include `latest` constraints. For controlled production releases:

1. Pin versions
2. Commit lockfiles
3. Review changelogs
4. Run tests/build
5. Scan dependencies
6. Upgrade on a scheduled cadence

Backend requirements use bounded major versions but should also be reviewed periodically.

## Backwards compatibility

The backend retains:

```text
/api/workspaces
workspaceCount
workspaces
```

These remain for contract compatibility. The dashboard no longer groups or filters by workspace/repository folder.

## Planned enhancement candidates

- Shared Redis cache
- GitHub App authentication
- Branch/ref selector
- External `$ref` resolution and bundling
- Per-file last-commit timestamps
- Webhook-driven refresh
- Role-based authorization
- User audit logs
- Automated infrastructure deployment
- Automated GitHub Actions deployment
- API quality/governance indicators
