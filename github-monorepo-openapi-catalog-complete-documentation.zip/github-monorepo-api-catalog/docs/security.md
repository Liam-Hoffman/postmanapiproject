# Security Model

## Trust boundaries

```text
Browser
  │
  ▼
Trusted reverse proxy / ALB
  │
  ▼
Flask application
  │
  ▼
GitHub API
```

## GitHub token

The token is:

- Read by the backend from environment variables
- Added to GitHub requests as a Bearer token
- Excluded from browser payloads
- Excluded from Git through `.gitignore`
- Entered through hidden input in Windows setup
- Expected to be stored in AWS Secrets Manager in production

The token should have the minimum repository access required.

## Frontend secret isolation

Never place the token in:

```text
frontend source
browser local storage
browser session storage
VITE_* variables
HTML
client-side configuration JSON
```

Anything bundled by Vite must be considered visible to users.

## Authentication

The application itself currently has no login endpoint.

For AWS hosting, authentication should be enforced before Flask through:

```text
Application Load Balancer + company OIDC
```

The ECS security group must accept traffic only from the ALB security group so users cannot bypass SSO by calling the task directly.

## Authorization

Current model:

```text
All authenticated catalog users have read-only catalog access.
```

For different roles, implement verified claim-based authorization in Flask.

## Data sensitivity

The catalog may reveal:

- Internal API names
- Paths
- Operation summaries
- Schema fields
- Server URLs
- Security-scheme names
- Repository paths
- Owners and support channels
- Raw OpenAPI definitions

Treat the entire application as internal confidential documentation unless reviewed for broader publication.

## Source links

GitHub source URLs are sent to the browser. They do not contain the backend token.

## Logging

The GitHub client logs request method and URL. It does not intentionally log the token.

Review error responses and logs for:

- Internal hostnames
- Repository names
- GitHub upstream URLs
- OpenAPI parsing errors

Do not log environment variables or full request headers.

## Secrets Manager and ECS

When Secrets Manager values are injected as environment variables:

- The value is available to the application process
- A task restart is required to pick up changes
- Task-definition permissions should be restricted
- Operators with container-execution or debugging privileges may be able to inspect process environment

For stronger rotation behavior, a future version can retrieve the secret programmatically at runtime.

## SSO client secret

The ALB OIDC client secret is configuration on the load balancer listener. Restrict IAM permission to read or modify the listener configuration.

## Network controls

Recommended:

- ECS tasks in private subnets
- No public task IP
- ALB HTTPS only
- ECS inbound only from ALB security group
- Controlled outbound access to GitHub
- Internal DNS and private ALB when company policy requires VPN/network presence
- AWS WAF for internet-facing deployments when required

## Dependency management

The project currently uses broad dependency ranges and several frontend dependencies marked `latest`.

Before production:

- Commit lockfiles
- Use `npm ci`
- Pin reviewed dependency versions
- Run vulnerability scanning
- Scan the ECR image
- Establish an upgrade cadence

## Known security limitations

- No application-level user audit log
- No role-based authorization
- No Content Security Policy configuration
- No request-rate limiting in Flask
- No built-in CSRF concern for read-only endpoints, but future write operations would require review
- Raw specification content is rendered as text, not executed
- External `$ref` content is not fetched, reducing one class of server-side fetch risk
