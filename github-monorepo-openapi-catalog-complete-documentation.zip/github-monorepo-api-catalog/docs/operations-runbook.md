# Operations Runbook

## Service objectives

The catalog is a read-only internal documentation service. The primary dependencies are:

- Container runtime
- Application Load Balancer
- Corporate identity provider
- GitHub repository and API
- GitHub access token
- DNS and TLS

## Health checks

### Application health

```text
GET /api/health
```

Use for ALB health checks. It does not call GitHub.

### Source health

```text
GET /api/source-health
```

Use to confirm:

- Repository URL parsing
- Token authentication
- Repository visibility
- Default branch lookup

Do not poll this endpoint at high frequency because it calls GitHub.

### Discovery health

```text
GET /api/discovery?refresh=true
```

Use for a full scan diagnostic.

## Standard startup validation

1. Confirm ECS desired and running task counts match.
2. Confirm target is healthy.
3. Open `/api/health`.
4. Open `/api/source-health`.
5. Open catalog UI.
6. Confirm expected API count.
7. Run one API and one endpoint search.
8. Open a detailed API view.
9. Confirm GitHub source link format.

## Refresh procedure

User-level:

```text
Select Refresh catalog
```

API:

```text
GET /api/catalog?refresh=true
```

Important: refresh affects the process handling that request. In a multi-worker or multi-task deployment, restart or redeploy all tasks for globally consistent cache invalidation.

## GitHub token rotation

1. Create replacement token.
2. Confirm repository read access.
3. Update Secrets Manager.
4. Force new ECS deployment.
5. Confirm `/api/source-health`.
6. Confirm catalog refresh.
7. Revoke old token.
8. Record rotation date and owner.

## Deployment procedure

1. Build and test image.
2. Tag image with commit SHA.
3. Push to ECR.
4. Register new task-definition revision.
5. Update ECS service.
6. Wait for service stability.
7. Confirm healthy target.
8. Run smoke tests.
9. Retain previous task-definition revision for rollback.

## Rollback

1. Select the last known-good task-definition revision.
2. Update ECS service.
3. Wait for service stability.
4. Confirm `/api/health`.
5. Confirm `/api/source-health`.
6. Document the failed revision and symptoms.

## Recommended alarms

- ECS running task count below desired
- ALB unhealthy target count above zero
- ALB 5xx responses
- Target 5xx responses
- Elevated target response time
- ECS CPU utilization
- ECS memory utilization
- Container restart count
- OIDC/ALB authentication errors
- GitHub rate-limit or 403 patterns in logs

## Logs

Container output is written to stdout/stderr and should be sent to CloudWatch Logs.

Expected messages include:

```text
[Catalog] Scanning GitHub monorepo ...
[GitHub] Found ... JSON/YAML candidates ...
[Catalog] Validated ... and found ... OpenAPI specifications ...
```

## Capacity considerations

Initial scans download and parse all JSON/YAML candidates. Resource usage grows with:

- Repository tree size
- Candidate file count
- Specification size
- Schema complexity
- `GITHUB_SCAN_WORKERS`
- Number of process/container caches

Start with:

```text
0.5 vCPU
1 GB memory
1 ECS task
1 Gunicorn worker
8 threads
```

Monitor and adjust.

## Cache strategy

Current:

```text
In-memory per process
```

Operational options:

1. Keep one worker and one task
2. Accept independent caches
3. Restart all tasks after important documentation changes
4. Add Redis/shared cache in a future release

## Backup and disaster recovery

No application database exists.

Recovery sources:

- Application source repository
- ECR image
- ECS task definition
- Secrets Manager
- GitHub documentation repository
- Infrastructure configuration

A full redeployment recreates runtime state.

## Ownership matrix

Document company-specific owners:

| Responsibility | Owner |
|---|---|
| Application source | `<team>` |
| Documentation repository | `<team>` |
| GitHub token rotation | `<team/person>` |
| AWS infrastructure | `<platform team>` |
| SSO application | `<identity team>` |
| DNS and certificate | `<network/platform team>` |
| On-call support | `<team>` |
