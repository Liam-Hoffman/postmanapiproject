# Runtime Architecture

## Component diagram

```mermaid
flowchart LR
    U[Browser user] -->|HTTPS or local HTTP| F[React/Vite frontend]
    F -->|/api requests| A[Flask application]
    A --> C[CatalogService]
    C --> G[GitHubMonorepoClient]
    G -->|Bearer token| GH[GitHub REST API]
    C --> P[OpenAPI parser and normalizer]
    C --> M[(In-memory catalog and detail caches)]
    A -->|Production static files| D[frontend/dist]
```

For the simplest AWS hosting model:

```mermaid
flowchart LR
    E[Employees] --> ALB[Application Load Balancer]
    ALB -->|OIDC redirect| IDP[Corporate identity provider]
    IDP --> ALB
    ALB -->|Authenticated HTTPS request| ECS[ECS Fargate task]
    ECS --> GH[GitHub API]
    ECS --> SM[AWS Secrets Manager]
    ECS --> CW[CloudWatch Logs]
    ECR[Amazon ECR] --> ECS
```

A generated visual is also available at [images/aws-simple-architecture.png](images/aws-simple-architecture.png).

## Frontend

Technology:

- React
- TypeScript
- Vite
- React Router

Responsibilities:

- Dashboard and detailed documentation UI
- API metadata search
- Endpoint search
- Sorting
- Endpoint expansion
- Operation navigation
- Raw specification display
- Theme persistence

The frontend calls only relative `/api` URLs. It never receives the GitHub token.

## Backend

Technology:

- Python
- Flask
- PyYAML
- Gunicorn in the Docker production image

Responsibilities:

- Runtime configuration
- GitHub authentication
- Repository-tree traversal
- JSON/YAML candidate selection
- OpenAPI validation
- Metadata and operation normalization
- Cache management
- Health and diagnostics endpoints
- Static frontend serving in production

## GitHub discovery sequence

1. Parse the configured repository URL.
2. Determine:
   - Host
   - Owner
   - Repository
   - GitHub.com or GitHub Enterprise API base URL
3. Read repository metadata.
4. Use the repository default branch.
5. Request a recursive Git tree.
6. If GitHub marks the response as truncated, walk every subtree explicitly.
7. Select candidate files using configured extensions.
8. Apply `GITHUB_SEARCH_ROOT` when set.
9. Download each candidate by Git blob SHA.
10. Parse as JSON first, then YAML.
11. Validate that the document is OpenAPI/Swagger.
12. Normalize metadata and operations.
13. Cache catalog and detail results.

## OpenAPI validation

A candidate must be an object containing:

- `openapi`, or `swagger: "2.0"`
- `info`
- `info.title`
- `paths`

Invalid and non-OpenAPI files are recorded in the discovery report with a reason.

## Normalized data model

The backend presents the frontend with a provider-neutral catalog model. Important fields include:

```text
id
name
version
description
owner
lifecycle
domain
tags
servers
securitySchemes
operationCount
operations
sourcePath
sourceUrl
sourceRef
sourceSha
```

The UI does not consume raw GitHub tree or blob response shapes.

## Caching

`CatalogService` uses process-local memory:

- Catalog cache
- Detail cache
- Cache timestamp
- Spec index

Default TTL:

```text
900 seconds
```

A forced refresh rebuilds the catalog and clears that process's detail cache.

### Production implication

Caches are not shared between:

- Gunicorn workers
- ECS tasks
- Separate application instances

The current Dockerfile starts:

```text
2 Gunicorn workers
4 threads per worker
```

Each worker can independently scan GitHub and hold different cache state. For the simplest predictable deployment, consider one Gunicorn worker with multiple threads:

```text
--workers 1 --threads 8
```

Alternatively, implement a shared cache such as Redis before scaling horizontally.

## Concurrency

OpenAPI candidate validation uses a bounded thread pool controlled by:

```env
GITHUB_SCAN_WORKERS=8
```

Allowed range:

```text
1 through 24
```

Higher values can reduce scan time but increase concurrent GitHub requests, CPU use, and memory use.

## Static serving

During development:

```text
Vite serves the frontend
Flask serves /api
```

In the Docker production image:

```text
Gunicorn runs Flask
Flask serves frontend/dist
Flask serves /api
```

Unknown frontend routes return `frontend/dist/index.html`, enabling React Router deep links.

## Network dependencies

The runtime needs outbound access to:

- GitHub.com API, or
- The configured GitHub Enterprise API endpoint

In AWS private subnets, provide NAT, a company network route, or another approved egress path.

## Persistence

The application has no database and stores no durable catalog state. Restarting the process clears all caches. GitHub remains the source of truth.
