# OpenAPI Authoring Guide

## Minimum document requirements

A file is included when it:

1. Has a `.json`, `.yml`, or `.yaml` extension
2. Parses as a JSON/YAML object
3. Contains either:
   - An `openapi` version, or
   - `swagger: "2.0"`
4. Contains `info.title`
5. Contains a `paths` object

Minimal OpenAPI 3 example:

```yaml
openapi: 3.0.3
info:
  title: Payments API
  version: 2.0.0
paths: {}
```

## Recommended catalog metadata

```yaml
openapi: 3.0.3
info:
  title: Payments API
  version: 2.4.1
  description: Creates and manages customer payments.
  x-owner-team: Payments Platform
  x-lifecycle: production
  x-domain: Payments
  x-support-channel: "#payments-api-support"
paths: {}
```

Recommended fields:

| Field | Purpose |
|---|---|
| `info.title` | Primary API name |
| `info.version` | API major-version display |
| `info.description` | API overview |
| `info.contact.name` | Owner fallback |
| `info.contact.email` | Support fallback |
| `info.contact.url` | Support fallback |
| `info.x-owner-team` | Preferred owner/team |
| `info.x-lifecycle` | Lifecycle label |
| `info.x-domain` | Business or technical domain |
| `info.x-support-channel` | Support destination |

## Lifecycle values

The UI displays lifecycle text as provided. Use a controlled vocabulary within the organization, for example:

```text
experimental
development
beta
production
deprecated
retired
```

Consistency improves search and future reporting.

## Operations

Give each operation a useful summary and stable operation ID:

```yaml
paths:
  /payments/{paymentId}:
    get:
      operationId: getPayment
      summary: Get a payment
      description: Returns one payment by its identifier.
      tags:
        - Payments
```

Endpoint search indexes:

- Method
- Path
- Summary
- Description
- Operation ID
- Tags

## Request schemas

Local JSON Pointer references are supported:

```yaml
components:
  schemas:
    PaymentRequest:
      type: object
      required:
        - amount
      properties:
        amount:
          type: number
          format: decimal
        currency:
          type: string

paths:
  /payments:
    post:
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: "#/components/schemas/PaymentRequest"
```

The detailed view recursively displays nested objects and arrays and identifies required fields.

## Examples

Provide request examples through media-type examples or schema examples:

```yaml
requestBody:
  content:
    application/json:
      schema:
        $ref: "#/components/schemas/PaymentRequest"
      example:
        amount: 125.50
        currency: USD
```

## Security schemes

Define security schemes under `components.securitySchemes`:

```yaml
components:
  securitySchemes:
    oauth2:
      type: oauth2
      flows:
        clientCredentials:
          tokenUrl: https://identity.company.com/oauth2/token
          scopes:
            payments.read: Read payments
```

The catalog displays the scheme names, but it does not execute authentication flows.

## External references

Current support:

```yaml
$ref: "#/components/schemas/Payment"
```

Not currently resolved:

```yaml
$ref: "./schemas/payment.yaml"
$ref: "https://example.com/common.yaml"
```

For reliable rendering, bundle external references into one document before publishing to the documentation repository.

## Filename conventions

The filename does not need to be `openapi.yaml`. Examples accepted by the scanner include:

```text
payments-definition.yaml
claims-v2.json
public-api.yml
schema.json
```

Use filenames that remain understandable in repository paths because the path is displayed beneath the API name.
