# AWS Deployment and Company SSO

## Simplest supported architecture

```text
Employees
   │
   ▼
Application Load Balancer
HTTPS + corporate OIDC authentication
   │
   ▼
ECS Fargate
React + Flask/Gunicorn container
   │
   ├── GitHub API
   ├── Secrets Manager
   └── CloudWatch Logs
```

Supporting services:

- Amazon ECR
- Amazon ECS on Fargate
- Application Load Balancer
- AWS Certificate Manager
- AWS Secrets Manager
- CloudWatch Logs
- IAM
- Route 53 or company DNS
- Existing VPC and subnets

Visual: [images/aws-simple-architecture.png](images/aws-simple-architecture.png)

## Why this is the simplest approach

- One container serves frontend and backend
- No EC2 server management
- No application login implementation
- ALB redirects users to company SSO
- GitHub token remains in Secrets Manager
- Standard health endpoint works with the target group

AWS references:

- [Authenticate users using an Application Load Balancer](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/listener-authenticate-users.html)
- [Use an Application Load Balancer for Amazon ECS](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/alb.html)
- [Pass Secrets Manager secrets through ECS environment variables](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/secrets-envvar-secrets-manager.html)
- [ECS task execution IAM role](https://docs.aws.amazon.com/AmazonECS/latest/developerguide/task_execution_IAM_role.html)

## Prerequisites

Obtain:

- AWS account and deployment permissions
- Existing VPC
- At least two subnets
- DNS hostname, such as `api-catalog.company.com`
- ACM certificate
- Corporate OIDC app registration
- GitHub token or GitHub App token
- Network access from ECS to GitHub

## Step 1: Build the image

The repository already contains a multi-stage `Dockerfile`.

```bash
docker build -t api-catalog .
```

Local container test:

```bash
docker run --rm -p 8080:8080 \
  --env-file .env \
  api-catalog
```

Open:

```text
http://127.0.0.1:8080
```

## Step 2: Create ECR repository

Create:

```text
api-catalog
```

Enable image scanning according to company standards.

Push the image using the commands shown by the ECR console.

Use immutable tags, preferably:

```text
<git-commit-sha>
```

Avoid relying only on `latest` for production rollback.

## Step 3: Store the GitHub token

Create a Secrets Manager secret, for example:

```text
api-catalog/github-token
```

Store either plain text or a JSON key.

Recommended JSON:

```json
{
  "GITHUB_ACCESS_TOKEN": "github_pat_..."
}
```

## Step 4: IAM roles

### Task execution role

Used by ECS to:

- Pull the image from ECR
- Publish logs
- Retrieve the referenced secret

Attach `AmazonECSTaskExecutionRolePolicy` and a scoped permission:

```json
{
  "Effect": "Allow",
  "Action": "secretsmanager:GetSecretValue",
  "Resource": "<secret-arn>"
}
```

Add `kms:Decrypt` when using a customer-managed KMS key.

### Task role

The current application does not call AWS APIs directly. It can use an empty/minimal task role.

## Step 5: Task definition

Recommended initial values:

```text
Launch type: Fargate
Network mode: awsvpc
CPU: 0.5 vCPU
Memory: 1 GB
Container port: 8080
```

Normal environment variables:

```text
APP_ENV=production
CATALOG_HOST=0.0.0.0
CATALOG_PORT=8080
GITHUB_REPOSITORY_URL=https://github.com/company/documentation-repo
GITHUB_SPEC_EXTENSIONS=.json,.yml,.yaml
GITHUB_SCAN_WORKERS=8
CATALOG_CACHE_TTL_SECONDS=900
```

Secret mapping:

```text
GITHUB_ACCESS_TOKEN → Secrets Manager
```

Configure CloudWatch `awslogs`.

## Step 6: Target group

Configure:

```text
Target type: IP
Protocol: HTTP
Port: 8080
Health check path: /api/health
Success code: 200
```

Fargate uses `awsvpc`; the target type must be IP.

## Step 7: ECS service

Initial simple deployment:

```text
Desired tasks: 1
Public IP: disabled
Private application subnets
ECS security group
ALB target group
```

Security groups:

```text
ALB security group:
  Inbound 443 from approved networks or internet
  Outbound 8080 to ECS security group

ECS security group:
  Inbound 8080 only from ALB security group
```

Do not expose port 8080 directly.

## Step 8: DNS and TLS

Request an ACM certificate for:

```text
api-catalog.company.com
```

Create:

```text
HTTPS listener: 443
HTTP listener: redirect to HTTPS
```

Point Route 53 or corporate DNS to the ALB.

## Step 9: Corporate OIDC SSO

Ask the identity team to register a web OIDC application.

Provide:

```text
Application URL:
https://api-catalog.company.com

Redirect URI:
https://api-catalog.company.com/oauth2/idpresponse
```

Obtain:

```text
Issuer URL
Authorization endpoint
Token endpoint
User-info endpoint
Client ID
Client secret
```

Configure the ALB HTTPS listener actions:

```text
1. Authenticate OIDC
2. Forward to ECS target group
```

Set unauthenticated behavior to authenticate.

Assign the OIDC app to the approved company group.

## SAML-only identity provider

ALB does not directly consume arbitrary corporate SAML configuration in the same way as OIDC. When the company requires SAML, use Amazon Cognito as a SAML-to-ALB bridge or another company-approved identity proxy.

## Application authorization

The current application expects all authenticated users to have the same access.

For role-based behavior:

1. Decide which identity claims contain roles/groups.
2. Verify the signed ALB identity data in Flask.
3. Map claims to application permissions.
4. Protect individual backend routes.

Do not trust arbitrary identity headers unless the backend can only be reached through the trusted ALB and the ALB-signed data is verified where needed.

## Runtime recommendation before scaling

Because the cache is process-local, use one Gunicorn worker for the simplest predictable initial deployment:

```dockerfile
CMD ["gunicorn", "--bind", "0.0.0.0:8080", "--workers", "1", "--threads", "8", "--timeout", "120", "app:app"]
```

When using multiple tasks or workers, implement a shared cache or accept that each instance can scan and refresh independently.

## Production checklist

- [ ] ECR image uses immutable tag
- [ ] ECS tasks are private
- [ ] ECS accepts traffic only from ALB
- [ ] HTTPS is enforced
- [ ] Corporate OIDC is required
- [ ] GitHub token is in Secrets Manager
- [ ] Execution role is least privilege
- [ ] CloudWatch logs have retention configured
- [ ] `/api/health` is green
- [ ] `/api/source-health` succeeds
- [ ] GitHub token rotation owner is documented
- [ ] ALB access logs and alarms are configured
- [ ] Direct task access is blocked
