# Backend API Reference

Base path:

```text
/api
```

## `GET /api/health`

Lightweight application health check.

Example response:

```json
{
  "status": "ok",
  "environment": "production",
  "provider": "github",
  "repository": "company/documentation-repo"
}
```

This endpoint does not call GitHub.

Recommended ALB target-group health check:

```text
/api/health
```

## `GET /api/source-health`

Tests configured GitHub repository access.

Example response:

```json
{
  "status": "ok",
  "provider": "github",
  "repository": "company/documentation-repo",
  "repositoryUrl": "https://github.com/company/documentation-repo",
  "ref": "main",
  "private": true,
  "authenticated": true
}
```

Failure response status: `502`

Use for diagnostics, startup checks, and token validation. Avoid aggressive monitoring frequency because it calls GitHub.

## `GET /api/catalog`

Returns normalized catalog metadata.

Query parameter:

```text
refresh=true
```

Example:

```text
GET /api/catalog?refresh=true
```

Important response fields:

```json
{
  "generatedAt": 0,
  "loadMilliseconds": 0,
  "apiCount": 0,
  "workspaceCount": 0,
  "apis": [],
  "errors": [],
  "source": {},
  "cache": {
    "hit": false,
    "ageSeconds": 0
  }
}
```

`workspaceCount` and `workspaces` remain in the backend contract for compatibility. The current dashboard does not expose workspace grouping or filtering.

## `GET /api/specs/{catalogId}`

Returns the complete normalized API detail for one catalog item.

Example:

```text
GET /api/specs/9d2c27c0b42f846fe35c4f19
```

Optional:

```text
GET /api/specs/{catalogId}?refresh=true
```

Responses:

- `200` detail found
- `404` catalog ID not found
- `502` GitHub retrieval failed
- `500` unexpected normalization failure

## `GET /api/discovery`

Returns discovery diagnostics.

Recommended forced diagnostic:

```text
GET /api/discovery?refresh=true
```

Important fields:

```json
{
  "apiCount": 42,
  "discovery": {
    "ref": "main",
    "searchRoot": "",
    "configuredExtensions": [".json", ".yaml", ".yml"],
    "recursiveTreeTruncated": false,
    "traversalMode": "recursive",
    "extensionCandidateCount": 95,
    "matchedSpecCount": 42,
    "matchedPaths": [],
    "rejectedFileCount": 53,
    "rejectedFiles": [],
    "excludedBySearchRootCount": 0
  }
}
```

## `GET /api/workspaces`

Compatibility endpoint returning repository-folder group objects.

The current UI no longer uses a workspace/repository-folder dropdown. New integrations should prefer `/api/catalog`.

## Error format

Typical upstream error:

```json
{
  "error": "Unable to load GitHub catalog",
  "details": "GitHub returned HTTP 403: ...",
  "upstreamUrl": "https://api.github.com/..."
}
```

Do not expose these diagnostics to untrusted public users without reviewing whether upstream URLs or messages reveal internal repository information.
