# Local Setup and Development

## Prerequisites

For the scripted local setup:

- Node.js 22 or newer
- npm
- Python 3.11 or newer
- GitHub repository access token
- Access to the configured repository

Docker is optional for local development.

## Required configuration

Copy `.env.example` to `.env` and set:

```env
GITHUB_REPOSITORY_URL=https://github.com/organization/documentation-repo
GITHUB_ACCESS_TOKEN=github_pat_...
```

Use a repository root URL. Do not use a branch, directory, or file URL.

Supported forms include:

```text
https://github.com/organization/repository
https://github.com/organization/repository.git
git@github.com:organization/repository.git
https://github.company.com/organization/repository
```

## Windows setup

Run:

```bat
setup.bat
```

The setup script:

1. Validates project files
2. Validates Node.js, npm, and Python versions
3. Creates or preserves `.env`
4. Prompts for repository URL
5. Prompts for the token using hidden input
6. Creates `.venv`
7. Installs Python dependencies
8. Installs root and frontend npm dependencies
9. Verifies repository URL parsing
10. Verifies backend imports
11. Verifies GitHub access
12. Builds the frontend

Start development services:

```bat
start-dev.bat
```

Local URLs:

```text
Frontend: http://127.0.0.1:5173
Backend:  http://127.0.0.1:8080
```

## Linux and macOS setup

Run:

```bash
chmod +x setup.sh start-dev.sh
./setup.sh
```

The first execution may create `.env` and ask you to edit it before rerunning.

Start:

```bash
./start-dev.sh
```

## Manual setup

```bash
python3 -m venv .venv
```

Activate the environment.

Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
```

Linux/macOS:

```bash
source .venv/bin/activate
```

Install backend dependencies:

```bash
python -m pip install --upgrade pip
python -m pip install -r backend/requirements.txt
```

Install frontend dependencies:

```bash
npm install
npm --prefix frontend install
```

Build:

```bash
npm --prefix frontend run build
```

## Development runtime

The local development runtime uses two processes:

```text
Browser
   │
   ▼
Vite dev server :5173
   │ /api proxy
   ▼
Flask dev server :8080
   │
   ▼
GitHub API
```

`frontend/vite.config.ts` loads the root `.env` and proxies `/api` to the configured Flask host and port.

## Verification

Windows:

```bat
verify.bat
```

The verification script checks:

- Backend syntax and imports
- Required Python dependencies
- GitHub authentication and repository access
- Retained frontend feature markers
- TypeScript and Vite production build

Optional PowerShell switches:

```powershell
.\verify.ps1 -SkipGitHubCheck
.\verify.ps1 -SkipFrontendBuild
```

## Discovery diagnostics

Windows:

```bat
discovery-report.bat
```

Direct Python equivalent:

```bash
.venv/bin/python backend/verify_installation.py discovery
```

## Docker development

Build and run:

```bash
docker compose up --build
```

The container listens on:

```text
http://127.0.0.1:8080
```

The Docker image builds the React frontend and serves it through Flask/Gunicorn.

## Useful npm commands

```bash
npm --prefix frontend run dev
npm --prefix frontend run build
npm --prefix frontend run lint
```

## Useful backend commands

```bash
python backend/run.py
python backend/verify_installation.py dependencies
python backend/verify_installation.py repository-url
python backend/verify_installation.py github-access
python backend/verify_installation.py discovery
```
