# Troubleshooting

## Setup fails with `NameError: name 'backend' is not defined`

Cause: an older build passed an inline Python expression through PowerShell and lost quotes.

Resolution:

- Use the current build
- Confirm `backend/verify_installation.py` exists
- Rerun `setup.bat`

## Setup reports a null-valued expression

This was a secondary error after failed repository URL parsing in an older script.

Use the current `setup.ps1`, which checks command output before calling string methods.

## Only some APIs appear

Run:

```bat
discovery-report.bat
```

Or:

```text
GET /api/discovery?refresh=true
```

Review:

```text
ref
searchRoot
extensionCandidateCount
matchedSpecCount
rejectedFiles
excludedBySearchRootPaths
recursiveTreeTruncated
traversalMode
```

Common causes:

- File is not on the default branch
- Extension is not configured
- `GITHUB_SEARCH_ROOT` excludes the file
- Invalid JSON/YAML
- Missing OpenAPI marker
- Missing `info.title`
- Missing `paths`
- Git submodule content is not part of the parent repository tree

## GitHub returns 401

Check:

- Token was copied correctly
- Token has not expired
- Secret does not include surrounding quotes
- Token belongs to the correct GitHub host

Rotate the token when uncertain.

## GitHub returns 403

Possible causes:

- Organization policy blocks the token
- Fine-grained PAT is awaiting approval
- SAML SSO authorization is required
- Rate limit exhausted
- Repository permission is missing

Check `/api/source-health` and GitHub organization policies.

## GitHub returns 404 for a private repository

GitHub often returns 404 when the caller lacks private repository access.

Check:

- Repository URL
- Owner and repository spelling
- Token repository selection
- Contents read permission

## GitHub Enterprise cannot be reached

Check:

- DNS from the runtime
- VPC/company network routes
- Firewall rules
- Enterprise TLS certificate trust
- API base URL mapping
- Proxy requirements

## `/api/health` works but catalog fails

`/api/health` is local-only. Check:

```text
/api/source-health
/api/discovery?refresh=true
```

The likely problem is GitHub access, parsing, or scanning.

## `/api/source-health` works but scan fails

Possible causes:

- Rate limiting during many blob requests
- Candidate file too large or invalid
- Unexpected GitHub API response
- Network timeout
- YAML parsing issue

Increase timeout carefully:

```env
GITHUB_REQUEST_TIMEOUT_SECONDS=60
```

Reduce concurrency:

```env
GITHUB_SCAN_WORKERS=4
```

## Endpoint search misses results

Check:

- Detail-loading progress completed
- Operation includes method/path/summary/description/operation ID/tag
- API is not excluded by API search
- Search term is not only in response schemas, which are not part of endpoint search text

## API name is incorrect

The title comes from `info.title`.

The displayed major version uses the first numeric segment from `info.version`.

Examples:

```text
2.7.1      → V2
v3-beta    → V3
2026-07-01 → V2026
```

Date-style versions therefore display the year as the major version.

## External schema fields are missing

External relative `$ref` files are not resolved.

Bundle the OpenAPI document or replace references with local JSON Pointers.

## Frontend shows `Frontend build not found`

Run:

```bash
npm --prefix frontend install
npm --prefix frontend run build
```

For local development, use `start-dev.bat` or `start-dev.sh`.

## Docker build fails at `npm ci`

Confirm frontend lockfile exists and matches `frontend/package.json`.

If intentionally regenerating dependencies:

```bash
cd frontend
npm install
```

Commit the updated lockfile before rebuilding.

## ECS target is unhealthy

Check:

- Container listens on `0.0.0.0:8080`
- Target group uses port 8080
- Health path is `/api/health`
- Target type is IP
- ECS security group allows 8080 from ALB security group
- Container logs
- Gunicorn started successfully

## SSO redirects repeatedly

Check:

- Redirect URI is exactly:
  `https://api-catalog.company.com/oauth2/idpresponse`
- ALB listener uses HTTPS
- OIDC issuer/endpoints match the provider
- Client ID and secret are correct
- DNS hostname matches the registered application
- Browser cookies are allowed
- System clocks are synchronized

## Updated secret is not used

ECS-injected environment variables are set at task startup.

Force a new deployment after updating Secrets Manager.

## Refresh appears inconsistent

Cause: independent caches in multiple Gunicorn workers or ECS tasks.

Resolution:

- Redeploy/restart all tasks
- Use one Gunicorn worker for simple deployments
- Add a shared cache in a future version
