# User Guide

## Opening the catalog

In local development, open:

```text
http://127.0.0.1:5173
```

In a hosted environment, use the company URL supplied by the platform team, for example:

```text
https://api-catalog.company.com
```

When company SSO is configured at the AWS Application Load Balancer, the browser redirects to the corporate identity provider before the catalog loads.

## Dashboard overview

The dashboard contains four main areas:

1. **Catalog identity and controls**
   - Refresh catalog
   - Toggle theme
   - Repository and scan summary
2. **Summary cards**
   - Number of visible APIs
   - Number of endpoints in the visible APIs
3. **Search and sorting**
   - Search APIs
   - Search endpoints
   - Sort APIs
4. **API table**
   - API name and major version
   - Source path
   - Lifecycle
   - Owner
   - Updated date
   - Endpoint count

There is no workspace or repository-folder selector. Every valid OpenAPI document is shown as an independent API.

## API names and versions

The primary name comes from:

```yaml
info:
  title: Payments API
```

The catalog extracts the first numeric portion of `info.version` and appends it as the major version:

```yaml
info:
  title: Payments API
  version: 2.7.1
```

Displayed as:

```text
Payments API V2
```

If the title already contains `V2` or `Version 2`, the version is not appended again.

## Search APIs

**Search APIs** filters API-level metadata, including:

- API title
- Version
- Owner
- Lifecycle
- Domain
- Tags
- Security schemes
- Repository name
- Repository path
- Source reference

API search does not automatically open endpoint previews.

Examples:

```text
payments
production
customer platform
services/claims
oauth
```

## Search endpoints

**Search endpoints** filters APIs by operation-level information:

- HTTP method
- Route path
- Summary
- Description
- Operation ID
- Tags

Examples:

```text
POST
/payments
customer
create claim
admin
```

The result list shows only APIs containing matching endpoints. Rows remain collapsed until the user explicitly opens one. When opened during an endpoint search, the preview shows only the matching operations.

## Sorting

The catalog can be sorted by:

- **Name**
- **Recently updated**
- **Most endpoints**

The Updated value currently comes from repository-level GitHub timestamps, not the last commit for each individual file.

## Endpoint counts

Endpoint counts use aligned numeric and label columns:

```text
 5 endpoints
13 endpoints
```

When endpoint search is active, the same control reports matches:

```text
 2 matches
11 matches
```

Select the count to expand or collapse the operation preview.

## Opening an API

Select anywhere on an API row, except the endpoint disclosure control, to open the detailed API view.

The detailed view includes:

- API title and version
- Repository source link
- Overview and metadata
- Servers
- Authentication/security schemes
- Operation navigation
- Endpoint method, route, summary, and description
- Request fields
- Required and optional indicators
- Nested object and array fields
- Request examples when present
- Raw specification text

## Navigating operations

Operation groups are collapsed by default. Use the operation navigation on the left to:

- Search operations within the selected API
- Expand an operation group
- Jump directly to an endpoint
- Switch between documentation and raw specification views

Searching inside the detailed API view expands relevant groups so matching operations are visible.

## Refreshing data

Select **Refresh catalog** to force a new repository scan.

A refresh:

- Clears the backend detail cache for the process handling the request
- Re-reads the repository tree
- Re-downloads JSON/YAML candidates
- Revalidates OpenAPI documents
- Updates visible metadata and operations

In a multi-worker or multi-container deployment, caches are independent. An operations team may need to restart or redeploy all tasks when a globally consistent refresh is required.

## Theme

Select **Theme** to switch between light and dark mode. The preference is stored in browser local storage.

## Common user issues

### An API is missing

Check:

- The file is on the repository default branch
- The file ends in `.json`, `.yml`, or `.yaml`
- The document includes `openapi` or `swagger: "2.0"`
- `info.title` exists
- `paths` exists and is an object
- `GITHUB_SEARCH_ROOT` is not excluding the path

Run `discovery-report.bat` or inspect `/api/discovery?refresh=true` for the rejection reason.

### Endpoint search shows no results

Endpoint details must finish loading before endpoint search can match all APIs. Check the status pills for detail-loading progress.

### The source link does not open

The signed-in GitHub user must independently have permission to view the repository. The catalog's backend token does not grant repository access to the browser user.
