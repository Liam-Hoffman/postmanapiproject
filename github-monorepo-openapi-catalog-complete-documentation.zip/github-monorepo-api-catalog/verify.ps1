[CmdletBinding()]
param(
    [switch]$SkipGitHubCheck,
    [switch]$SkipFrontendBuild
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

function Invoke-Native {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Command,

        [Parameter(ValueFromRemainingArguments = $true)]
        [string[]]$Arguments
    )

    & $Command @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Command failed with exit code ${LASTEXITCODE}: $Command $($Arguments -join ' ')"
    }
}

$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $VenvPython)) {
    throw "The Python virtual environment is missing. Run setup.bat first."
}
if (-not (Test-Path "frontend\node_modules")) {
    throw "Frontend dependencies are missing. Run setup.bat first."
}

Write-Host "GitHub Monorepo API Catalog - verification" -ForegroundColor Green

Write-Host "`n==> Checking backend syntax and imports" -ForegroundColor Cyan
Invoke-Native $VenvPython "-m" "compileall" "-q" "backend"
Invoke-Native $VenvPython "backend\verify_installation.py" "dependencies"
Invoke-Native $VenvPython "backend\verify_installation.py" "imports"

if (-not $SkipGitHubCheck) {
    Write-Host "`n==> Checking GitHub authentication and repository access" -ForegroundColor Cyan
    Invoke-Native $VenvPython "backend\verify_installation.py" "github-access"
} else {
    Write-Host "GitHub access check skipped" -ForegroundColor Yellow
}

Write-Host "`n==> Checking required frontend feature markers" -ForegroundColor Cyan
$AppSource = Get-Content "frontend\src\App.tsx" -Raw
$ExplorerSource = Get-Content "frontend\src\components\ApiExplorer.tsx" -Raw
$SidebarSource = Get-Content "frontend\src\components\Sidebar.tsx" -Raw
$ViteSource = Get-Content "frontend\vite.config.ts" -Raw
$GitHubSource = Get-Content "backend\github_client.py" -Raw
$ConfigSource = Get-Content "backend\config.py" -Raw

$RequiredChecks = @(
    @{ Name = "Endpoint-aware catalog search"; Value = $AppSource -match "matchingOperations" },
    @{ Name = "Separate API and endpoint searches"; Value = $SidebarSource -match "Search endpoints" -and $AppSource -match "endpointQuery" },
    @{ Name = "Clean dashboard catalog UI"; Value = $SidebarSource -match "dashboard-stat-grid" -and $AppSource -match "dashboard-main-header" },
    @{ Name = "No repository folder selector"; Value = $SidebarSource -notmatch "Repository folder" -and $AppSource -notmatch "onWorkspace" },
    @{ Name = "Explicit-only operation expansion"; Value = $AppSource -match "setExpandedApiId\(null\)" -and $AppSource -notmatch "api-search-matches" },
    @{ Name = "Fixed catalog header row"; Value = (Get-Content "frontend\src\styles.css" -Raw) -match "flat-api-grid" },
    @{ Name = "Aligned endpoint disclosure"; Value = $AppSource -match "operation-disclosure__label" },
    @{ Name = "Flat one-API-per-row catalog"; Value = $AppSource -match "flat-api-catalog" },
    @{ Name = "Repository path subtitles"; Value = $AppSource -match "api-source-path" },
    @{ Name = "Inline operation disclosure"; Value = $AppSource -match "operation-disclosure" },
    @{ Name = "Compact detailed header"; Value = $AppSource -match "detail-page-header__nav-row" },
    @{ Name = "Major-version API names"; Value = $AppSource -match "V\$\{majorVersion\}" },
    @{ Name = "Collapsed detailed operation groups"; Value = $ExplorerSource -match "open=\{query \? true : undefined\}" },
    @{ Name = "GitHub source links"; Value = $ExplorerSource -match "github-source-link" },
    @{ Name = "Compact Refresh and Theme buttons"; Value = $SidebarSource -match "sidebar-action-button" },
    @{ Name = "Local-only Vite binding"; Value = $ViteSource -match "host: '127.0.0.1'" },
    @{ Name = "Shared backend proxy configuration"; Value = $ViteSource -match "CATALOG_PORT" },
    @{ Name = "Repository URL configuration"; Value = $ConfigSource -match "GITHUB_REPOSITORY_URL" },
    @{ Name = "JSON/YAML extension scanning"; Value = $ConfigSource -match "GITHUB_SPEC_EXTENSIONS" },
    @{ Name = "Content-based OpenAPI validation"; Value = $GitHubSource -match "extensionCandidateCount" },
    @{ Name = "Bearer token authentication"; Value = $GitHubSource -match 'Authorization.*Bearer' }
)

foreach ($check in $RequiredChecks) {
    if (-not $check.Value) {
        throw "Feature verification failed: $($check.Name)"
    }
    Write-Host "PASS: $($check.Name)"
}

if (-not $SkipFrontendBuild) {
    Write-Host "`n==> Running TypeScript and Vite production build" -ForegroundColor Cyan
    Invoke-Native "npm" "--prefix" "frontend" "run" "build"
} else {
    Write-Host "Frontend build skipped" -ForegroundColor Yellow
}

Write-Host "`nAll verification checks passed." -ForegroundColor Green
