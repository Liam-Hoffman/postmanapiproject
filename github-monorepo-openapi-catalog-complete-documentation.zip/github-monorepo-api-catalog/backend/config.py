import os

GITHUB_REPOSITORY_URL = os.environ.get("GITHUB_REPOSITORY_URL", "").strip()
# GITHUB_TOKEN remains a backwards-compatible alias for an existing .env.
GITHUB_ACCESS_TOKEN = (
    os.environ.get("GITHUB_ACCESS_TOKEN", "").strip()
    or os.environ.get("GITHUB_TOKEN", "").strip()
)
GITHUB_API_VERSION = os.environ.get("GITHUB_API_VERSION", "2022-11-28").strip()
GITHUB_SEARCH_ROOT = os.environ.get("GITHUB_SEARCH_ROOT", "").strip().strip("/")
GITHUB_SPEC_EXTENSIONS = {
    value if value.startswith(".") else f".{value}"
    for value in (
        item.strip().casefold()
        for item in os.environ.get(
            "GITHUB_SPEC_EXTENSIONS",
            ".json,.yml,.yaml",
        ).split(",")
    )
    if value
}
GITHUB_SCAN_WORKERS = min(
    max(int(os.environ.get("GITHUB_SCAN_WORKERS", "8")), 1),
    24,
)
GITHUB_REQUEST_TIMEOUT_SECONDS = max(
    int(os.environ.get("GITHUB_REQUEST_TIMEOUT_SECONDS", "30")),
    1,
)
GITHUB_MAX_RETRIES = min(
    max(int(os.environ.get("GITHUB_MAX_RETRIES", "3")), 0),
    8,
)
GITHUB_RETRY_BUFFER_SECONDS = max(
    float(os.environ.get("GITHUB_RETRY_BUFFER_SECONDS", "1")),
    0.0,
)

HOST = os.environ.get("CATALOG_HOST", "127.0.0.1")
PORT = int(os.environ.get("CATALOG_PORT", "8080"))
CACHE_TTL_SECONDS = max(
    int(os.environ.get("CATALOG_CACHE_TTL_SECONDS", "900")),
    0,
)
