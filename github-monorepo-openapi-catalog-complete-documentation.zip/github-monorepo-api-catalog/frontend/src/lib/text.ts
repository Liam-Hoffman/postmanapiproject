import type { ApiItem } from '../types'

export function htmlToText(value = ''): string {
  const document = new DOMParser().parseFromString(value, 'text/html')
  return (document.body.textContent || '').replace(/\s+/g, ' ').trim()
}

export function apiSearchable(api: ApiItem): string {
  const version = String(api.version || '').trim()
  const majorVersion = version.match(/\d+/)?.[0]
  const displayName = majorVersion ? `${api.name} V${majorVersion}` : api.name

  return [
    displayName,
    api.name,
    api.description,
    api.version,
    api.lifecycle,
    api.owner,
    api.domain,
    api.workspace?.name,
    api.repository,
    api.sourcePath,
    api.sourceRef,
    ...(api.tags || []),
    ...(api.securitySchemes || []),
  ]
    .filter(Boolean)
    .join(' ')
    .toLowerCase()
}


export function formatDate(value?: string): string {
  if (!value) return 'Unknown'
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(date)
}
