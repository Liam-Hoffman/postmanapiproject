interface Props {
  summary: string
  apiSearch: string
  endpointSearch: string
  sort: string
  apiCount: number
  endpointCount: number
  loading: boolean
  onApiSearch(value: string): void
  onEndpointSearch(value: string): void
  onSort(value: string): void
  onRefresh(): void
  onTheme(): void
}

export function Sidebar(props: Props) {
  return <aside className="catalog-sidebar dashboard-sidebar">
    <header className="brand-block dashboard-brand">
      <div className="dashboard-brand__identity">
        <div className="dashboard-brand__mark" aria-hidden="true">API</div>
        <div>
          <div className="eyebrow">Internal Developer Portal</div>
          <h1>API Catalog</h1>
        </div>
      </div>
      <p className="dashboard-brand__summary">{props.summary}</p>
      <div className="actions sidebar-actions dashboard-brand__actions">
        <button
          className="sidebar-action-button sidebar-action-button--primary"
          onClick={props.onRefresh}
          disabled={props.loading}
        >
          {props.loading ? 'Refreshing…' : 'Refresh catalog'}
        </button>
        <button
          className="sidebar-action-button sidebar-action-button--secondary"
          onClick={props.onTheme}
          aria-label="Toggle color theme"
        >
          Theme
        </button>
      </div>
    </header>

    <section className="dashboard-stat-grid" aria-label="Catalog summary">
      <div className="dashboard-stat-card">
        <span>Visible APIs</span>
        <strong>{props.apiCount}</strong>
        <small>Matching current filters</small>
      </div>
      <div className="dashboard-stat-card">
        <span>Endpoints</span>
        <strong>{props.endpointCount}</strong>
        <small>Available in visible APIs</small>
      </div>
    </section>

    <section className="sidebar-panel dashboard-controls">
      <div className="dashboard-section-heading">
        <div>
          <span className="dashboard-section-heading__eyebrow">Discover</span>
          <strong>Search and organize</strong>
        </div>
      </div>

      <div className="catalog-search-group" role="group" aria-label="Catalog searches">
        <label>
          <span>Search APIs</span>
          <input
            value={props.apiSearch}
            onChange={event => props.onApiSearch(event.target.value)}
            type="search"
            placeholder="Name, owner, lifecycle, path…"
          />
          <small>Filters API metadata without opening operations.</small>
        </label>

        <label>
          <span>Search endpoints</span>
          <input
            value={props.endpointSearch}
            onChange={event => props.onEndpointSearch(event.target.value)}
            type="search"
            placeholder="Method, route, summary, tag…"
          />
          <small>Shows APIs containing matching endpoints.</small>
        </label>
      </div>

      <label className="dashboard-sort-control">
        <span>Sort APIs</span>
        <select value={props.sort} onChange={event => props.onSort(event.target.value)}>
          <option value="name">Name</option>
          <option value="updated">Recently updated</option>
          <option value="operations">Most endpoints</option>
        </select>
      </label>

      <div className="sidebar-help dashboard-scope-note">
        <strong>Catalog scope</strong>
        <span>JSON and YAML files are scanned recursively and included only when their contents are valid OpenAPI documents.</span>
      </div>
    </section>
  </aside>
}
