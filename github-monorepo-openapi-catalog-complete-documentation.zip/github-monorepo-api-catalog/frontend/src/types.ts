export interface Workspace { id: string; name: string; type?: string }
export interface RequestField { name: string; path?: string; location?: string; type?: string; required?: boolean; description?: string }
export interface RequestBodyExample { contentType?: string; example: unknown }
export interface Operation {
  method: string; path: string; summary?: string; description?: string; operationId?: string;
  tags?: string[]; requestFields?: RequestField[]; requestBodyExample?: RequestBodyExample;
}
export interface ApiItem {
  id: string; name: string; description?: string; catalogDescription?: string; owner?: string;
  lifecycle?: string; domain?: string; workspace: Workspace; tags?: string[]; servers?: string[]; securitySchemes?: string[]; operations?: Operation[];
  version?: string; operationCount?: number | null; updatedAt?: string; detailsLoaded?: boolean;
  definitionText?: string; definitionParsed?: boolean;
  repository?: string; sourceProvider?: string; sourcePath?: string; sourceUrl?: string;
  sourceRef?: string; sourceSha?: string;
}
export interface CatalogPayload {
  apis: ApiItem[]; apiCount: number; workspaceCount: number; loadMilliseconds?: number;
  workspaces?: Workspace[]; errors?: unknown[];
  source?: {
    provider: string
    repository: string
    ref: string
    private?: boolean
    webUrl?: string
    searchRoot?: string
    extensions?: string[]
    discovery?: {
      repository?: string
      ref?: string
      searchRoot?: string
      configuredExtensions?: string[]
      recursiveTreeTruncated?: boolean
      traversalMode?: string
      totalTreeEntries?: number
      totalBlobs?: number
      extensionCandidateCount?: number
      extensionCandidatePaths?: string[]
      matchedSpecCount?: number
      matchedPaths?: string[]
      rejectedFileCount?: number
      rejectedFiles?: Array<{ path: string; reason: string }>
      excludedBySearchRootCount?: number
      excludedBySearchRootPaths?: string[]
    }
  }
}


export type CatalogFacetKey = 'method' | 'lifecycle' | 'domain' | 'owner' | 'auth' | 'tag'
export interface CatalogFacetFilters {
  method: string
  lifecycle: string
  domain: string
  owner: string
  auth: string
  tag: string
}
export interface FacetOption { value: string; label: string; count: number }
export type CatalogFacetOptions = Record<CatalogFacetKey, FacetOption[]>
