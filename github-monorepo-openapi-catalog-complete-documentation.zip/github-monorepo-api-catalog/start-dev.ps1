$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $VenvPython)) {
    throw "The Python virtual environment is missing. Run setup.bat first."
}
if (-not (Test-Path "frontend\node_modules")) {
    throw "Frontend dependencies are missing. Run setup.bat first."
}

# Read the same backend host/port used by Flask and Vite.
$CatalogHost = "127.0.0.1"
$CatalogPort = "8080"
if (Test-Path ".env") {
    foreach ($line in Get-Content ".env") {
        if ($line -match '^\s*CATALOG_HOST=(.+?)\s*$') {
            $CatalogHost = $Matches[1].Trim()
        }
        if ($line -match '^\s*CATALOG_PORT=(.+?)\s*$') {
            $CatalogPort = $Matches[1].Trim()
        }
    }
}

$BackendBaseUrl = "http://${CatalogHost}:${CatalogPort}"
$HealthUrl = "${BackendBaseUrl}/api/health"
$SourceHealthUrl = "${BackendBaseUrl}/api/source-health"

Write-Host "Starting backend at $BackendBaseUrl" -ForegroundColor Cyan
$backendCommand = "& '$VenvPython' backend\run.py"
$backendProcess = Start-Process powershell.exe `
    -ArgumentList @("-NoExit", "-NoProfile", "-Command", "Set-Location '$ProjectRoot'; $backendCommand") `
    -PassThru

try {
    Write-Host "Waiting for the backend to become available..." -ForegroundColor Cyan
    $backendReady = $false

    for ($attempt = 1; $attempt -le 30; $attempt++) {
        if ($backendProcess.HasExited) {
            throw "The backend process exited before it became available."
        }

        try {
            $response = Invoke-WebRequest `
                -Uri $HealthUrl `
                -UseBasicParsing `
                -TimeoutSec 2 `
                -ErrorAction Stop

            if ($response.StatusCode -ge 200 -and $response.StatusCode -lt 500) {
                $backendReady = $true
                break
            }
        } catch {
            Start-Sleep -Milliseconds 500
        }
    }

    if (-not $backendReady) {
        throw "The backend did not respond at $HealthUrl. Check the backend PowerShell window for its error."
    }

    Write-Host "Verifying GitHub repository access..." -ForegroundColor Cyan
    try {
        $sourceResponse = Invoke-RestMethod `
            -Uri $SourceHealthUrl `
            -TimeoutSec 30 `
            -ErrorAction Stop

        if ($sourceResponse.status -ne "ok") {
            throw ($sourceResponse.error | Out-String)
        }

        $authMode = if ($sourceResponse.authenticated) { "token authenticated" } else { "anonymous public access" }
        Write-Host "GitHub source ready: $($sourceResponse.repository) @ $($sourceResponse.ref) ($authMode)" -ForegroundColor Green
    } catch {
        throw "GitHub repository access failed at $SourceHealthUrl. Check GITHUB_REPOSITORY_URL and GITHUB_ACCESS_TOKEN in .env. $($_.Exception.Message)"
    }

    Write-Host "Backend is ready. Starting frontend at http://127.0.0.1:5173" -ForegroundColor Green
    Push-Location frontend
    npm run dev
    if ($LASTEXITCODE -ne 0) {
        throw "The frontend development server exited with code $LASTEXITCODE."
    }
} finally {
    if ((Get-Location).Path -like "*\frontend") {
        Pop-Location
    }
    if ($backendProcess -and -not $backendProcess.HasExited) {
        Stop-Process -Id $backendProcess.Id -ErrorAction SilentlyContinue
    }
}
