#!/usr/bin/env bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_ROOT"
command -v node >/dev/null || { echo "Node.js 22+ is required." >&2; exit 1; }
command -v npm >/dev/null || { echo "NPM is required." >&2; exit 1; }
PYTHON="$(command -v python3 || command -v python || true)"
[[ -n "$PYTHON" ]] || { echo "Python 3.11+ is required." >&2; exit 1; }
if [[ ! -f .env ]]; then
  cp .env.example .env
  echo "Created .env. Set GITHUB_REPOSITORY_URL and GITHUB_ACCESS_TOKEN, then rerun."
  exit 0
fi
if grep -q 'organization/platform-monorepo' .env || grep -q 'replace-with-github-access-token' .env; then
  echo "Set GITHUB_REPOSITORY_URL and GITHUB_ACCESS_TOKEN in .env, then rerun." >&2
  exit 1
fi
"$PYTHON" -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r backend/requirements.txt
npm install
npm --prefix frontend install
.venv/bin/python -c 'from dotenv import load_dotenv; load_dotenv(); import sys; sys.path.insert(0,"backend"); import config; from github_client import GitHubMonorepoClient; print(GitHubMonorepoClient(config.GITHUB_REPOSITORY_URL, config.GITHUB_ACCESS_TOKEN).health())'
npm --prefix frontend run build
echo "Setup complete. Run ./start-dev.sh"
