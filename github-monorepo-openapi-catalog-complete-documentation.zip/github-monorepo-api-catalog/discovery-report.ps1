$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $VenvPython)) {
    throw "The Python virtual environment is missing. Run setup.bat first."
}

Write-Host "Scanning the configured GitHub repository..." -ForegroundColor Cyan
& $VenvPython "backend\verify_installation.py" "discovery"
if ($LASTEXITCODE -ne 0) {
    throw "Discovery reporting failed with exit code $LASTEXITCODE."
}
