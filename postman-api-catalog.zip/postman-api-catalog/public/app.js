const state = { apis: [], search: "", type: "" };

const catalogElement = document.querySelector("#catalog");
const statusElement = document.querySelector("#status");
const summaryElement = document.querySelector("#summary");
const searchInput = document.querySelector("#searchInput");
const typeFilter = document.querySelector("#typeFilter");
const refreshButton = document.querySelector("#refreshButton");
const cardTemplate = document.querySelector("#apiCardTemplate");

function searchableText(api) {
    const operations = api.operations
        .map(operation => [
            operation.method,
            operation.path,
            operation.summary,
            operation.operationId,
            ...(operation.tags || [])
        ].join(" "))
        .join(" ");

    return [
        api.name,
        api.description,
        api.version,
        api.type,
        ...(api.tags || []),
        ...(api.servers || []),
        operations
    ].join(" ").toLowerCase();
}

function formatDate(value) {
    if (!value) return "Unknown";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;
    return new Intl.DateTimeFormat(undefined, {
        year: "numeric", month: "short", day: "numeric"
    }).format(date);
}

function renderTags(container, tags) {
    container.replaceChildren();
    for (const tag of tags || []) {
        const element = document.createElement("span");
        element.className = "tag";
        element.textContent = tag;
        container.append(element);
    }
}

function renderOperations(container, operations) {
    container.replaceChildren();
    if (!operations.length) {
        const empty = document.createElement("p");
        empty.textContent = "No operations were found.";
        container.append(empty);
        return;
    }

    for (const operation of operations) {
        const row = document.createElement("div");
        row.className = "operation";

        const method = document.createElement("span");
        method.className = `method method-${operation.method.toLowerCase()}`;
        method.textContent = operation.method;

        const path = document.createElement("code");
        path.textContent = operation.path;

        const summary = document.createElement("span");
        summary.className = "operation-summary";
        summary.textContent = operation.summary || operation.operationId || "No description";

        row.append(method, path, summary);
        container.append(row);
    }
}

function renderCatalog() {
    const query = state.search.trim().toLowerCase();
    const filtered = state.apis.filter(api => {
        const matchesType = !state.type || api.type === state.type;
        const matchesSearch = !query || searchableText(api).includes(query);
        return matchesType && matchesSearch;
    });

    catalogElement.replaceChildren();

    for (const api of filtered) {
        const fragment = cardTemplate.content.cloneNode(true);
        fragment.querySelector(".api-name").textContent = api.name;
        fragment.querySelector(".api-description").textContent = api.description || "No description provided.";
        fragment.querySelector(".api-type").textContent = api.type;
        fragment.querySelector(".api-version").textContent = api.version || "Unspecified";
        fragment.querySelector(".api-operation-count").textContent = api.operationCount;
        fragment.querySelector(".api-updated").textContent = formatDate(api.updatedAt);
        renderTags(fragment.querySelector(".tags"), api.tags);
        renderOperations(fragment.querySelector(".operations"), api.operations);
        catalogElement.append(fragment);
    }

    statusElement.textContent = `${filtered.length} of ${state.apis.length} APIs shown`;
}

function populateTypes() {
    const types = [...new Set(state.apis.map(api => api.type).filter(Boolean))].sort();
    typeFilter.querySelectorAll("option:not(:first-child)").forEach(option => option.remove());
    for (const type of types) {
        const option = document.createElement("option");
        option.value = type;
        option.textContent = type;
        typeFilter.append(option);
    }
}

async function loadCatalog() {
    refreshButton.disabled = true;
    statusElement.textContent = "Loading catalog…";

    try {
        const response = await fetch("/api/catalog", {
            headers: { "Accept": "application/json" }
        });
        const payload = await response.json();
        if (!response.ok) {
            throw new Error(payload.details || payload.error || `HTTP ${response.status}`);
        }
        state.apis = payload.apis;
        summaryElement.textContent = `${payload.count} specifications available`;
        populateTypes();
        renderCatalog();
    } catch (error) {
        statusElement.textContent = `Unable to load catalog: ${error.message}`;
    } finally {
        refreshButton.disabled = false;
    }
}

searchInput.addEventListener("input", event => {
    state.search = event.target.value;
    renderCatalog();
});

typeFilter.addEventListener("change", event => {
    state.type = event.target.value;
    renderCatalog();
});

refreshButton.addEventListener("click", loadCatalog);
loadCatalog();
