import json
import os
import urllib.error
import urllib.parse
import urllib.request
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

POSTMAN_BASE_URL = "https://api.postman.com"
POSTMAN_API_KEY = os.environ.get("POSTMAN_API_KEY", "")
PUBLIC_DIRECTORY = Path(__file__).parent / "public"


def postman_get(path: str, query: dict | None = None):
    if not POSTMAN_API_KEY:
        raise RuntimeError("POSTMAN_API_KEY is not configured")

    url = f"{POSTMAN_BASE_URL}{path}"

    if query:
        clean_query = {
            key: value
            for key, value in query.items()
            if value is not None and value != ""
        }
        url += "?" + urllib.parse.urlencode(clean_query)

    request = urllib.request.Request(
        url,
        headers={
            "x-api-key": POSTMAN_API_KEY,
            "Accept": "application/json",
            "User-Agent": "internal-postman-catalog/1.0",
        },
        method="GET",
    )

    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            return json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        body = error.read().decode("utf-8", errors="replace")
        raise RuntimeError(
            f"Postman returned HTTP {error.code}: {body}"
        ) from error
    except urllib.error.URLError as error:
        raise RuntimeError(f"Unable to reach Postman: {error.reason}") from error


def get_all_specs():
    specifications = []
    limit = 100
    offset = 0

    while True:
        payload = postman_get(
            "/specs",
            {
                "limit": limit,
                "offset": offset,
            },
        )

        page = (
            payload.get("specs")
            or payload.get("data")
            or payload.get("specifications")
            or []
        )

        specifications.extend(page)

        if len(page) < limit:
            break

        offset += limit

    return specifications


def get_spec_definition(spec_id: str):
    payload = postman_get(f"/specs/{urllib.parse.quote(spec_id)}/definition")
    definition = payload.get("definition", payload)

    if isinstance(definition, str):
        try:
            return json.loads(definition)
        except json.JSONDecodeError:
            return {
                "raw": definition,
                "format": "yaml-or-text",
            }

    return definition


def normalize_spec(spec: dict):
    spec_id = str(
        spec.get("id")
        or spec.get("uid")
        or spec.get("specId")
        or ""
    )

    workspace = spec.get("workspace") or {}

    record = {
        "id": spec_id,
        "name": spec.get("name") or spec.get("title") or "Unnamed API",
        "type": spec.get("type") or spec.get("schemaType") or "unknown",
        "workspaceId": spec.get("workspaceId") or workspace.get("id"),
        "updatedAt": spec.get("updatedAt") or spec.get("updated_at"),
        "description": spec.get("description") or "",
        "version": "",
        "servers": [],
        "tags": [],
        "operations": [],
        "operationCount": 0,
        "definitionAvailable": False,
    }

    if not spec_id:
        return record

    try:
        definition = get_spec_definition(spec_id)
        record["definitionAvailable"] = True

        if not isinstance(definition, dict):
            return record

        info = definition.get("info", {})
        record["name"] = info.get("title") or record["name"]
        record["description"] = info.get("description") or record["description"]
        record["version"] = info.get("version") or ""

        record["servers"] = [
            server.get("url")
            for server in definition.get("servers", [])
            if isinstance(server, dict) and server.get("url")
        ]

        root_tags = definition.get("tags", [])
        record["tags"] = [
            tag.get("name")
            for tag in root_tags
            if isinstance(tag, dict) and tag.get("name")
        ]

        operation_methods = {
            "get", "post", "put", "patch", "delete",
            "head", "options", "trace",
        }

        for path, path_item in definition.get("paths", {}).items():
            if not isinstance(path_item, dict):
                continue

            for method, operation in path_item.items():
                if method.lower() not in operation_methods:
                    continue

                operation = operation if isinstance(operation, dict) else {}
                record["operations"].append(
                    {
                        "method": method.upper(),
                        "path": path,
                        "summary": operation.get("summary", ""),
                        "operationId": operation.get("operationId", ""),
                        "deprecated": operation.get("deprecated", False),
                        "tags": operation.get("tags", []),
                    }
                )

        record["operationCount"] = len(record["operations"])

    except RuntimeError as error:
        record["definitionError"] = str(error)

    return record


def build_catalog():
    specs = get_all_specs()
    catalog = [normalize_spec(spec) for spec in specs]
    catalog.sort(key=lambda item: item["name"].lower())

    return {
        "count": len(catalog),
        "apis": catalog,
    }


class CatalogHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(PUBLIC_DIRECTORY), **kwargs)

    def send_json(self, status: int, payload):
        body = json.dumps(payload, indent=2).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)

        if parsed.path == "/api/catalog":
            try:
                self.send_json(200, build_catalog())
            except RuntimeError as error:
                self.send_json(
                    502,
                    {
                        "error": "Unable to build Postman catalog",
                        "details": str(error),
                    },
                )
            return

        if parsed.path.startswith("/api/specs/"):
            spec_id = parsed.path.removeprefix("/api/specs/").strip("/")
            try:
                self.send_json(200, get_spec_definition(spec_id))
            except RuntimeError as error:
                self.send_json(
                    502,
                    {
                        "error": "Unable to retrieve specification",
                        "details": str(error),
                    },
                )
            return

        super().do_GET()


if __name__ == "__main__":
    if not POSTMAN_API_KEY:
        raise SystemExit(
            "Set the POSTMAN_API_KEY environment variable before starting."
        )

    server = ThreadingHTTPServer(("127.0.0.1", 8080), CatalogHandler)
    print("API Catalog available at http://localhost:8080")
    server.serve_forever()
