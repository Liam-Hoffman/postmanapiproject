if (-not $env:POSTMAN_API_KEY) {
    Write-Host "Set your Postman API key first:" -ForegroundColor Yellow
    Write-Host '$env:POSTMAN_API_KEY = "PMAK-your-key"'
    exit 1
}

python .\server.py
