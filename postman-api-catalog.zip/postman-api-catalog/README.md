# Postman API Catalog Dashboard

A no-`npm` internal API catalog built with:

- Python standard library backend
- Vanilla HTML, CSS, and JavaScript
- Postman API / Spec Hub data

## Requirements

- Python 3.10 or newer
- A Postman API key with access to the specifications you want to display

## Run on Windows PowerShell

```powershell
cd postman-api-catalog
$env:POSTMAN_API_KEY = "PMAK-your-key"
.\start.ps1
```

Then open:

```text
http://localhost:8080
```

You may also run it directly:

```powershell
python .\server.py
```

## Security

Do not place the Postman API key in `app.js` or other browser files. The browser calls the local Python backend, which securely adds the `x-api-key` header when requesting Postman data.

## Endpoints

- `GET /api/catalog` — normalized catalog payload
- `GET /api/specs/{specId}` — raw specification definition

## Project structure

```text
postman-api-catalog/
├── server.py
├── start.ps1
├── README.md
└── public/
    ├── index.html
    ├── app.js
    └── styles.css
```
