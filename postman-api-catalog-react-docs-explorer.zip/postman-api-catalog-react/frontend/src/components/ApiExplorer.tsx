import { useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import type { ApiItem, Operation, RequestField } from '../types'
import { formatDate, htmlToText } from '../lib/text'

const METHOD_ORDER = ['GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS','TRACE']
interface FieldNode { field: RequestField; children: FieldNode[] }
function parentPath(path:string){const i=path.lastIndexOf('.');return i===-1?'':path.slice(0,i)}
function buildTree(fields:RequestField[]){const nodes=new Map<string,FieldNode>();const roots:FieldNode[]=[];fields.forEach((f,i)=>{const p=f.path||f.name||`field-${i}`;nodes.set(p,{field:{...f,path:p},children:[]})});nodes.forEach((n,p)=>{const parent=nodes.get(parentPath(p));parent?parent.children.push(n):roots.push(n)});return roots}
function opId(op:Operation,index:number){return `${op.method.toLowerCase()}-${(op.operationId||op.summary||op.path||String(index)).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/(^-|-$)/g,'')}`}
function opText(op:Operation){return [op.method,op.path,op.summary,op.description,op.operationId,...(op.tags||[]),...(op.requestFields||[]).flatMap(f=>[f.path,f.name,f.description,f.type])].filter(Boolean).join(' ').toLowerCase()}

export function ApiExplorer({api}:{api:ApiItem}){
  const [search,setSearch]=useState('')
  const [tab,setTab]=useState<'reference'|'spec'>('reference')
  const query=search.trim().toLowerCase()
  const operations=useMemo(()=>(api.operations||[]).filter(op=>!query||opText(op).includes(query)),[api.operations,query])
  const groups=useMemo(()=>METHOD_ORDER.map(method=>[method,operations.filter(op=>op.method.toUpperCase()===method)] as const).filter(([,ops])=>ops.length),[operations])
  return <div className="explorer-shell">
    <nav className="operation-nav">
      <input type="search" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search this API…" />
      <button className={tab==='reference'?'nav-tab active':'nav-tab'} onClick={()=>setTab('reference')}>Overview & operations</button>
      <button className={tab==='spec'?'nav-tab active':'nav-tab'} onClick={()=>setTab('spec')}>Raw specification</button>
      {tab==='reference'&&<div className="operation-tree">{groups.map(([method,ops])=><details key={method} open>
        <summary><span className={`method method-${method.toLowerCase()}`}>{method}</span><strong>{method}</strong><span>{ops.length}</span></summary>
        {ops.map((op,index)=><a key={opId(op,index)} href={`#${opId(op,index)}`}>{op.summary||op.operationId||op.path}</a>)}
      </details>)}</div>}
    </nav>
    <article className="reference-pane">
      {tab==='spec'?<><div className="reference-actions"><button className="secondary" onClick={()=>navigator.clipboard.writeText(api.definitionText||'')}>Copy specification</button></div><pre className="spec"><code>{api.definitionText||'Specification unavailable.'}</code></pre></>:<>
        <section className="api-overview"><div className="eyebrow">{api.workspace.name}</div><h1>{api.name}</h1>{api.description&&<p>{htmlToText(api.description)}</p>}
          <div className="detail-summary"><div><strong>Version</strong><span>{api.version||'Unspecified'}</span></div><div><strong>Owner</strong><span>{api.owner||'Unspecified'}</span></div><div><strong>Operations</strong><span>{api.operationCount??operations.length}</span></div><div><strong>Updated</strong><span>{formatDate(api.updatedAt)}</span></div></div>
        </section>
        {!!api.servers?.length&&<section><h3>Servers</h3><div className="server-list">{api.servers.map(server=><code key={server}>{server}</code>)}</div></section>}
        <section><div className="section-title-row"><h3>Operations</h3><span>{operations.length} shown</span></div>{groups.map(([method,ops])=><details className="operation-group reference-group" key={method} open>
          <summary><span className={`method method-${method.toLowerCase()}`}>{method}</span><strong>{method} operations</strong><span className="operation-count">{ops.length}</span><span className="group-chevron">›</span></summary>
          <div className="operation-group-content">{ops.map((op,index)=><OperationCard key={opId(op,index)} op={op} id={opId(op,index)} expandAll={Boolean(query)}/>)}</div>
        </details>)}</section>
      </>}
    </article>
  </div>
}

function FieldTable({fields,expandAll}:{fields:RequestField[];expandAll:boolean}){
  const tree=useMemo(()=>buildTree(fields),[fields]);const [expanded,setExpanded]=useState<Set<string>>(new Set())
  function toggle(path:string){setExpanded(current=>{const next=new Set(current);next.has(path)?next.delete(path):next.add(path);return next})}
  function rows(nodes:FieldNode[],depth=0):ReactNode[]{return nodes.flatMap(node=>{const path=node.field.path||node.field.name;const children=node.children.length>0;const open=expandAll||expanded.has(path);const row=<tr key={path} className={`${node.field.required?'required-field-row':''} ${children?'object-field-row':''}`}><td><div className="field-name-cell" style={{paddingLeft:depth*22}}>{children?<button className="field-expander" aria-expanded={open} onClick={()=>toggle(path)}><span className="field-chevron">›</span></button>:<span className="field-expander-spacer"/>}<div><div className="field-code-line"><code>{node.field.name||path.split('.').at(-1)}</code>{node.field.required&&<span className="required-asterisk">*</span>}{children&&<span className="object-pill">{node.children.length} fields</span>}</div>{node.field.description&&<small>{htmlToText(node.field.description)}</small>}</div></div></td><td>{node.field.location||'body'}</td><td><code>{node.field.type||'unknown'}</code></td><td>{node.field.required?<span className="required-badge"><span>*</span> Required</span>:<span className="optional-badge">Optional</span>}</td></tr>;return children&&open?[row,...rows(node.children,depth+1)]:[row]})}
  return <div className="table-wrap"><table className="request-fields-table"><thead><tr><th>Field</th><th>In</th><th>Type</th><th>Importance</th></tr></thead><tbody>{rows(tree)}</tbody></table></div>
}
function OperationCard({op,id,expandAll}:{op:Operation;id:string;expandAll:boolean}){return <article className="operation" id={id}><div className="operation-title"><span className={`method method-${op.method.toLowerCase()}`}>{op.method}</span><code>{op.path}</code><a className="anchor-link" href={`#${id}`}>#</a></div><h4>{op.summary||op.operationId||'No summary'}</h4>{op.description&&<p>{htmlToText(op.description)}</p>}{!!op.requestFields?.length&&<FieldTable fields={op.requestFields} expandAll={expandAll}/>} {op.requestBodyExample?<div className="example"><strong>Example request body</strong><pre><code>{typeof op.requestBodyExample.example==='string'?op.requestBodyExample.example:JSON.stringify(op.requestBodyExample.example,null,2)}</code></pre></div>:!['GET','HEAD','OPTIONS','TRACE'].includes(op.method.toUpperCase())&&<p className="muted">No request body is defined for this operation.</p>}</article>}
