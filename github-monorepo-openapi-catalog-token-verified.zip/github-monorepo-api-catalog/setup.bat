@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title GitHub Monorepo API Catalog - First-Time Setup

echo.
echo ============================================================
echo   GitHub Monorepo API Catalog - First-Time Setup
echo ============================================================
echo.

where powershell.exe >nul 2>&1
if errorlevel 1 (
    echo ERROR: Windows PowerShell was not found.
    echo This setup requires Windows PowerShell 5.1 or newer.
    echo.
    pause
    exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1" %*
set "SETUP_EXIT=%ERRORLEVEL%"

if not "%SETUP_EXIT%"=="0" (
    echo.
    echo ============================================================
    echo   SETUP FAILED
    echo ============================================================
    echo Review the error above, correct it, and run setup.bat again.
    echo.
    pause
    exit /b %SETUP_EXIT%
)

echo.
echo ============================================================
echo   SETUP COMPLETED SUCCESSFULLY
echo ============================================================
echo.
echo Run start-dev.bat to launch the catalog.
echo.
pause
exit /b 0
