# GitHub Monorepo API Catalog

A local React, TypeScript, Vite, Flask, and Python API catalog that discovers OpenAPI documents from one GitHub monorepo.

## Discovery behavior

The backend scans the repository tree recursively and includes files whose names match, case-insensitively:

- `openapi.json`
- `openapi.yml`
- `openapi.yaml`

The files may appear at any directory depth. Every containing folder becomes a catalog group. The OpenAPI document supplies the API title, description, version, endpoints, request fields, examples, servers, tags, authentication schemes, and optional catalog metadata.

When GitHub reports that a recursive tree response is truncated, the provider walks every subtree explicitly so deeply nested specification files are still discovered.

## Supported OpenAPI metadata

Standard fields are read from `info`, `paths`, `components`, and related OpenAPI structures. These optional extensions improve catalog metadata:

```yaml
info:
  title: Payments API
  version: 2.0.0
  description: Payment processing operations
  x-owner-team: Payments Platform
  x-lifecycle: production
  x-domain: Payments
  x-support-channel: "#payments-api-support"
```

The parser supports OpenAPI JSON and YAML, including OpenAPI 2/Swagger-style body parameters. Local JSON Pointer references such as `#/components/schemas/Payment` are resolved. External relative `$ref` files are not bundled in this version.

## GitHub authentication

Public repositories can be read without a token, although authenticated access has better rate limits. Private repositories require `GITHUB_TOKEN`.

Use a fine-grained personal access token or GitHub App installation token with read-only access to repository contents. Keep the token only in the backend `.env`; it is never sent to the browser.

GitHub Enterprise Server is supported by changing:

```env
GITHUB_API_URL=https://github.example.com/api/v3
GITHUB_WEB_URL=https://github.example.com
```

## First-time Windows setup

Run:

```bat
setup.bat
```

The script:

1. Checks Node.js 22+, NPM, and Python 3.11+.
2. Creates `.env`.
3. Prompts for the GitHub owner, monorepo name, optional ref, and optional token.
4. Creates `.venv`.
5. Installs backend and frontend dependencies.
6. Verifies GitHub repository access.
7. Runs a frontend production build.

Then start the local application:

```bat
start-dev.bat
```

The frontend is available at `http://127.0.0.1:5173`; Flask runs at `http://127.0.0.1:8080`. Both remain local-only with the default configuration.

## Configuration

```env
GITHUB_API_URL=https://api.github.com
GITHUB_WEB_URL=https://github.com
GITHUB_API_VERSION=2022-11-28
GITHUB_OWNER=your-organization
GITHUB_REPO=your-monorepo
GITHUB_REF=
GITHUB_TOKEN=
GITHUB_SEARCH_ROOT=
GITHUB_OPENAPI_FILENAMES=openapi.json,openapi.yml,openapi.yaml

CATALOG_HOST=127.0.0.1
CATALOG_PORT=8080
CATALOG_CACHE_TTL_SECONDS=900
```

`GITHUB_REF` may be a branch, tag, or commit SHA. Leaving it blank uses the repository default branch.

`GITHUB_SEARCH_ROOT` can limit scanning to a directory prefix such as `services/apis`. Leaving it blank scans the entire repository.

## API routes

- `GET /api/health`
- `GET /api/source-health`
- `GET /api/catalog`
- `GET /api/catalog?refresh=true`
- `GET /api/specs/{catalogId}`
- `GET /api/workspaces` — compatibility route returning repository folders

## Source layout

```text
backend/
  app.py
  catalog.py
  config.py
  github_client.py
frontend/
  src/
setup.bat
setup.ps1
start-dev.bat
start-dev.ps1
```

The frontend still consumes the same normalized catalog contract, so search, endpoint previews, operation navigation, nested request fields, theming, and the detailed API view do not depend on GitHub-specific response shapes.

## Versioned API names

Once an OpenAPI definition is loaded, the application extracts the first numeric segment from `info.version` and appends it as an uppercase major version, such as `Payments API V2`. If the title already contains `V2` or `Version 2`, it is not appended again.

## Token use and verification

When `GITHUB_TOKEN` is configured, the backend adds it to outbound GitHub API requests as an `Authorization: Bearer ...` header. The token is stored only in the root `.env`, which is ignored by Git, and is never returned to the browser. A token is required for private repositories and optional for public repositories.

`start-dev.bat` verifies both the local Flask health endpoint and GitHub repository access before starting Vite. It reports whether access is token-authenticated or anonymous without revealing the token.

Run this at any time to re-check backend imports, GitHub access, retained UI features, TypeScript, and the Vite production build:

```bat
verify.bat
```
