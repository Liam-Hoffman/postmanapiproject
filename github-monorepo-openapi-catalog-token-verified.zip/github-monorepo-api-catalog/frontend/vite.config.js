import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
export default defineConfig(function (_a) {
    var mode = _a.mode;
    // Load the same root .env file used by Flask so both services always agree.
    var env = loadEnv(mode, '..', '');
    var backendHost = env.CATALOG_HOST || '127.0.0.1';
    var backendPort = env.CATALOG_PORT || '8080';
    var apiTarget = env.VITE_API_TARGET || "http://".concat(backendHost, ":").concat(backendPort);
    return {
        envDir: '..',
        plugins: [react()],
        server: {
            host: '127.0.0.1',
            port: 5173,
            strictPort: true,
            proxy: {
                '/api': {
                    target: apiTarget,
                    changeOrigin: true,
                },
            },
        },
    };
});
