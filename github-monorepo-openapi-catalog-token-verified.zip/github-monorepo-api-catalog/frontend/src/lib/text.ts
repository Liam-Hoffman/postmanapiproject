import type { ApiItem } from '../types'

export function htmlToText(value = ''): string {
  const document = new DOMParser().parseFromString(value, 'text/html')
  return (document.body.textContent || '').replace(/\s+/g, ' ').trim()
}

export function searchable(api: ApiItem): string {
  const operations = Array.isArray(api.operations) ? api.operations : []
  const version = String(api.version || '').trim()
  const majorVersion = version.match(/\d+/)?.[0]
  const displayName = majorVersion ? `${api.name} V${majorVersion}` : api.name

  const operationText = operations
    .map(operation =>
      [
        operation.method,
        operation.path,
        operation.summary,
        operation.description,
        operation.operationId,
        ...(Array.isArray(operation.tags) ? operation.tags : []),
      ]
        .filter(Boolean)
        .join(' ')
    )
    .join(' ')

  return [
    displayName,
    api.name,
    api.description,
    api.version,
    api.lifecycle,
    api.owner,
    api.domain,
    api.workspace?.name,
    api.repository,
    api.sourcePath,
    api.sourceRef,
    ...(api.tags || []),
    ...(api.securitySchemes || []),
    operationText,
  ]
    .filter(Boolean)
    .join(' ')
    .toLowerCase()
}

export function formatDate(value?: string): string {
  if (!value) return 'Unknown'
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(date)
}
