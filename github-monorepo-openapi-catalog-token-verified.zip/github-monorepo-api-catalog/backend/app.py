from __future__ import annotations

import os
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

import config
from catalog import CatalogService
from github_client import GitHubAPIError, GitHubMonorepoClient

BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIST = BASE_DIR.parent / "frontend" / "dist"


def create_app() -> Flask:
    app = Flask(__name__, static_folder=None)

    service: CatalogService | None = None
    service_error = ""
    try:
        if config.GITHUB_OWNER and config.GITHUB_REPO:
            service = CatalogService(
                GitHubMonorepoClient(
                    owner=config.GITHUB_OWNER,
                    repo=config.GITHUB_REPO,
                    token=config.GITHUB_TOKEN,
                    ref=config.GITHUB_REF,
                )
            )
        else:
            service_error = (
                "GITHUB_OWNER and GITHUB_REPO are not configured. "
                "Copy .env.example to .env and provide the monorepo details."
            )
    except ValueError as exc:
        service_error = str(exc)

    def require_service() -> CatalogService:
        if service is None:
            raise ValueError(service_error or "GitHub catalog is not configured.")
        return service

    @app.get("/api/health")
    def health():
        payload = {
            "status": "ok",
            "environment": os.getenv("APP_ENV", "development"),
            "provider": "github",
        }
        if service is not None:
            payload["repository"] = service.client.repository_name
        return jsonify(payload)

    @app.get("/api/source-health")
    def source_health():
        try:
            return jsonify(require_service().client.health())
        except (GitHubAPIError, ValueError) as exc:
            return jsonify(
                {
                    "status": "error",
                    "error": str(exc),
                    "upstreamUrl": getattr(exc, "url", ""),
                }
            ), 502

    @app.get("/api/catalog")
    def catalog():
        force = request.args.get("refresh", "false").lower() in {
            "1", "true", "yes"
        }
        try:
            return jsonify(require_service().get_catalog(force=force))
        except (GitHubAPIError, ValueError) as exc:
            return jsonify(
                {
                    "error": "Unable to load GitHub catalog",
                    "details": str(exc),
                    "upstreamUrl": getattr(exc, "url", ""),
                }
            ), 502
        except Exception as exc:
            return jsonify(
                {
                    "error": "Unexpected catalog error",
                    "details": str(exc),
                }
            ), 500

    @app.get("/api/specs/<path:spec_id>")
    def spec_detail(spec_id: str):
        force = request.args.get("refresh", "false").lower() in {
            "1", "true", "yes"
        }
        try:
            return jsonify(
                require_service().get_spec_detail(spec_id, force=force)
            )
        except KeyError as exc:
            return jsonify({"error": str(exc)}), 404
        except GitHubAPIError as exc:
            return jsonify(
                {
                    "error": "Unable to load GitHub specification",
                    "details": str(exc),
                    "upstreamUrl": getattr(exc, "url", ""),
                }
            ), 502
        except Exception as exc:
            return jsonify(
                {
                    "error": "Unexpected specification error",
                    "details": str(exc),
                }
            ), 500

    # Compatibility endpoint: frontend terminology is being kept stable.
    @app.get("/api/workspaces")
    def workspaces():
        try:
            values = require_service().get_groups()
            return jsonify(
                {
                    "workspaces": [
                        {"id": item.id, "name": item.name, "type": item.type}
                        for item in values
                    ]
                }
            )
        except (GitHubAPIError, ValueError) as exc:
            return jsonify(
                {
                    "error": str(exc),
                    "upstreamUrl": getattr(exc, "url", ""),
                }
            ), 502

    @app.get("/")
    @app.get("/<path:path>")
    def frontend(path: str = ""):
        if not FRONTEND_DIST.exists():
            return jsonify(
                {
                    "error": "Frontend build not found",
                    "details": (
                        "Run npm install and npm run build in frontend, "
                        "or use npm run dev for local development."
                    ),
                }
            ), 404
        candidate = FRONTEND_DIST / path
        if path and candidate.is_file():
            return send_from_directory(FRONTEND_DIST, path)
        return send_from_directory(FRONTEND_DIST, "index.html")

    return app


app = create_app()

if __name__ == "__main__":
    app.run(
        host=config.HOST,
        port=config.PORT,
        debug=os.getenv("APP_ENV", "development") == "development",
    )
