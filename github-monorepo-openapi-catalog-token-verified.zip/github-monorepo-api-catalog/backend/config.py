import os

GITHUB_API_URL = os.environ.get("GITHUB_API_URL", "https://api.github.com").rstrip("/")
GITHUB_WEB_URL = os.environ.get("GITHUB_WEB_URL", "https://github.com").rstrip("/")
GITHUB_API_VERSION = os.environ.get("GITHUB_API_VERSION", "2022-11-28").strip()
GITHUB_OWNER = os.environ.get("GITHUB_OWNER", "").strip()
GITHUB_REPO = os.environ.get("GITHUB_REPO", "").strip()
GITHUB_REF = os.environ.get("GITHUB_REF", "").strip()
GITHUB_TOKEN = os.environ.get("GITHUB_TOKEN", "").strip()
GITHUB_SEARCH_ROOT = os.environ.get("GITHUB_SEARCH_ROOT", "").strip().strip("/")
GITHUB_OPENAPI_FILENAMES = {
    value.strip().casefold()
    for value in os.environ.get(
        "GITHUB_OPENAPI_FILENAMES",
        "openapi.json,openapi.yml,openapi.yaml",
    ).split(",")
    if value.strip()
}
GITHUB_REQUEST_TIMEOUT_SECONDS = max(
    int(os.environ.get("GITHUB_REQUEST_TIMEOUT_SECONDS", "30")),
    1,
)
GITHUB_MAX_RETRIES = min(
    max(int(os.environ.get("GITHUB_MAX_RETRIES", "3")), 0),
    8,
)
GITHUB_RETRY_BUFFER_SECONDS = max(
    float(os.environ.get("GITHUB_RETRY_BUFFER_SECONDS", "1")),
    0.0,
)

HOST = os.environ.get("CATALOG_HOST", "127.0.0.1")
PORT = int(os.environ.get("CATALOG_PORT", "8080"))
CACHE_TTL_SECONDS = max(
    int(os.environ.get("CATALOG_CACHE_TTL_SECONDS", "900")),
    0,
)
