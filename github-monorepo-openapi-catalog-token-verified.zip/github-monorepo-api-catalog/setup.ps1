[CmdletBinding()]
param(
    [switch]$SkipInstall,
    [switch]$SkipBuild,
    [switch]$SkipGitHubCheck,
    [switch]$Start,
    [string]$GitHubOwner,
    [string]$GitHubRepo,
    [string]$GitHubRef,
    [string]$GitHubToken
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

function Write-Step([string]$Message) {
    Write-Host "`n==> $Message" -ForegroundColor Cyan
}

function Require-Path([string]$Path, [string]$Description) {
    if (-not (Test-Path $Path)) {
        throw "$Description was not found at: $Path"
    }
}

function Require-Command([string]$Name, [string]$InstallHint) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "$Name was not found. $InstallHint"
    }
}

function Invoke-Native {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Command,

        [Parameter(ValueFromRemainingArguments = $true)]
        [string[]]$Arguments
    )

    & $Command @Arguments
    if ($LASTEXITCODE -ne 0) {
        $argumentText = $Arguments -join " "
        throw "Command failed with exit code ${LASTEXITCODE}: $Command $argumentText"
    }
}

function Get-VersionMajor([string]$VersionText) {
    $match = [regex]::Match($VersionText, '(\d+)')
    if (-not $match.Success) { return 0 }
    return [int]$match.Groups[1].Value
}

function Get-PythonCommand {
    foreach ($candidate in @("py", "python", "python3")) {
        if (Get-Command $candidate -ErrorAction SilentlyContinue) {
            return $candidate
        }
    }
    return $null
}

function Invoke-SystemPython {
    param(
        [Parameter(ValueFromRemainingArguments = $true)]
        [string[]]$Arguments
    )

    if ($script:PythonCommand -eq "py") {
        Invoke-Native "py" @("-3") @Arguments
    } else {
        Invoke-Native $script:PythonCommand @Arguments
    }
}

function Get-EnvValue([string]$Name) {
    if (-not (Test-Path ".env")) { return "" }
    $pattern = "^\s*" + [regex]::Escape($Name) + "=(.*)$"
    foreach ($line in Get-Content ".env") {
        if ($line -match $pattern) {
            return $Matches[1].Trim()
        }
    }
    return ""
}

function Set-EnvValue([string]$Name, [string]$Value) {
    $envText = Get-Content ".env" -Raw
    $pattern = "(?m)^" + [regex]::Escape($Name) + "=.*$"
    $line = "$Name=$Value"

    if ($envText -match $pattern) {
        $envText = [regex]::Replace($envText, $pattern, $line)
    } else {
        $envText = $envText.TrimEnd() + "`r`n$line`r`n"
    }

    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText(
        (Join-Path $ProjectRoot ".env"),
        $envText,
        $utf8NoBom
    )
}

Write-Host "GitHub Monorepo API Catalog - first-time setup" -ForegroundColor Green

Write-Step "Checking project files"
Require-Path ".env.example" ".env.example"
Require-Path "backend\requirements.txt" "Backend requirements"
Require-Path "backend\run.py" "Backend entry point"
Require-Path "backend\github_client.py" "GitHub provider"
Require-Path "package.json" "Root package.json"
Require-Path "frontend\package.json" "Frontend package.json"

Write-Step "Checking prerequisites"
Require-Command "node" "Install Node.js 22 or newer, then rerun setup.bat."
Require-Command "npm" "Install NPM with Node.js, then rerun setup.bat."

$script:PythonCommand = Get-PythonCommand
if (-not $script:PythonCommand) {
    throw "Python was not found. Install Python 3.11 or newer and select 'Add Python to PATH', then rerun setup.bat."
}

$nodeVersion = (& node --version).Trim()
if ((Get-VersionMajor $nodeVersion) -lt 22) {
    throw "Node.js $nodeVersion is installed, but Node.js 22 or newer is required."
}

$pythonVersion = if ($script:PythonCommand -eq "py") {
    (& py -3 --version 2>&1).ToString().Trim()
} else {
    (& $script:PythonCommand --version 2>&1).ToString().Trim()
}
$pythonMatch = [regex]::Match($pythonVersion, '(\d+)\.(\d+)')
if (
    -not $pythonMatch.Success -or
    [int]$pythonMatch.Groups[1].Value -lt 3 -or
    (
        [int]$pythonMatch.Groups[1].Value -eq 3 -and
        [int]$pythonMatch.Groups[2].Value -lt 11
    )
) {
    throw "$pythonVersion is installed, but Python 3.11 or newer is required."
}

Write-Host "Node:   $nodeVersion"
Write-Host "NPM:    $((& npm --version).Trim())"
Write-Host "Python: $pythonVersion"

Write-Step "Preparing GitHub repository configuration"
if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host "Created .env from .env.example"
} else {
    Write-Host ".env already exists; preserving existing values"
}

$currentOwner = Get-EnvValue "GITHUB_OWNER"
if (-not $GitHubOwner -and (
    -not $currentOwner -or
    $currentOwner -eq "replace-with-owner-or-organization"
)) {
    $GitHubOwner = Read-Host "GitHub owner or organization"
}
if ($GitHubOwner) {
    Set-EnvValue "GITHUB_OWNER" $GitHubOwner.Trim()
}

$currentRepo = Get-EnvValue "GITHUB_REPO"
if (-not $GitHubRepo -and (
    -not $currentRepo -or
    $currentRepo -eq "replace-with-monorepo-name"
)) {
    $GitHubRepo = Read-Host "GitHub monorepo name"
}
if ($GitHubRepo) {
    Set-EnvValue "GITHUB_REPO" $GitHubRepo.Trim()
}

if ($PSBoundParameters.ContainsKey("GitHubRef")) {
    Set-EnvValue "GITHUB_REF" $GitHubRef.Trim()
} elseif (-not (Get-EnvValue "GITHUB_REF")) {
    $enteredRef = Read-Host "Branch, tag, or commit SHA (leave blank for default branch)"
    Set-EnvValue "GITHUB_REF" $enteredRef.Trim()
}

if ($PSBoundParameters.ContainsKey("GitHubToken")) {
    Set-EnvValue "GITHUB_TOKEN" $GitHubToken.Trim()
} elseif (-not (Get-EnvValue "GITHUB_TOKEN")) {
    $secureToken = Read-Host "GitHub token (optional for public repositories; input hidden)" -AsSecureString
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureToken)
    try {
        $tokenValue = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    } finally {
        [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
    }
    if ($tokenValue) {
        Set-EnvValue "GITHUB_TOKEN" $tokenValue.Trim()
    }
}

$finalOwner = Get-EnvValue "GITHUB_OWNER"
$finalRepo = Get-EnvValue "GITHUB_REPO"
if (
    -not $finalOwner -or
    $finalOwner -eq "replace-with-owner-or-organization" -or
    -not $finalRepo -or
    $finalRepo -eq "replace-with-monorepo-name"
) {
    throw "GITHUB_OWNER and GITHUB_REPO must be configured in .env."
}

$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"

if (-not $SkipInstall) {
    Write-Step "Creating the Python virtual environment"
    if (-not (Test-Path ".venv")) {
        Invoke-SystemPython "-m" "venv" ".venv"
    } else {
        Write-Host ".venv already exists; reusing it"
    }

    Require-Path $VenvPython "Virtual-environment Python"

    Write-Step "Installing backend dependencies"
    Invoke-Native $VenvPython "-m" "pip" "install" "--upgrade" "pip"
    Invoke-Native $VenvPython "-m" "pip" "install" "-r" "backend\requirements.txt"

    Write-Step "Verifying backend dependencies"
    Invoke-Native $VenvPython "-c" "import flask, dotenv, yaml; print('Backend imports verified')"

    Write-Step "Installing root development dependencies"
    if (Test-Path "package-lock.json") {
        Invoke-Native "npm" "ci"
    } else {
        Invoke-Native "npm" "install"
    }

    Write-Step "Installing frontend dependencies"
    if (Test-Path "frontend\package-lock.json") {
        Invoke-Native "npm" "--prefix" "frontend" "ci"
    } else {
        Invoke-Native "npm" "--prefix" "frontend" "install"
    }
} else {
    Write-Host "Dependency installation skipped because -SkipInstall was supplied"
    Require-Path $VenvPython "Virtual-environment Python"
}

Write-Step "Verifying backend application imports"
Invoke-Native $VenvPython "-c" "import sys; sys.path.insert(0, 'backend'); import app, catalog, github_client; print('Backend application import verified')"

if (-not $SkipGitHubCheck) {
    Write-Step "Verifying GitHub repository access"
    Invoke-Native $VenvPython "-c" "from dotenv import load_dotenv; load_dotenv(); import sys; sys.path.insert(0, 'backend'); import config; from github_client import GitHubMonorepoClient; client=GitHubMonorepoClient(config.GITHUB_OWNER, config.GITHUB_REPO, config.GITHUB_TOKEN, config.GITHUB_REF); print(client.health())"
} else {
    Write-Host "GitHub access verification skipped because -SkipGitHubCheck was supplied"
}

if (-not $SkipBuild) {
    Write-Step "Building the frontend to verify the installation"
    Invoke-Native "npm" "--prefix" "frontend" "run" "build"
} else {
    Write-Host "Frontend build verification skipped because -SkipBuild was supplied"
}

Write-Step "Setup complete"
Write-Host "Repository:       $finalOwner/$finalRepo"
Write-Host "Development site: http://127.0.0.1:5173"
Write-Host "Backend API:      http://127.0.0.1:8080"
Write-Host "Run start-dev.bat to start both services."

if ($Start) {
    Write-Step "Starting development servers"
    & "$ProjectRoot\start-dev.ps1"
}
