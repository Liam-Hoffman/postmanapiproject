from __future__ import annotations

import json
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any

import config


class PostmanAPIError(RuntimeError):
    def __init__(self, status: int | None, message: str, url: str = ""):
        self.status = status
        self.url = url
        super().__init__(message)


@dataclass(frozen=True)
class Workspace:
    id: str
    name: str
    type: str = ""


class PostmanClient:
    def __init__(self, api_key: str):
        if not api_key:
            raise ValueError("POSTMAN_API_KEY is not set.")
        self.api_key = api_key

    def _get(self, path: str, query: dict[str, Any] | None = None) -> Any:
        url = f"{config.POSTMAN_BASE_URL}{path}"
        if query:
            clean = {
                key: value
                for key, value in query.items()
                if value is not None and value != ""
            }
            if clean:
                url += "?" + urllib.parse.urlencode(clean)

        request = urllib.request.Request(
            url,
            headers={
                "x-api-key": self.api_key,
                "Accept": "application/json",
                "User-Agent": "postman-api-catalog/1.0",
            },
            method="GET",
        )

        try:
            with urllib.request.urlopen(
                request, timeout=config.REQUEST_TIMEOUT_SECONDS
            ) as response:
                raw = response.read().decode("utf-8")
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8", errors="replace")
            try:
                parsed = json.loads(body)
                error_value = parsed.get("error")
                if isinstance(error_value, dict):
                    detail = error_value.get("message")
                else:
                    detail = error_value
                detail = detail or parsed.get("message") or body
            except json.JSONDecodeError:
                detail = body or exc.reason
            raise PostmanAPIError(
                exc.code,
                f"Postman returned HTTP {exc.code}: {detail}",
                url,
            ) from exc
        except urllib.error.URLError as exc:
            raise PostmanAPIError(
                None, f"Unable to reach Postman: {exc.reason}", url
            ) from exc

    def get_workspaces(self) -> list[Workspace]:
        payload = self._get("/workspaces")
        raw_workspaces = payload.get("workspaces", [])
        workspaces: list[Workspace] = []

        for item in raw_workspaces:
            workspace_id = str(item.get("id", "")).strip()
            if not workspace_id:
                continue
            if config.WORKSPACE_ALLOWLIST and workspace_id not in config.WORKSPACE_ALLOWLIST:
                continue
            workspaces.append(
                Workspace(
                    id=workspace_id,
                    name=item.get("name") or "Unnamed workspace",
                    type=item.get("type") or "",
                )
            )

        return workspaces

    def get_specs_for_workspace(self, workspace_id: str) -> list[dict[str, Any]]:
        specs: list[dict[str, Any]] = []
        cursor: str | None = None
        seen_cursors: set[str] = set()

        while True:
            payload = self._get(
                "/specs",
                {
                    "workspaceId": workspace_id,
                    "limit": config.SPEC_PAGE_LIMIT,
                    "cursor": cursor,
                },
            )

            page = payload.get("specs")
            if page is None:
                page = payload.get("data", [])
            if not isinstance(page, list):
                page = []
            specs.extend(item for item in page if isinstance(item, dict))

            meta = payload.get("meta") or {}
            next_cursor = meta.get("nextCursor")
            if not next_cursor:
                break
            if next_cursor in seen_cursors:
                raise PostmanAPIError(
                    None,
                    f"Postman returned a repeated cursor for workspace {workspace_id}.",
                )
            seen_cursors.add(next_cursor)
            cursor = next_cursor

        return specs

    def get_spec_definition(self, spec_id: str) -> Any:
        encoded = urllib.parse.quote(spec_id, safe="")
        return self._get(f"/specs/{encoded}/definitions")
