# Postman API Catalog

A zero-`npm`, zero-`pip` internal API catalog built with Python's standard library and vanilla HTML/CSS/JavaScript.

## Postman request flow

1. `GET /workspaces`
2. For every accessible workspace:
   - `GET /specs?workspaceId={workspaceId}&limit=100`
   - Follow `meta.nextCursor` using the `cursor` query parameter
3. For every specification:
   - `GET /specs/{specId}/definitions`
4. Normalize the definitions into one `/api/catalog` payload.

The server never sends an `offset` query parameter to `/specs`.

## Requirements

- Python 3.10 or newer
- A Postman API key
- No Node.js, npm, Flask, FastAPI, or third-party Python libraries

## Windows PowerShell

```powershell
Expand-Archive .\postman-api-catalog.zip
cd .\postman-api-catalog
$env:POSTMAN_API_KEY = "PMAK-your-key"
.\start.ps1
```

Open `http://127.0.0.1:8080`.

## macOS or Linux

```bash
export POSTMAN_API_KEY="PMAK-your-key"
chmod +x start.sh
./start.sh
```

## Optional settings

```powershell
$env:POSTMAN_WORKSPACE_ALLOWLIST = "workspace-id-1,workspace-id-2"
$env:CATALOG_CACHE_TTL_SECONDS = "900"
$env:CATALOG_PORT = "8080"
```

When `POSTMAN_WORKSPACE_ALLOWLIST` is unset, all workspaces returned by the API key are queried.

## Local endpoints

- `GET /api/health`
- `GET /api/workspaces`
- `GET /api/catalog`
- `GET /api/catalog?refresh=true`

## OpenAPI metadata

```yaml
info:
  title: Customer API
  version: 1.0.0
  x-owner-team: Customer Platform
  x-lifecycle: production
  x-support-channel: "#customer-api-support"
  x-repository-url: "https://github.example.com/customer-api"
```

## YAML limitation

The application deliberately has no dependencies. JSON-formatted definitions are fully parsed. When Postman returns a YAML definition, the API still appears using Spec Hub metadata, but endpoint extraction is unavailable without a YAML parser.

## Troubleshooting

### `workspaceId is missing`

An older build called `/specs` globally. This package discovers workspaces first and always passes `workspaceId`.

### `/offset is invalid`

An older build used offset pagination. This package uses `cursor` and `meta.nextCursor`.

### Some workspaces show warnings

The API key may see a workspace while lacking permission to read one or more specs. Other workspaces continue loading, and the dashboard reports the warning count.
