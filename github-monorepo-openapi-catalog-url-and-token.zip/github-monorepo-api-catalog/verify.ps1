[CmdletBinding()]
param(
    [switch]$SkipGitHubCheck,
    [switch]$SkipFrontendBuild
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

function Invoke-Native {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Command,

        [Parameter(ValueFromRemainingArguments = $true)]
        [string[]]$Arguments
    )

    & $Command @Arguments
    if ($LASTEXITCODE -ne 0) {
        throw "Command failed with exit code ${LASTEXITCODE}: $Command $($Arguments -join ' ')"
    }
}

$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $VenvPython)) {
    throw "The Python virtual environment is missing. Run setup.bat first."
}
if (-not (Test-Path "frontend\node_modules")) {
    throw "Frontend dependencies are missing. Run setup.bat first."
}

Write-Host "GitHub Monorepo API Catalog - verification" -ForegroundColor Green

Write-Host "`n==> Checking backend syntax and imports" -ForegroundColor Cyan
Invoke-Native $VenvPython "-m" "compileall" "-q" "backend"
Invoke-Native $VenvPython "-c" "from dotenv import load_dotenv; load_dotenv(); import sys; sys.path.insert(0, 'backend'); import config, catalog, github_client, app; print('Backend imports verified')"

if (-not $SkipGitHubCheck) {
    Write-Host "`n==> Checking GitHub authentication and repository access" -ForegroundColor Cyan
    Invoke-Native $VenvPython "-c" 'from dotenv import load_dotenv; load_dotenv(); import sys; sys.path.insert(0, "backend"); import config; from github_client import GitHubMonorepoClient; c=GitHubMonorepoClient(config.GITHUB_REPOSITORY_URL, config.GITHUB_ACCESS_TOKEN); h=c.health(); print("GitHub access verified: {} @ {} (authenticated={})".format(h["repository"], h["ref"], h["authenticated"]))'
} else {
    Write-Host "GitHub access check skipped" -ForegroundColor Yellow
}

Write-Host "`n==> Checking required frontend feature markers" -ForegroundColor Cyan
$AppSource = Get-Content "frontend\src\App.tsx" -Raw
$ExplorerSource = Get-Content "frontend\src\components\ApiExplorer.tsx" -Raw
$SidebarSource = Get-Content "frontend\src\components\Sidebar.tsx" -Raw
$ViteSource = Get-Content "frontend\vite.config.ts" -Raw
$GitHubSource = Get-Content "backend\github_client.py" -Raw
$ConfigSource = Get-Content "backend\config.py" -Raw

$RequiredChecks = @(
    @{ Name = "Endpoint-aware catalog search"; Value = $AppSource -match "matchingOperations" },
    @{ Name = "Inline operation dropdown"; Value = $AppSource -match "View operations" },
    @{ Name = "Compact detailed header"; Value = $AppSource -match "detail-page-header__nav-row" },
    @{ Name = "Major-version API names"; Value = $AppSource -match "V\$\{majorVersion\}" },
    @{ Name = "Collapsed detailed operation groups"; Value = $ExplorerSource -match "open=\{query \? true : undefined\}" },
    @{ Name = "GitHub source links"; Value = $ExplorerSource -match "github-source-link" },
    @{ Name = "Compact Refresh and Theme buttons"; Value = $SidebarSource -match "sidebar-action-button" },
    @{ Name = "Local-only Vite binding"; Value = $ViteSource -match "host: '127.0.0.1'" },
    @{ Name = "Shared backend proxy configuration"; Value = $ViteSource -match "CATALOG_PORT" },
    @{ Name = "Repository URL configuration"; Value = $ConfigSource -match "GITHUB_REPOSITORY_URL" },
    @{ Name = "Bearer token authentication"; Value = $GitHubSource -match 'Authorization.*Bearer' }
)

foreach ($check in $RequiredChecks) {
    if (-not $check.Value) {
        throw "Feature verification failed: $($check.Name)"
    }
    Write-Host "PASS: $($check.Name)"
}

if (-not $SkipFrontendBuild) {
    Write-Host "`n==> Running TypeScript and Vite production build" -ForegroundColor Cyan
    Invoke-Native "npm" "--prefix" "frontend" "run" "build"
} else {
    Write-Host "Frontend build skipped" -ForegroundColor Yellow
}

Write-Host "`nAll verification checks passed." -ForegroundColor Green
