#!/usr/bin/env bash
set -euo pipefail
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate
pip install -r backend/requirements.txt
[ -d frontend/node_modules ] || (cd frontend && npm install)
python backend/run.py &
BACKEND_PID=$!
trap 'kill $BACKEND_PID 2>/dev/null || true' EXIT
cd frontend
npm run dev
