[CmdletBinding()]
param(
    [switch]$SkipInstall,
    [switch]$Start,
    [string]$PostmanApiKey
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

function Write-Step([string]$Message) {
    Write-Host "`n==> $Message" -ForegroundColor Cyan
}

function Require-Command([string]$Name, [string]$InstallHint) {
    if (-not (Get-Command $Name -ErrorAction SilentlyContinue)) {
        throw "$Name was not found. $InstallHint"
    }
}

function Get-VersionMajor([string]$VersionText) {
    $match = [regex]::Match($VersionText, '(\d+)')
    if (-not $match.Success) { return 0 }
    return [int]$match.Groups[1].Value
}

Write-Host "Postman API Catalog - first-time setup" -ForegroundColor Green

Write-Step "Checking prerequisites"
Require-Command "node" "Install Node.js 22 or newer, then rerun this script."
Require-Command "npm" "Install NPM with Node.js, then rerun this script."

$PythonCommand = $null
foreach ($candidate in @("python", "py", "python3")) {
    if (Get-Command $candidate -ErrorAction SilentlyContinue) {
        $PythonCommand = $candidate
        break
    }
}
if (-not $PythonCommand) {
    throw "Python was not found. Install Python 3.11 or newer, then rerun this script."
}

$nodeVersion = (& node --version).Trim()
if ((Get-VersionMajor $nodeVersion) -lt 22) {
    throw "Node.js $nodeVersion is installed, but Node.js 22 or newer is required."
}

$pythonVersion = if ($PythonCommand -eq "py") {
    (& py -3 --version 2>&1).ToString().Trim()
} else {
    (& $PythonCommand --version 2>&1).ToString().Trim()
}
$pythonMatch = [regex]::Match($pythonVersion, '(\d+)\.(\d+)')
if (-not $pythonMatch.Success -or [int]$pythonMatch.Groups[1].Value -lt 3 -or
    ([int]$pythonMatch.Groups[1].Value -eq 3 -and [int]$pythonMatch.Groups[2].Value -lt 11)) {
    throw "$pythonVersion is installed, but Python 3.11 or newer is required."
}

Write-Host "Node:   $nodeVersion"
Write-Host "Python: $pythonVersion"

Write-Step "Preparing local environment configuration"
if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
    Write-Host "Created .env from .env.example"
} else {
    Write-Host ".env already exists; leaving it unchanged"
}

if (-not $PostmanApiKey) {
    $currentEnv = Get-Content ".env" -Raw
    if ($currentEnv -match '(?m)^POSTMAN_API_KEY=(.+)$') {
        $currentKey = $Matches[1].Trim()
    } else {
        $currentKey = ""
    }

    if (-not $currentKey -or $currentKey -eq "replace-with-your-postman-api-key") {
        $secureKey = Read-Host "Enter your Postman API key (input is hidden)" -AsSecureString
        $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureKey)
        try {
            $PostmanApiKey = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
        } finally {
            [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr)
        }
    }
}

if ($PostmanApiKey) {
    $envText = Get-Content ".env" -Raw
    if ($envText -match '(?m)^POSTMAN_API_KEY=.*$') {
        $envText = [regex]::Replace($envText, '(?m)^POSTMAN_API_KEY=.*$', "POSTMAN_API_KEY=$PostmanApiKey")
    } else {
        $envText += "`nPOSTMAN_API_KEY=$PostmanApiKey`n"
    }
    Set-Content ".env" $envText -NoNewline
    Write-Host "Saved the Postman API key to the local .env file"
}

if (-not $SkipInstall) {
    Write-Step "Creating the Python virtual environment"
    if (-not (Test-Path ".venv")) {
        if ($PythonCommand -eq "py") { & py -3 -m venv .venv }
        else { & $PythonCommand -m venv .venv }
    } else {
        Write-Host ".venv already exists"
    }

    $VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
    if (-not (Test-Path $VenvPython)) {
        throw "The Python virtual environment was not created correctly."
    }

    Write-Step "Installing backend dependencies"
    & $VenvPython -m pip install --upgrade pip
    & $VenvPython -m pip install -r backend\requirements.txt

    Write-Step "Installing root and frontend NPM dependencies"
    & npm install
    & npm --prefix frontend install
} else {
    Write-Host "Dependency installation skipped"
}

Write-Step "Setup complete"
Write-Host "Development site: http://localhost:5173"
Write-Host "Backend API:      http://127.0.0.1:8080"
Write-Host "Run .\start-dev.ps1 to start both services."

if ($Start) {
    Write-Step "Starting development servers"
    & "$ProjectRoot\start-dev.ps1"
}
