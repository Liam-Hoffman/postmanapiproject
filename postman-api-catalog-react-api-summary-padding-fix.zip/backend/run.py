from dotenv import load_dotenv
load_dotenv()

from app import app

if __name__ == "__main__":
    import config
    app.run(host=config.HOST, port=config.PORT, debug=True)
