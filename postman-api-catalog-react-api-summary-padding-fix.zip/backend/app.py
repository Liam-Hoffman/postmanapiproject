from __future__ import annotations

import os
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory

import config
from catalog import CatalogService
from postman_client import PostmanAPIError, PostmanClient

BASE_DIR = Path(__file__).resolve().parent
FRONTEND_DIST = BASE_DIR.parent / "frontend" / "dist"


def create_app() -> Flask:
    app = Flask(__name__, static_folder=None)
    service = CatalogService(PostmanClient(config.POSTMAN_API_KEY)) if config.POSTMAN_API_KEY else None

    def require_service() -> CatalogService:
        if service is None:
            raise ValueError("POSTMAN_API_KEY is not set. Copy .env.example to .env and provide a key.")
        return service

    @app.get("/api/health")
    def health():
        return jsonify({"status": "ok", "environment": os.getenv("APP_ENV", "development")})

    @app.get("/api/catalog")
    def catalog():
        force = request.args.get("refresh", "false").lower() in {"1", "true", "yes"}
        try:
            return jsonify(require_service().get_catalog(force=force))
        except (PostmanAPIError, ValueError) as exc:
            return jsonify({"error": "Unable to load catalog", "details": str(exc), "upstreamUrl": getattr(exc, "url", "")}), 502
        except Exception as exc:
            return jsonify({"error": "Unexpected catalog error", "details": str(exc)}), 500

    @app.get("/api/specs/<path:spec_id>")
    def spec_detail(spec_id: str):
        force = request.args.get("refresh", "false").lower() in {"1", "true", "yes"}
        try:
            return jsonify(require_service().get_spec_detail(spec_id, force=force))
        except KeyError as exc:
            return jsonify({"error": str(exc)}), 404
        except PostmanAPIError as exc:
            return jsonify({"error": "Unable to load specification definition", "details": str(exc), "upstreamUrl": getattr(exc, "url", "")}), 502
        except Exception as exc:
            return jsonify({"error": "Unexpected specification error", "details": str(exc)}), 500

    @app.get("/api/workspaces")
    def workspaces():
        try:
            values = require_service().client.get_workspaces()
            return jsonify({"workspaces": [{"id": ws.id, "name": ws.name, "type": ws.type} for ws in values]})
        except (PostmanAPIError, ValueError) as exc:
            return jsonify({"error": str(exc), "upstreamUrl": getattr(exc, "url", "")}), 502

    @app.get("/")
    @app.get("/<path:path>")
    def frontend(path: str = ""):
        if not FRONTEND_DIST.exists():
            return jsonify({
                "error": "Frontend build not found",
                "details": "Run npm install and npm run build in frontend, or use npm run dev for local development."
            }), 404
        candidate = FRONTEND_DIST / path
        if path and candidate.is_file():
            return send_from_directory(FRONTEND_DIST, path)
        return send_from_directory(FRONTEND_DIST, "index.html")

    return app


app = create_app()

if __name__ == "__main__":
    app.run(host=config.HOST, port=config.PORT, debug=os.getenv("APP_ENV", "development") == "development")
