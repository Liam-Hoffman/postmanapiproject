from __future__ import annotations

import email.utils
import json
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from collections import deque
from dataclasses import dataclass
from typing import Any

import config


class PostmanAPIError(RuntimeError):
    def __init__(self, status: int | None, message: str, url: str = ""):
        self.status = status
        self.url = url
        super().__init__(message)


@dataclass(frozen=True)
class Workspace:
    id: str
    name: str
    type: str = ""


class PostmanClient:
    def __init__(self, api_key: str):
        if not api_key:
            raise ValueError("POSTMAN_API_KEY is not set.")
        self.api_key = api_key
        self._rate_lock = threading.Lock()
        self._request_times: deque[float] = deque()
        self._blocked_until = 0.0
        self._users_cache: list[dict[str, Any]] | None = None
        self._users_cached_at = 0.0

    def _wait_for_budget(self) -> None:
        while True:
            with self._rate_lock:
                now = time.monotonic()
                if now < self._blocked_until:
                    wait = self._blocked_until - now
                else:
                    cutoff = now - 60.0
                    while self._request_times and self._request_times[0] <= cutoff:
                        self._request_times.popleft()
                    if len(self._request_times) < config.POSTMAN_REQUESTS_PER_MINUTE:
                        self._request_times.append(now)
                        return
                    wait = max(0.05, 60.0 - (now - self._request_times[0]))
            print(f"[RateLimit] Waiting {wait:.1f}s for request budget", flush=True)
            time.sleep(wait)

    @staticmethod
    def _header_int(headers: Any, *names: str) -> int | None:
        for name in names:
            value = headers.get(name)
            if value is None:
                continue
            try:
                return int(float(str(value).strip()))
            except ValueError:
                continue
        return None

    @staticmethod
    def _rate_limit_header(headers: Any) -> tuple[int | None, int | None, int | None]:
        value = headers.get("RateLimit")
        if not value:
            return None, None, None
        parsed: dict[str, int] = {}
        for part in value.split(","):
            if "=" not in part:
                continue
            key, raw = part.strip().split("=", 1)
            try:
                parsed[key.lower()] = int(float(raw))
            except ValueError:
                pass
        return parsed.get("limit"), parsed.get("remaining"), parsed.get("reset")

    @staticmethod
    def _retry_after_seconds(headers: Any, attempt: int) -> float:
        for name in ("X-RateLimit-RetryAfter", "RetryAfter", "Retry-After"):
            value = headers.get(name)
            if not value:
                continue
            try:
                return max(0.0, float(value))
            except ValueError:
                try:
                    target = email.utils.parsedate_to_datetime(value)
                    return max(0.0, target.timestamp() - time.time())
                except (TypeError, ValueError):
                    pass

        reset = PostmanClient._header_int(
            headers, "RateLimit-Reset", "X-RateLimit-Reset"
        )
        if reset is not None:
            # Postman documents reset headers on different endpoints as either
            # seconds-to-reset or an epoch timestamp.
            if reset > 10_000_000:
                return max(0.0, reset - time.time())
            return max(0.0, float(reset))

        return min(60.0, float(2 ** attempt))

    def _observe_headers(self, headers: Any) -> None:
        limit, remaining, reset = self._rate_limit_header(headers)
        limit = limit or self._header_int(
            headers, "X-RateLimit-Limit", "RateLimit-Limit"
        )
        remaining = remaining if remaining is not None else self._header_int(
            headers, "X-RateLimit-Remaining", "RateLimit-Remaining"
        )
        reset = reset if reset is not None else self._header_int(
            headers, "X-RateLimit-Reset", "RateLimit-Reset"
        )

        if limit is not None or remaining is not None:
            print(
                f"[RateLimit] limit={limit if limit is not None else '?'} "
                f"remaining={remaining if remaining is not None else '?'} "
                f"reset={reset if reset is not None else '?'}",
                flush=True,
            )

        if remaining is not None and remaining <= 1 and reset is not None:
            wait = (
                max(0.0, reset - time.time())
                if reset > 10_000_000
                else max(0.0, float(reset))
            )
            with self._rate_lock:
                self._blocked_until = max(
                    self._blocked_until,
                    time.monotonic() + wait + config.POSTMAN_RATE_LIMIT_BUFFER_SECONDS,
                )

    def _get(self, path: str, query: dict[str, Any] | None = None) -> Any:
        url = f"{config.POSTMAN_BASE_URL}{path}"
        if query:
            clean = {
                key: value for key, value in query.items()
                if value is not None and value != ""
            }
            if clean:
                url += "?" + urllib.parse.urlencode(clean)

        request = urllib.request.Request(
            url,
            headers={
                "x-api-key": self.api_key,
                "Accept": "application/json, application/yaml, text/yaml, text/plain",
                "User-Agent": "postman-api-catalog/1.1",
            },
            method="GET",
        )

        for attempt in range(config.POSTMAN_RATE_LIMIT_RETRIES + 1):
            self._wait_for_budget()
            print(f"[Postman] GET {url}", flush=True)
            try:
                with urllib.request.urlopen(
                    request, timeout=config.REQUEST_TIMEOUT_SECONDS
                ) as response:
                    self._observe_headers(response.headers)
                    status = getattr(response, "status", 200)
                    content_type = response.headers.get("Content-Type", "")
                    print(f"[Postman] {status} {content_type or 'unknown'} {url}", flush=True)
                    raw = response.read().decode("utf-8", errors="replace")

                    if not raw.strip():
                        raise PostmanAPIError(
                            status,
                            "Postman returned an empty successful response "
                            f"(content-type: {content_type or 'unknown'})",
                            url,
                        )
                    try:
                        return json.loads(raw)
                    except json.JSONDecodeError:
                        if path.endswith("/definitions"):
                            return raw
                        preview = raw[:500].replace("\r", " ").replace("\n", " ")
                        raise PostmanAPIError(
                            status,
                            "Postman returned a non-JSON response "
                            f"(content-type: {content_type or 'unknown'}): {preview}",
                            url,
                        )

            except urllib.error.HTTPError as exc:
                body = exc.read().decode("utf-8", errors="replace")
                self._observe_headers(exc.headers)

                if exc.code == 429 and attempt < config.POSTMAN_RATE_LIMIT_RETRIES:
                    wait = self._retry_after_seconds(exc.headers, attempt)
                    wait += config.POSTMAN_RATE_LIMIT_BUFFER_SECONDS
                    with self._rate_lock:
                        self._blocked_until = max(
                            self._blocked_until, time.monotonic() + wait
                        )
                    print(
                        f"[RateLimit] HTTP 429. Retrying in {wait:.1f}s "
                        f"({attempt + 1}/{config.POSTMAN_RATE_LIMIT_RETRIES})",
                        flush=True,
                    )
                    continue

                try:
                    parsed = json.loads(body)
                    error_value = parsed.get("error")
                    detail = (
                        error_value.get("message")
                        if isinstance(error_value, dict)
                        else error_value
                    )
                    detail = detail or parsed.get("message") or body
                except json.JSONDecodeError:
                    detail = body or exc.reason
                raise PostmanAPIError(
                    exc.code,
                    f"Postman returned HTTP {exc.code}: {detail}",
                    url,
                ) from exc

            except urllib.error.URLError as exc:
                raise PostmanAPIError(
                    None, f"Unable to reach Postman: {exc.reason}", url
                ) from exc

        raise PostmanAPIError(429, "Postman rate limit retries exhausted", url)

    def get_team_users(self, force: bool = False) -> list[dict[str, Any]]:
        now = time.time()
        if (
            not force
            and self._users_cache is not None
            and now - self._users_cached_at < config.USER_CACHE_TTL_SECONDS
        ):
            print(
                f"[Users] Cache hit: {len(self._users_cache)} team users",
                flush=True,
            )
            return list(self._users_cache)

        payload = self._get("/users")
        raw_users = payload.get("data", []) if isinstance(payload, dict) else []
        users = [item for item in raw_users if isinstance(item, dict)]
        self._users_cache = users
        self._users_cached_at = time.time()
        print(f"[Users] Cached {len(users)} team users", flush=True)
        return list(users)

    def get_workspaces(self) -> list[Workspace]:
        payload = self._get("/workspaces")
        raw_workspaces = payload.get("workspaces", [])
        workspaces: list[Workspace] = []

        for item in raw_workspaces:
            workspace_id = str(item.get("id", "")).strip()
            workspace_name = str(item.get("name") or "Unnamed workspace").strip()
            if not workspace_id:
                continue
            if workspace_name.casefold() == "my workspace":
                print(
                    f"[Catalog] Excluding workspace: {workspace_name} ({workspace_id})",
                    flush=True,
                )
                continue
            if config.WORKSPACE_ALLOWLIST and workspace_id not in config.WORKSPACE_ALLOWLIST:
                continue
            workspaces.append(
                Workspace(
                    id=workspace_id,
                    name=workspace_name,
                    type=item.get("type") or "",
                )
            )

        return workspaces

    def get_specs_for_workspace(self, workspace_id: str) -> list[dict[str, Any]]:
        specs: list[dict[str, Any]] = []
        cursor: str | None = None
        seen_cursors: set[str] = set()

        while True:
            payload = self._get(
                "/specs",
                {
                    "workspaceId": workspace_id,
                    "limit": config.SPEC_PAGE_LIMIT,
                    "cursor": cursor,
                },
            )
            page = payload.get("specs")
            if page is None:
                page = payload.get("data", [])
            if not isinstance(page, list):
                page = []
            specs.extend(item for item in page if isinstance(item, dict))

            meta = payload.get("meta") or {}
            next_cursor = meta.get("nextCursor")
            if not next_cursor:
                break
            if next_cursor in seen_cursors:
                raise PostmanAPIError(
                    None,
                    f"Postman returned a repeated cursor for workspace {workspace_id}.",
                )
            seen_cursors.add(next_cursor)
            cursor = next_cursor

        return specs

    def get_spec_definition(self, spec_id: str) -> Any:
        encoded = urllib.parse.quote(spec_id, safe="")
        return self._get(f"/specs/{encoded}/definitions")
