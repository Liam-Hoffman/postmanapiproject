interface Props {
  summary: string; search: string; workspace: string; sort: string;
  workspaces: { id: string; name: string }[];
  apiCount: number; workspaceCount: number; loading: boolean;
  onSearch(value: string): void; onWorkspace(value: string): void;
  onSort(value: string): void; onRefresh(): void; onTheme(): void;
}

export function Sidebar(props: Props) {
  return <aside className="catalog-sidebar">
    <header className="brand-block">
      <div className="eyebrow">Internal Developer Portal</div>
      <h1>API Catalog</h1>
      <p>{props.summary}</p>
      <div className="actions">
        <button onClick={props.onRefresh} disabled={props.loading}>{props.loading ? 'Loading…' : 'Refresh Postman'}</button>
        <button className="secondary" onClick={props.onTheme}>Theme</button>
      </div>
    </header>
    <section className="sidebar-panel">
      <label><span>Search APIs</span><input value={props.search} onChange={e => props.onSearch(e.target.value)} type="search" placeholder="API, endpoint, owner, tag…" /></label>
      <label><span>CSAA workspace</span><select value={props.workspace} onChange={e => props.onWorkspace(e.target.value)}>
        <option value="">All matching workspaces ({props.workspaces.length})</option>
        {props.workspaces.map(w => <option key={w.id} value={w.id}>{w.name}</option>)}
      </select></label>
      <label><span>Sort APIs</span><select value={props.sort} onChange={e => props.onSort(e.target.value)}>
        <option value="name">Name</option><option value="updated">Recently updated</option><option value="operations">Most operations</option>
      </select></label>
      <div className="sidebar-help">
        <strong>Catalog scope</strong>
        <span>Only Postman workspaces beginning with <code>[CSAA]</code> are included.</span>
      </div>
      <div className="stats"><div><strong>{props.apiCount}</strong><span>Matching APIs</span></div><div><strong>{props.workspaceCount}</strong><span>Workspaces</span></div></div>
    </section>
  </aside>
}
