import type { ButtonHTMLAttributes, HTMLAttributes, InputHTMLAttributes, ReactNode } from "react";

type SurfaceProps = HTMLAttributes<HTMLElement> & {
  as?: "div" | "section" | "aside" | "header";
  elevated?: boolean;
  children: ReactNode;
};

export function Surface({ as: Tag = "div", elevated = false, className = "", ...props }: SurfaceProps) {
  return <Tag className={`ui-surface${elevated ? " ui-surface--elevated" : ""} ${className}`.trim()} {...props} />;
}

type ButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: "primary" | "secondary" | "ghost";
};

export function Button({ variant = "secondary", className = "", ...props }: ButtonProps) {
  return <button className={`ui-button ui-button--${variant} ${className}`.trim()} {...props} />;
}

export function Input({ className = "", ...props }: InputHTMLAttributes<HTMLInputElement>) {
  return <input className={`ui-input ${className}`.trim()} {...props} />;
}

export function Badge({
  tone = "default",
  className = "",
  ...props
}: HTMLAttributes<HTMLSpanElement> & { tone?: "default" | "danger" }) {
  return <span className={`ui-badge${tone === "danger" ? " ui-badge--danger" : ""} ${className}`.trim()} {...props} />;
}
