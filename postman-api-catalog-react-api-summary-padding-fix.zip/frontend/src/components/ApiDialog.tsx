import { useEffect, useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import type { ApiItem, Operation, RequestField } from '../types'
import { formatDate, htmlToText } from '../lib/text'

const METHOD_ORDER = ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'HEAD', 'OPTIONS', 'TRACE']

interface FieldNode {
  field: RequestField
  children: FieldNode[]
}

function operationText(op: Operation) {
  return [
    op.method,
    op.path,
    op.summary,
    op.description,
    op.operationId,
    ...(op.tags || []),
    ...(op.requestFields || []).flatMap(field => [
      field.path,
      field.name,
      field.location,
      field.type,
      field.description,
    ]),
  ].filter(Boolean).join(' ').toLowerCase()
}

function parentPath(path: string) {
  const index = path.lastIndexOf('.')
  return index === -1 ? '' : path.slice(0, index)
}

function buildFieldTree(fields: RequestField[]): FieldNode[] {
  const nodes = new Map<string, FieldNode>()
  const roots: FieldNode[] = []

  fields.forEach((field, index) => {
    const path = field.path || field.name || `field-${index}`
    nodes.set(path, { field: { ...field, path }, children: [] })
  })

  nodes.forEach((node, path) => {
    const parent = nodes.get(parentPath(path))
    if (parent) parent.children.push(node)
    else roots.push(node)
  })

  return roots
}

function RequiredIndicator({ required }: { required?: boolean }) {
  return required
    ? <span className="required-badge"><span aria-hidden="true">*</span> Required</span>
    : <span className="optional-badge">Optional</span>
}

function FieldTable({ fields, operationKey, expandAll }: { fields: RequestField[]; operationKey: string; expandAll: boolean }) {
  const tree = useMemo(() => buildFieldTree(fields), [fields])
  const [expanded, setExpanded] = useState<Set<string>>(new Set())

  function toggle(path: string) {
    setExpanded(current => {
      const next = new Set(current)
      if (next.has(path)) next.delete(path)
      else next.add(path)
      return next
    })
  }

  function renderNodes(nodes: FieldNode[], depth = 0): ReactNode[] {
    return nodes.flatMap(node => {
      const path = node.field.path || node.field.name
      const key = `${operationKey}-${path}`
      const hasChildren = node.children.length > 0
      const isExpanded = expandAll || expanded.has(path)
      const rows: ReactNode[] = [
        <tr key={key} className={`${node.field.required ? 'required-field-row' : ''} ${hasChildren ? 'object-field-row' : ''}`}>
          <td>
            <div className="field-name-cell" style={{ paddingLeft: `${depth * 22}px` }}>
              {hasChildren
                ? <button
                    type="button"
                    className="field-expander"
                    aria-expanded={isExpanded}
                    aria-label={`${isExpanded ? 'Collapse' : 'Expand'} ${path}`}
                    onClick={() => toggle(path)}
                  >
                    <span className="field-chevron" aria-hidden="true">›</span>
                  </button>
                : <span className="field-expander-spacer" />}
              <div>
                <div className="field-code-line">
                  <code>{node.field.name || path.split('.').at(-1)}</code>
                  {node.field.required && <span className="required-asterisk" aria-label="Required field">*</span>}
                  {hasChildren && <span className="object-pill">{node.children.length} fields</span>}
                </div>
                {node.field.description && <small>{htmlToText(node.field.description)}</small>}
              </div>
            </div>
          </td>
          <td>{node.field.location || 'body'}</td>
          <td><code>{node.field.type || 'unknown'}</code></td>
          <td><RequiredIndicator required={node.field.required} /></td>
        </tr>,
      ]

      if (hasChildren && isExpanded) rows.push(...renderNodes(node.children, depth + 1))
      return rows
    })
  }

  return <div className="table-wrap">
    <table className="request-fields-table">
      <thead><tr><th>Field</th><th>In</th><th>Type</th><th>Importance</th></tr></thead>
      <tbody>{renderNodes(tree)}</tbody>
    </table>
  </div>
}

function OperationCard({ op, index, searchActive }: { op: Operation; index: number; searchActive: boolean }) {
  const operationKey = `${op.method}-${op.path}-${index}`
  return <article className="operation">
    <div className="operation-title"><span className={`method method-${op.method.toLowerCase()}`}>{op.method}</span><code>{op.path}</code></div>
    <h4>{op.summary || op.operationId || 'No summary'}</h4>
    {op.description && <p>{htmlToText(op.description)}</p>}
    {!!op.requestFields?.length && <FieldTable fields={op.requestFields} operationKey={operationKey} expandAll={searchActive} />}
    {op.requestBodyExample
      ? <div className="example"><strong>Example request body</strong><pre><code>{typeof op.requestBodyExample.example === 'string' ? op.requestBodyExample.example : JSON.stringify(op.requestBodyExample.example, null, 2)}</code></pre></div>
      : !['GET', 'HEAD', 'OPTIONS', 'TRACE'].includes(op.method.toUpperCase()) && <p className="muted">No request body is defined for this operation.</p>}
  </article>
}

export function ApiDialog({ api, loading, error, onClose }: { api: ApiItem | null; loading: boolean; error: string; onClose(): void }) {
  const [tab, setTab] = useState<'overview' | 'spec'>('overview')
  const [search, setSearch] = useState('')
  useEffect(() => { setTab('overview'); setSearch('') }, [api?.id])
  const query = search.trim().toLowerCase()
  const operations = useMemo(() => (api?.operations || []).filter(op => !query || operationText(op).includes(query)), [api, query])
  const groupedOperations = useMemo(() => {
    const groups = new Map<string, Operation[]>()
    operations.forEach(op => {
      const method = op.method.toUpperCase()
      groups.set(method, [...(groups.get(method) || []), op])
    })
    return [...groups.entries()].sort(([methodA], [methodB]) => {
      const a = METHOD_ORDER.indexOf(methodA)
      const b = METHOD_ORDER.indexOf(methodB)
      return (a === -1 ? METHOD_ORDER.length : a) - (b === -1 ? METHOD_ORDER.length : b) || methodA.localeCompare(methodB)
    })
  }, [operations])

  if (!api) return null

  return <div className="dialog-backdrop" role="presentation" onMouseDown={e => { if (e.target === e.currentTarget) onClose() }}>
    <section className="detail-dialog" role="dialog" aria-modal="true" aria-label={`${api.name} details`}>
      <header className="detail-header">
        <div><div className="eyebrow">{api.workspace.name}</div><h2>{api.name}</h2></div>
        <div className="detail-actions">
          <button className={tab === 'overview' ? 'active' : 'secondary'} onClick={() => setTab('overview')}>Overview</button>
          <button className={tab === 'spec' ? 'active' : 'secondary'} onClick={() => setTab('spec')}>Specification</button>
          <button className="secondary" onClick={() => navigator.clipboard.writeText(api.definitionText || '')}>Copy spec</button>
          <button className="secondary" onClick={onClose}>Close</button>
        </div>
        <input type="search" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search this API…" />
      </header>
      <div className="detail-content">
        {loading && <p className="notice">Loading this API definition from Postman…</p>}
        {error && <p className="notice error">{error}</p>}
        {!loading && !error && tab === 'spec' && <pre className="spec"><code>{api.definitionText || 'Specification unavailable.'}</code></pre>}
        {!loading && !error && tab === 'overview' && <>
          <div className="detail-summary">
            <div><strong>Version</strong><span>{api.version || 'Unspecified'}</span></div>
            <div><strong>Owner</strong><span>{api.owner || 'Unspecified'}</span></div>
            <div><strong>Operations</strong><span>{api.operationCount ?? 0}</span></div>
            <div><strong>Updated</strong><span>{formatDate(api.updatedAt)}</span></div>
          </div>
          {api.description && (!query || htmlToText(api.description).toLowerCase().includes(query)) && <section><h3>Description</h3><p>{htmlToText(api.description)}</p></section>}
          {!!api.servers?.filter(s => !query || s.toLowerCase().includes(query)).length && <section><h3>Servers</h3><div className="server-list">{api.servers.filter(s => !query || s.toLowerCase().includes(query)).map(s => <code key={s}>{s}</code>)}</div></section>}
          <section className="operations-section">
            <div className="section-title-row"><h3>Operations</h3><span>{operations.length} shown</span></div>
            {operations.length === 0
              ? <p>No matching operations were found.</p>
              : <div className="operation-groups">{groupedOperations.map(([method, methodOperations]) => <details className="operation-group" key={method} open>
                  <summary>
                    <span className={`method method-${method.toLowerCase()}`}>{method}</span>
                    <strong>{method} operations</strong>
                    <span className="operation-count">{methodOperations.length}</span>
                    <span className="group-chevron" aria-hidden="true">›</span>
                  </summary>
                  <div className="operation-group-content">
                    {methodOperations.map((op, index) => <OperationCard key={`${op.method}-${op.path}-${index}`} op={op} index={index} searchActive={Boolean(query)} />)}
                  </div>
                </details>)}</div>}
          </section>
        </>}
      </div>
    </section>
  </div>
}
