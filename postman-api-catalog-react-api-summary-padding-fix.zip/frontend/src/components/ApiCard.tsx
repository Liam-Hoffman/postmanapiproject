import type { ApiItem } from '../types'
import { formatDate, htmlToText } from '../lib/text'

export function ApiCard({ api, onOpen }: { api: ApiItem; onOpen(api: ApiItem): void }) {
  const description = htmlToText(api.catalogDescription ?? api.description) || 'Open this API to view its full definition.'
  return <article className="api-card" tabIndex={0} onClick={() => onOpen(api)} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') onOpen(api) }}>
    <div className="workspace-name">{api.workspace.name}</div>
    <h3>{api.name}</h3>
    <p className="description">{description}</p>
    <div className="tags">{(api.tags || []).slice(0, 5).map(tag => <span key={tag}>{tag}</span>)}</div>
    <div className="card-footer">
      <p>{api.version ? `v${api.version}` : 'Version loads on open'} · {api.operationCount == null ? 'Operations load on open' : `${api.operationCount} operations`} · Updated {formatDate(api.updatedAt)}</p>
      <button onClick={e => { e.stopPropagation(); onOpen(api) }}>View API Details</button>
    </div>
  </article>
}
