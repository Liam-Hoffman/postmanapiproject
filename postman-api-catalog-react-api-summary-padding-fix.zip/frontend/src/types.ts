export interface Workspace { id: string; name: string; type?: string }
export interface RequestField { name: string; path?: string; location?: string; type?: string; required?: boolean; description?: string }
export interface RequestBodyExample { contentType?: string; example: unknown }
export interface Operation {
  method: string; path: string; summary?: string; description?: string; operationId?: string;
  tags?: string[]; requestFields?: RequestField[]; requestBodyExample?: RequestBodyExample;
}
export interface ApiItem {
  id: string; name: string; description?: string; catalogDescription?: string; owner?: string;
  lifecycle?: string; workspace: Workspace; tags?: string[]; servers?: string[]; operations?: Operation[];
  version?: string; operationCount?: number | null; updatedAt?: string; detailsLoaded?: boolean;
  definitionText?: string; definitionParsed?: boolean;
}
export interface CatalogPayload {
  apis: ApiItem[]; apiCount: number; workspaceCount: number; loadMilliseconds?: number;
  workspaces?: Workspace[]; errors?: unknown[];
}
