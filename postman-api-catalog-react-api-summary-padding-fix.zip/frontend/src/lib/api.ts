import type { ApiItem, CatalogPayload } from '../types'

async function getJson<T>(url: string): Promise<T> {
  const response = await fetch(url, { headers: { Accept: 'application/json' } })
  const payload = await response.json()
  if (!response.ok) throw new Error(payload.details || payload.error || `HTTP ${response.status}`)
  return payload as T
}

export const catalogApi = {
  getCatalog: (refresh = false) => getJson<CatalogPayload>(`/api/catalog${refresh ? '?refresh=true' : ''}`),
  getSpec: (id: string) => getJson<ApiItem>(`/api/specs/${encodeURIComponent(id)}`),
}
