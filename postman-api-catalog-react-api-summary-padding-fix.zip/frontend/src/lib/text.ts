import type { ApiItem } from '../types'

export function htmlToText(value = ''): string {
  const document = new DOMParser().parseFromString(value, 'text/html')
  return (document.body.textContent || '').replace(/\s+/g, ' ').trim()
}

export function searchable(api: ApiItem): string {
  return [
    api.name, htmlToText(api.description), api.owner, api.lifecycle, api.workspace.name,
    ...(api.tags || []), ...(api.servers || []),
    ...(api.operations || []).flatMap(op => [op.method, op.path, op.summary, op.description, op.operationId, ...(op.tags || [])]),
  ].filter(Boolean).join(' ').toLowerCase()
}

export function formatDate(value?: string): string {
  if (!value) return 'Unknown'
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? value : new Intl.DateTimeFormat(undefined, { dateStyle: 'medium' }).format(date)
}
