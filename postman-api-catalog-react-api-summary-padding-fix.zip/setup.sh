#!/usr/bin/env bash
set -euo pipefail

PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$PROJECT_ROOT"

SKIP_INSTALL=0
START_AFTER=0
POSTMAN_API_KEY_ARG=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --skip-install) SKIP_INSTALL=1 ;;
    --start) START_AFTER=1 ;;
    --api-key)
      shift
      POSTMAN_API_KEY_ARG="${1:-}"
      ;;
    -h|--help)
      cat <<'HELP'
Usage: ./setup.sh [--skip-install] [--start] [--api-key KEY]

Creates .env, creates a Python virtual environment, and installs backend,
root, and frontend dependencies. Existing .env files are preserved.
HELP
      exit 0
      ;;
    *) echo "Unknown option: $1" >&2; exit 2 ;;
  esac
  shift
done

step() { printf '\n\033[36m==> %s\033[0m\n' "$1"; }
fail() { printf '\nError: %s\n' "$1" >&2; exit 1; }

printf '\033[32mPostman API Catalog - first-time setup\033[0m\n'

step "Checking prerequisites"
command -v node >/dev/null || fail "Node.js 22 or newer is required."
command -v npm >/dev/null || fail "NPM is required."

PYTHON=""
for candidate in python3 python; do
  if command -v "$candidate" >/dev/null; then PYTHON="$candidate"; break; fi
done
[[ -n "$PYTHON" ]] || fail "Python 3.11 or newer is required."

NODE_MAJOR="$(node --version | sed -E 's/^v([0-9]+).*/\1/')"
[[ "$NODE_MAJOR" -ge 22 ]] || fail "Node.js $(node --version) is installed; version 22 or newer is required."

"$PYTHON" - <<'PY' || fail "Python 3.11 or newer is required."
import sys
raise SystemExit(0 if sys.version_info >= (3, 11) else 1)
PY

printf 'Node:   %s\n' "$(node --version)"
printf 'Python: %s\n' "$($PYTHON --version 2>&1)"

step "Preparing local environment configuration"
if [[ ! -f .env ]]; then
  cp .env.example .env
  echo "Created .env from .env.example"
else
  echo ".env already exists; leaving existing values unchanged"
fi

CURRENT_KEY="$(sed -n 's/^POSTMAN_API_KEY=//p' .env | head -n 1)"
if [[ -z "$POSTMAN_API_KEY_ARG" && ( -z "$CURRENT_KEY" || "$CURRENT_KEY" == "replace-with-your-postman-api-key" ) ]]; then
  read -r -s -p "Enter your Postman API key (input is hidden): " POSTMAN_API_KEY_ARG
  printf '\n'
fi

if [[ -n "$POSTMAN_API_KEY_ARG" ]]; then
  POSTMAN_API_KEY_VALUE="$POSTMAN_API_KEY_ARG" "$PYTHON" - <<'PY'
from pathlib import Path
import os, re
path = Path('.env')
text = path.read_text()
value = os.environ['POSTMAN_API_KEY_VALUE']
line = f'POSTMAN_API_KEY={value}'
if re.search(r'(?m)^POSTMAN_API_KEY=.*$', text):
    text = re.sub(r'(?m)^POSTMAN_API_KEY=.*$', lambda _: line, text)
else:
    text = text.rstrip() + '\n' + line + '\n'
path.write_text(text)
PY
  echo "Saved the Postman API key to the local .env file"
fi

if [[ "$SKIP_INSTALL" -eq 0 ]]; then
  step "Creating the Python virtual environment"
  if [[ ! -d .venv ]]; then
    "$PYTHON" -m venv .venv
  else
    echo ".venv already exists"
  fi

  VENV_PYTHON=".venv/bin/python"
  [[ -x "$VENV_PYTHON" ]] || fail "The Python virtual environment was not created correctly."

  step "Installing backend dependencies"
  "$VENV_PYTHON" -m pip install --upgrade pip
  "$VENV_PYTHON" -m pip install -r backend/requirements.txt

  step "Installing root and frontend NPM dependencies"
  npm install
  npm --prefix frontend install
else
  echo "Dependency installation skipped"
fi

step "Setup complete"
echo "Development site: http://localhost:5173"
echo "Backend API:      http://127.0.0.1:8080"
echo "Run ./start-dev.sh to start both services."

if [[ "$START_AFTER" -eq 1 ]]; then
  step "Starting development servers"
  exec ./start-dev.sh
fi
