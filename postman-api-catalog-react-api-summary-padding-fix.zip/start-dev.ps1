$ErrorActionPreference = "Stop"
if (-not (Test-Path ".venv")) { python -m venv .venv }
& .\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
if (-not (Test-Path "frontend\node_modules")) { Push-Location frontend; npm install; Pop-Location }
Start-Process powershell -ArgumentList '-NoExit','-Command',"Set-Location '$PWD'; .\.venv\Scripts\python.exe backend\run.py"
Push-Location frontend
npm run dev
Pop-Location
