from __future__ import annotations

import json
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

import config
from postman_client import PostmanAPIError, PostmanClient, Workspace

HTTP_METHODS = {
    "get", "post", "put", "patch", "delete", "head", "options", "trace"
}


def _parse_definition(payload: Any) -> tuple[dict[str, Any] | None, str]:
    value = payload
    if isinstance(payload, dict):
        for key in ("definition", "data", "content"):
            if key in payload:
                value = payload[key]
                break

    if isinstance(value, dict):
        return value, "json"

    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            if isinstance(parsed, dict):
                return parsed, "json"
        except json.JSONDecodeError:
            return None, "yaml-or-text"

    return None, "unknown"


def _normalize_spec(
    spec: dict[str, Any],
    workspace: Workspace,
    definition_payload: Any,
) -> dict[str, Any]:
    definition, definition_format = _parse_definition(definition_payload)
    info = definition.get("info", {}) if definition else {}

    spec_id = str(spec.get("id") or spec.get("uid") or "")
    name = info.get("title") or spec.get("name") or "Unnamed API"
    description = info.get("description") or spec.get("description") or ""
    version = info.get("version") or ""

    operations: list[dict[str, Any]] = []
    tags: set[str] = set()
    servers: list[str] = []
    security_schemes: list[str] = []

    if definition:
        for server in definition.get("servers", []) or []:
            if isinstance(server, dict) and server.get("url"):
                servers.append(str(server["url"]))

        for tag in definition.get("tags", []) or []:
            if isinstance(tag, dict) and tag.get("name"):
                tags.add(str(tag["name"]))

        paths = definition.get("paths", {})
        if isinstance(paths, dict):
            for path, path_item in paths.items():
                if not isinstance(path_item, dict):
                    continue
                for method, operation in path_item.items():
                    if method.lower() not in HTTP_METHODS:
                        continue
                    operation = operation if isinstance(operation, dict) else {}
                    operation_tags = [
                        str(value) for value in operation.get("tags", []) or []
                    ]
                    tags.update(operation_tags)
                    responses = operation.get("responses", {})
                    operations.append(
                        {
                            "method": method.upper(),
                            "path": str(path),
                            "summary": operation.get("summary") or "",
                            "description": operation.get("description") or "",
                            "operationId": operation.get("operationId") or "",
                            "deprecated": bool(operation.get("deprecated", False)),
                            "tags": operation_tags,
                            "responseCodes": list(responses.keys())
                            if isinstance(responses, dict)
                            else [],
                        }
                    )

        components = definition.get("components", {})
        if isinstance(components, dict):
            schemes = components.get("securitySchemes", {})
            if isinstance(schemes, dict):
                security_schemes = list(schemes.keys())

    owner = (
        info.get("x-owner-team")
        or info.get("x-owner")
        or info.get("x-team")
        or ""
    )
    lifecycle = (
        info.get("x-lifecycle")
        or info.get("x-api-lifecycle")
        or "unspecified"
    )
    repository = (
        info.get("x-repository")
        or info.get("x-repository-url")
        or info.get("x-github")
        or ""
    )
    support = info.get("x-support-channel") or info.get("x-support") or ""

    if isinstance(definition_payload, str):
        definition_text = definition_payload
    elif definition is not None:
        definition_text = json.dumps(definition, ensure_ascii=False, indent=2)
    else:
        definition_text = json.dumps(definition_payload, ensure_ascii=False, indent=2)

    return {
        "definitionText": definition_text,
        "name": name,
        "description": description,
        "version": version,
        "type": spec.get("type") or "",
        "fileFormat": spec.get("fileFormat") or definition_format,
        "createdAt": spec.get("createdAt"),
        "updatedAt": spec.get("updatedAt"),
        "workspace": {
            "id": workspace.id,
            "name": workspace.name,
            "type": workspace.type,
        },
        "owner": owner,
        "lifecycle": lifecycle,
        "repository": repository,
        "support": support,
        "tags": sorted(tags, key=str.lower),
        "servers": servers,
        "securitySchemes": security_schemes,
        "operationCount": len(operations),
        "operations": operations,
        "definitionParsed": definition is not None,
        "definitionFormat": definition_format,
    }


def _name_tokens(value: str) -> set[str]:
    return {
        token.casefold()
        for token in re.findall(r"[A-Za-z0-9]+", value)
        if len(token) >= 3
    }


def _user_name_tokens(users: list[dict[str, Any]]) -> set[str]:
    tokens: set[str] = set()
    for user in users:
        full_name = str(user.get("name") or "").strip()
        parts = re.findall(r"[A-Za-z0-9]+", full_name)
        if not parts:
            continue
        # Only first and last names are used, as requested. Exact token matching
        # avoids substring false positives such as Ann matching Analytics.
        for part in {parts[0], parts[-1]}:
            if len(part) >= 3:
                tokens.add(part.casefold())
    return tokens


def _workspace_matches_user(workspace_name: str, user_tokens: set[str]) -> bool:
    return bool(_name_tokens(workspace_name) & user_tokens)


class CatalogService:
    def __init__(self, client: PostmanClient):
        self.client = client
        self._lock = threading.Lock()
        self._cached: dict[str, Any] | None = None
        self._cached_at = 0.0
        self._spec_index: dict[str, tuple[Workspace, dict[str, Any]]] = {}
        self._detail_cache: dict[str, dict[str, Any]] = {}

    def get_catalog(self, force: bool = False) -> dict[str, Any]:
        now = time.time()
        if (
            not force
            and self._cached is not None
            and now - self._cached_at < config.CACHE_TTL_SECONDS
        ):
            result = dict(self._cached)
            result["cache"] = {"hit": True, "ageSeconds": int(now - self._cached_at)}
            return result

        with self._lock:
            now = time.time()
            if (
                not force
                and self._cached is not None
                and now - self._cached_at < config.CACHE_TTL_SECONDS
            ):
                result = dict(self._cached)
                result["cache"] = {"hit": True, "ageSeconds": int(now - self._cached_at)}
                return result

            catalog = self._build_catalog()
            self._cached = catalog
            self._cached_at = time.time()
            result = dict(catalog)
            result["cache"] = {"hit": False, "ageSeconds": 0}
            return result

    def get_spec_detail(self, spec_id: str, force: bool = False) -> dict[str, Any]:
        if not force and spec_id in self._detail_cache:
            result = dict(self._detail_cache[spec_id])
            result["detailCacheHit"] = True
            return result

        # Build the lightweight catalog first if this process has not loaded it yet.
        if spec_id not in self._spec_index:
            self.get_catalog(force=False)

        item = self._spec_index.get(spec_id)
        if item is None:
            raise KeyError(f"Specification not found: {spec_id}")

        workspace, spec = item
        print(
            f"[Catalog] Loading definition on demand: "
            f"{spec.get('name') or spec_id}",
            flush=True,
        )
        definition = self.client.get_spec_definition(spec_id)
        detail = _normalize_spec(spec, workspace, definition)
        self._detail_cache[spec_id] = detail
        result = dict(detail)
        result["detailCacheHit"] = False
        return result

    @staticmethod
    def _metadata_spec(spec: dict[str, Any], workspace: Workspace) -> dict[str, Any]:
        return {
            "id": str(spec.get("id") or spec.get("uid") or ""),
            "name": spec.get("name") or "Unnamed API",
            "description": spec.get("description") or "",
            "version": spec.get("version") or "",
            "type": spec.get("type") or "",
            "fileFormat": spec.get("fileFormat") or "",
            "createdAt": spec.get("createdAt"),
            "updatedAt": spec.get("updatedAt"),
            "workspace": {
                "id": workspace.id,
                "name": workspace.name,
                "type": workspace.type,
            },
            # Definition-derived values are intentionally deferred.
            "owner": "",
            "lifecycle": "details not loaded",
            "repository": "",
            "support": "",
            "tags": [],
            "servers": [],
            "securitySchemes": [],
            "operationCount": None,
            "operations": [],
            "definitionParsed": None,
            "detailsLoaded": False,
        }

    def _build_catalog(self) -> dict[str, Any]:
        started = time.time()
        print("[Catalog] Loading accessible workspaces...", flush=True)
        workspaces = self.client.get_workspaces()
        print(f"[Catalog] Found {len(workspaces)} workspaces before user filtering", flush=True)

        user_filter_warning: dict[str, Any] | None = None
        try:
            users = self.client.get_team_users(force=False)
            user_tokens = _user_name_tokens(users)
            retained: list[Workspace] = []
            for workspace in workspaces:
                matched = _name_tokens(workspace.name) & user_tokens
                if matched:
                    print(
                        f"[Catalog] Excluding personal-name workspace: "
                        f"{workspace.name} (matched: {', '.join(sorted(matched))})",
                        flush=True,
                    )
                    continue
                retained.append(workspace)
            workspaces = retained
            print(
                f"[Catalog] {len(workspaces)} workspaces remain after user filtering",
                flush=True,
            )
        except PostmanAPIError as exc:
            user_filter_warning = {
                "stage": "list-users",
                "error": str(exc),
            }
            print(
                f"[Catalog] WARNING: Could not load team users; "
                f"name filtering disabled: {exc}",
                flush=True,
            )

        apis: list[dict[str, Any]] = []
        errors: list[dict[str, Any]] = (
            [user_filter_warning] if user_filter_warning is not None else []
        )
        next_index: dict[str, tuple[Workspace, dict[str, Any]]] = {}
        nonempty_workspaces: list[Workspace] = []

        def list_workspace_specs(workspace: Workspace) -> tuple[Workspace, list[dict[str, Any]]]:
            specs = self.client.get_specs_for_workspace(workspace.id)
            return workspace, specs

        worker_count = min(max(config.DEFINITION_WORKERS, 1), max(len(workspaces), 1))
        print(
            f"[Catalog] Listing workspace specs with {worker_count} workers...",
            flush=True,
        )

        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            future_map = {
                executor.submit(list_workspace_specs, workspace): workspace
                for workspace in workspaces
            }

            completed = 0
            for future in as_completed(future_map):
                workspace = future_map[future]
                completed += 1
                try:
                    _, specs = future.result()
                    print(
                        f"[Catalog] Workspace {completed}/{len(workspaces)}: "
                        f"{workspace.name} — {len(specs)} specs",
                        flush=True,
                    )
                    if not specs:
                        print(
                            f"[Catalog] Excluding empty workspace: {workspace.name}",
                            flush=True,
                        )
                        continue
                    nonempty_workspaces.append(workspace)
                    for spec in specs:
                        spec_id = str(spec.get("id") or spec.get("uid") or "")
                        if not spec_id:
                            continue
                        next_index[spec_id] = (workspace, spec)
                        apis.append(self._metadata_spec(spec, workspace))
                except PostmanAPIError as exc:
                    print(
                        f"[Catalog] Workspace {workspace.name} ERROR: {exc}",
                        flush=True,
                    )
                    errors.append(
                        {
                            "workspaceId": workspace.id,
                            "workspaceName": workspace.name,
                            "stage": "list-specs",
                            "error": str(exc),
                        }
                    )

        apis.sort(
            key=lambda item: (
                item["name"].lower(),
                item["workspace"]["name"].lower(),
            )
        )
        self._spec_index = next_index

        elapsed_ms = int((time.time() - started) * 1000)
        print(
            f"[Catalog] Initial catalog ready: {len(apis)} APIs in "
            f"{elapsed_ms} ms. Definitions load only when opened.",
            flush=True,
        )

        return {
            "generatedAt": int(time.time()),
            "loadMilliseconds": elapsed_ms,
            "workspaceCount": len(nonempty_workspaces),
            "apiCount": len(apis),
            "workspaces": [
                {"id": ws.id, "name": ws.name, "type": ws.type}
                for ws in sorted(nonempty_workspaces, key=lambda item: item.name.casefold())
            ],
            "apis": apis,
            "errors": errors,
            "lazyDefinitions": True,
        }
