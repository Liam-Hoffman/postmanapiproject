$ErrorActionPreference = "Stop"
if (-not $env:POSTMAN_API_KEY) {
  Write-Error "Set POSTMAN_API_KEY first: `$env:POSTMAN_API_KEY = 'PMAK-your-key'"
}
python "$PSScriptRoot\server.py"
