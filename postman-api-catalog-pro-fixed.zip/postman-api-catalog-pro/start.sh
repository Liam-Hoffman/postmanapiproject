#!/usr/bin/env sh
set -eu
if [ -z "${POSTMAN_API_KEY:-}" ]; then
  echo "Set POSTMAN_API_KEY first: export POSTMAN_API_KEY='PMAK-your-key'" >&2
  exit 1
fi
exec python3 "$(dirname "$0")/server.py"
