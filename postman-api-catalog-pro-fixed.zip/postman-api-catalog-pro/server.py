#!/usr/bin/env python3
"""Zero-dependency internal Postman API Catalog server."""
from __future__ import annotations

import json
import mimetypes
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

BASE_DIR = Path(__file__).resolve().parent
PUBLIC_DIR = BASE_DIR / "public"
POSTMAN_BASE_URL = os.getenv("POSTMAN_BASE_URL", "https://api.getpostman.com").rstrip("/")
POSTMAN_API_KEY = os.getenv("POSTMAN_API_KEY", "")
PORT = int(os.getenv("PORT", "8080"))
HOST = os.getenv("HOST", "127.0.0.1")
CACHE_TTL_SECONDS = int(os.getenv("CACHE_TTL_SECONDS", "600"))
REQUEST_TIMEOUT_SECONDS = int(os.getenv("REQUEST_TIMEOUT_SECONDS", "30"))
WORKSPACE_ALLOWLIST = {x.strip() for x in os.getenv("POSTMAN_WORKSPACE_ALLOWLIST", "").split(",") if x.strip()}
INCLUDE_COLLECTIONS = os.getenv("INCLUDE_COLLECTIONS", "true").lower() in {"1", "true", "yes", "on"}
MAX_DEFINITION_WORKERS = max(1, min(int(os.getenv("MAX_DEFINITION_WORKERS", "6")), 16))

HTTP_METHODS = {"get", "post", "put", "patch", "delete", "head", "options", "trace"}


class PostmanError(RuntimeError):
    pass


def _json_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def postman_get(path: str, query: dict[str, Any] | None = None) -> Any:
    if not POSTMAN_API_KEY:
        raise PostmanError("POSTMAN_API_KEY is not configured")
    url = f"{POSTMAN_BASE_URL}{path}"
    if query:
        clean = {k: v for k, v in query.items() if v is not None and v != ""}
        if clean:
            url += "?" + urllib.parse.urlencode(clean)
    request = urllib.request.Request(
        url,
        headers={
            "X-API-Key": POSTMAN_API_KEY,
            "Accept": "application/json",
            "User-Agent": "internal-postman-api-catalog/2.0",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=REQUEST_TIMEOUT_SECONDS) as response:
            raw = response.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")[:1000]
        raise PostmanError(f"Postman HTTP {exc.code}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise PostmanError(f"Unable to reach Postman: {exc.reason}") from exc
    except json.JSONDecodeError as exc:
        raise PostmanError("Postman returned invalid JSON") from exc


def list_paginated(path: str, response_keys: tuple[str, ...], extra_query: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    limit, offset = 100, 0
    while True:
        query = {"limit": limit, "offset": offset, **(extra_query or {})}
        payload = postman_get(path, query)
        page: list[dict[str, Any]] = []
        if isinstance(payload, dict):
            for key in response_keys:
                if isinstance(payload.get(key), list):
                    page = payload[key]
                    break
            if not page and isinstance(payload.get("data"), list):
                page = payload["data"]
        items.extend(x for x in page if isinstance(x, dict))
        if len(page) < limit:
            break
        offset += limit
    return items


def parse_definition_payload(payload: Any) -> tuple[dict[str, Any] | None, str | None]:
    value = payload.get("definition", payload) if isinstance(payload, dict) else payload
    if isinstance(value, dict):
        # Some responses wrap content one additional level deep.
        content = value.get("content")
        if isinstance(content, dict):
            return content, None
        if isinstance(content, str):
            value = content
        else:
            return value, None
    if isinstance(value, str):
        try:
            parsed = json.loads(value)
            return parsed if isinstance(parsed, dict) else None, None
        except json.JSONDecodeError:
            return None, "YAML definitions are listed but not parsed by the zero-dependency server"
    return None, "Unsupported definition response"


def extension(info: dict[str, Any], key: str, default: str = "") -> str:
    value = info.get(key, default)
    return str(value) if value is not None else default


def normalize_spec_summary(spec: dict[str, Any]) -> dict[str, Any]:
    workspace = spec.get("workspace") if isinstance(spec.get("workspace"), dict) else {}
    return {
        "id": str(spec.get("id") or spec.get("uid") or spec.get("specId") or ""),
        "name": str(spec.get("name") or spec.get("title") or "Unnamed API"),
        "resourceType": "spec",
        "specType": str(spec.get("type") or spec.get("schemaType") or "Specification"),
        "workspaceId": str(spec.get("workspaceId") or workspace.get("id") or ""),
        "workspaceName": str(workspace.get("name") or ""),
        "updatedAt": spec.get("updatedAt") or spec.get("updated_at"),
        "description": str(spec.get("description") or ""),
        "version": "",
        "owner": "Unassigned",
        "support": "",
        "lifecycle": "Unspecified",
        "domain": "Unspecified",
        "servers": [],
        "tags": [],
        "security": [],
        "operations": [],
        "operationCount": 0,
        "deprecatedCount": 0,
        "definitionAvailable": False,
        "definitionWarning": "",
    }


def enrich_spec(record: dict[str, Any]) -> dict[str, Any]:
    if not record["id"]:
        return record
    payload = postman_get(f"/specs/{urllib.parse.quote(record['id'])}/definition")
    definition, warning = parse_definition_payload(payload)
    record["definitionWarning"] = warning or ""
    if not definition:
        return record
    record["definitionAvailable"] = True
    info = definition.get("info") if isinstance(definition.get("info"), dict) else {}
    record["name"] = str(info.get("title") or record["name"])
    record["description"] = str(info.get("description") or record["description"])
    record["version"] = str(info.get("version") or "")
    record["owner"] = extension(info, "x-owner-team", extension(info, "x-owner", "Unassigned"))
    record["support"] = extension(info, "x-support-channel")
    record["lifecycle"] = extension(info, "x-lifecycle", "Unspecified")
    record["domain"] = extension(info, "x-business-domain", extension(info, "x-domain", "Unspecified"))
    record["servers"] = [str(x.get("url")) for x in definition.get("servers", []) if isinstance(x, dict) and x.get("url")]
    record["tags"] = [str(x.get("name")) for x in definition.get("tags", []) if isinstance(x, dict) and x.get("name")]
    security_schemes = (((definition.get("components") or {}).get("securitySchemes")) if isinstance(definition.get("components"), dict) else {}) or {}
    record["security"] = sorted(str(k) for k in security_schemes.keys()) if isinstance(security_schemes, dict) else []
    operations: list[dict[str, Any]] = []
    paths = definition.get("paths") if isinstance(definition.get("paths"), dict) else {}
    for path, path_item in paths.items():
        if not isinstance(path_item, dict):
            continue
        for method, operation in path_item.items():
            if method.lower() not in HTTP_METHODS:
                continue
            operation = operation if isinstance(operation, dict) else {}
            operations.append({
                "method": method.upper(),
                "path": str(path),
                "summary": str(operation.get("summary") or operation.get("description") or ""),
                "operationId": str(operation.get("operationId") or ""),
                "deprecated": bool(operation.get("deprecated", False)),
                "tags": [str(x) for x in operation.get("tags", []) if x is not None],
            })
    operations.sort(key=lambda x: (x["path"], x["method"]))
    record["operations"] = operations
    record["operationCount"] = len(operations)
    record["deprecatedCount"] = sum(1 for x in operations if x["deprecated"])
    return record


def flatten_collection_items(items: list[Any], prefix: str = "") -> list[dict[str, Any]]:
    operations: list[dict[str, Any]] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        name = str(item.get("name") or "")
        if isinstance(item.get("item"), list):
            operations.extend(flatten_collection_items(item["item"], f"{prefix}{name} / "))
            continue
        request = item.get("request") if isinstance(item.get("request"), dict) else {}
        method = str(request.get("method") or "GET").upper()
        url = request.get("url")
        if isinstance(url, dict):
            path_parts = url.get("path") if isinstance(url.get("path"), list) else []
            path = "/" + "/".join(str(x) for x in path_parts) if path_parts else str(url.get("raw") or "")
        else:
            path = str(url or "")
        operations.append({"method": method, "path": path, "summary": f"{prefix}{name}".strip(), "operationId": "", "deprecated": False, "tags": []})
    return operations


def load_workspaces() -> list[dict[str, Any]]:
    payload = postman_get("/workspaces")
    workspaces = payload.get("workspaces", []) if isinstance(payload, dict) else []
    records = [x for x in workspaces if isinstance(x, dict) and x.get("id")]
    if WORKSPACE_ALLOWLIST:
        records = [x for x in records if str(x.get("id")) in WORKSPACE_ALLOWLIST]
    return records


def load_specs(workspaces: list[dict[str, Any]]) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for workspace in workspaces:
        workspace_id = str(workspace.get("id") or "")
        workspace_name = str(workspace.get("name") or "")
        if not workspace_id:
            continue
        summaries = list_paginated(
            "/specs",
            ("specs", "specifications"),
            {"workspaceId": workspace_id},
        )
        for summary in summaries:
            record = normalize_spec_summary(summary)
            if not record["workspaceId"]:
                record["workspaceId"] = workspace_id
            if not record["workspaceName"]:
                record["workspaceName"] = workspace_name
            records.append(record)
    return records


def load_collections() -> list[dict[str, Any]]:
    if not INCLUDE_COLLECTIONS:
        return []
    summaries = list_paginated("/collections", ("collections",))
    records: list[dict[str, Any]] = []
    for summary in summaries:
        uid = str(summary.get("uid") or summary.get("id") or "")
        workspace_id = str(summary.get("workspaceId") or "")
        if WORKSPACE_ALLOWLIST and workspace_id and workspace_id not in WORKSPACE_ALLOWLIST:
            continue
        record = {
            "id": uid,
            "name": str(summary.get("name") or "Unnamed Collection"),
            "resourceType": "collection",
            "specType": "Postman Collection",
            "workspaceId": workspace_id,
            "workspaceName": "",
            "updatedAt": summary.get("updatedAt"),
            "description": "",
            "version": "",
            "owner": "Unassigned",
            "support": "",
            "lifecycle": "Unspecified",
            "domain": "Unspecified",
            "servers": [],
            "tags": [],
            "security": [],
            "operations": [],
            "operationCount": 0,
            "deprecatedCount": 0,
            "definitionAvailable": False,
            "definitionWarning": "",
        }
        try:
            payload = postman_get(f"/collections/{urllib.parse.quote(uid)}")
            collection = payload.get("collection", {}) if isinstance(payload, dict) else {}
            info = collection.get("info") if isinstance(collection.get("info"), dict) else {}
            description = info.get("description")
            if isinstance(description, dict):
                description = description.get("content")
            record["description"] = str(description or "")
            record["version"] = str(info.get("version") or "")
            operations = flatten_collection_items(collection.get("item", []) if isinstance(collection.get("item"), list) else [])
            record["operations"] = operations
            record["operationCount"] = len(operations)
            record["definitionAvailable"] = True
        except PostmanError as exc:
            record["definitionWarning"] = str(exc)
        records.append(record)
    return records


@dataclass
class Cache:
    lock: threading.Lock
    value: dict[str, Any] | None = None
    generated_at: float = 0
    last_error: str = ""

    def fresh(self) -> bool:
        return self.value is not None and (time.time() - self.generated_at) < CACHE_TTL_SECONDS


CACHE = Cache(threading.Lock())


def build_catalog() -> dict[str, Any]:
    workspaces = load_workspaces()
    records = load_specs(workspaces)

    # Fixed-size worker pool without third-party dependencies.
    queue = records[:]
    enriched: list[dict[str, Any]] = []
    result_lock = threading.Lock()

    def worker() -> None:
        while True:
            with result_lock:
                if not queue:
                    return
                record = queue.pop()
            try:
                record = enrich_spec(record)
            except PostmanError as exc:
                record["definitionWarning"] = str(exc)
            with result_lock:
                enriched.append(record)

    threads = [threading.Thread(target=worker, daemon=True) for _ in range(min(MAX_DEFINITION_WORKERS, max(1, len(queue))))]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    enriched.extend(load_collections())
    enriched.sort(key=lambda x: (x["name"].casefold(), x["resourceType"]))
    owners = sorted({x["owner"] for x in enriched if x["owner"] and x["owner"] != "Unassigned"})
    domains = sorted({x["domain"] for x in enriched if x["domain"] and x["domain"] != "Unspecified"})
    lifecycles = sorted({x["lifecycle"] for x in enriched if x["lifecycle"] and x["lifecycle"] != "Unspecified"})
    return {
        "generatedAt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "count": len(enriched),
        "specCount": sum(1 for x in enriched if x["resourceType"] == "spec"),
        "collectionCount": sum(1 for x in enriched if x["resourceType"] == "collection"),
        "operationCount": sum(x["operationCount"] for x in enriched),
        "deprecatedCount": sum(x["deprecatedCount"] for x in enriched),
        "owners": owners,
        "domains": domains,
        "lifecycles": lifecycles,
        "apis": enriched,
    }


def get_catalog(force: bool = False) -> dict[str, Any]:
    with CACHE.lock:
        if not force and CACHE.fresh():
            return CACHE.value  # type: ignore[return-value]
        try:
            CACHE.value = build_catalog()
            CACHE.generated_at = time.time()
            CACHE.last_error = ""
        except Exception as exc:
            CACHE.last_error = str(exc)
            if CACHE.value is None:
                raise
        return CACHE.value  # type: ignore[return-value]


class Handler(BaseHTTPRequestHandler):
    server_version = "PostmanCatalog/2.0"

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[{self.log_date_time_string()}] {self.address_string()} {fmt % args}")

    def send_json(self, status: int, payload: Any) -> None:
        body = _json_bytes(payload)
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def serve_static(self, relative: str) -> None:
        target = (PUBLIC_DIR / relative.lstrip("/")).resolve()
        if not str(target).startswith(str(PUBLIC_DIR.resolve())) or not target.is_file():
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        body = target.read_bytes()
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_response(HTTPStatus.OK)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "public, max-age=300")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/catalog":
            try:
                self.send_json(200, get_catalog())
            except Exception as exc:
                self.send_json(502, {"error": "Unable to build catalog", "details": str(exc)})
            return
        if path == "/api/health":
            self.send_json(200, {"status": "ok", "configured": bool(POSTMAN_API_KEY), "cached": CACHE.value is not None, "lastError": CACHE.last_error})
            return
        if path == "/" or path == "/index.html":
            self.serve_static("index.html")
            return
        self.serve_static(path)

    def do_POST(self) -> None:
        path = urllib.parse.urlparse(self.path).path
        if path == "/api/catalog/refresh":
            try:
                self.send_json(200, get_catalog(force=True))
            except Exception as exc:
                self.send_json(502, {"error": "Unable to refresh catalog", "details": str(exc)})
            return
        self.send_error(HTTPStatus.NOT_FOUND)


if __name__ == "__main__":
    if not POSTMAN_API_KEY:
        print("WARNING: POSTMAN_API_KEY is not set. The dashboard will load, but catalog requests will fail.")
    print(f"Postman API Catalog: http://{HOST}:{PORT}")
    ThreadingHTTPServer((HOST, PORT), Handler).serve_forever()
