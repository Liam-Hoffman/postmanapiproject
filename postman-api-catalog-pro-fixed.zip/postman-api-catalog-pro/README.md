# Postman API Catalog Pro — zero npm dependencies

A self-contained internal API catalog built with Python's standard library and vanilla HTML, CSS, and JavaScript.

## Features

- Reads Postman Spec Hub specifications and optionally Postman Collections
- Full-text search across names, descriptions, owners, tags, paths, and operations
- Filters for source, owner, and lifecycle
- API detail dialog with endpoints, authentication schemes, workspace, and support metadata
- Catalog metrics and deprecated-operation visibility
- In-memory caching and manual refresh
- Workspace allowlist support
- Light and dark modes
- No Node.js, npm, pip packages, or frontend build step

## Requirements

- Python 3.10 or newer
- A Postman API key with access to the desired resources

## Start on Windows PowerShell

```powershell
cd postman-api-catalog-pro
$env:POSTMAN_API_KEY = "PMAK-your-key"
.\start.ps1
```

Then open http://127.0.0.1:8080.

## Start on macOS or Linux

```bash
cd postman-api-catalog-pro
export POSTMAN_API_KEY="PMAK-your-key"
./start.sh
```

## Configuration

| Variable | Default | Purpose |
|---|---:|---|
| `POSTMAN_API_KEY` | required | Postman API key; never expose it in browser code |
| `POSTMAN_BASE_URL` | `https://api.getpostman.com` | Postman API base URL |
| `HOST` | `127.0.0.1` | Bind address; use `0.0.0.0` in a container or internal server |
| `PORT` | `8080` | HTTP port |
| `CACHE_TTL_SECONDS` | `600` | Catalog cache lifetime |
| `REQUEST_TIMEOUT_SECONDS` | `30` | Upstream request timeout |
| `POSTMAN_WORKSPACE_ALLOWLIST` | empty | Comma-separated workspace IDs |
| `INCLUDE_COLLECTIONS` | `true` | Include collections as catalog entries |
| `MAX_DEFINITION_WORKERS` | `6` | Parallel definition requests, capped at 16 |

## Recommended OpenAPI metadata

Add these optional extensions to each OpenAPI document:

```yaml
info:
  title: Customer API
  version: 1.4.0
  description: Manages customer records.
  x-owner-team: Customer Platform
  x-support-channel: "#customer-api-support"
  x-lifecycle: production
  x-business-domain: Customer Management
```

## Important security notes

- The API key stays in the Python process. It is never returned to the browser.
- Bind to `127.0.0.1` for local use.
- For shared use, place this application behind company SSO, a VPN, or an authenticated reverse proxy.
- Use a dedicated Postman service account or least-privilege key where available.

## Endpoints

- `GET /` — dashboard
- `GET /api/catalog` — normalized catalog payload
- `POST /api/catalog/refresh` — force cache refresh
- `GET /api/health` — health and configuration status

## Gmail-safe transfer

Gmail may inspect and block archives containing scripts. The included `.base64.txt` transport file can be emailed as plain text and decoded later:

```powershell
$encoded = Get-Content .\postman-api-catalog-pro.zip.base64.txt -Raw
[IO.File]::WriteAllBytes("postman-api-catalog-pro.zip", [Convert]::FromBase64String($encoded))
```

On macOS/Linux:

```bash
base64 --decode postman-api-catalog-pro.zip.base64.txt > postman-api-catalog-pro.zip
```

## Workspace discovery

The server first calls `GET /workspaces`, then calls `GET /specs?workspaceId=...` for each accessible workspace. Set `POSTMAN_WORKSPACE_ALLOWLIST` to a comma-separated list of workspace IDs to restrict the catalog and reduce API calls.
