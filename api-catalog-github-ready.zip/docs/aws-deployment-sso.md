# EKS Deployment with Application-Level Keycloak SSO

The company standard for this application is Keycloak authentication inside Flask. The EKS Ingress/ALB provides TLS termination and routing only.

## Architecture

```mermaid
flowchart LR
    U[Internal employees] --> DNS[Internal DNS]
    DNS --> ALB[Internal AWS ALB / EKS Ingress]
    ALB --> SVC[Kubernetes Service]
    SVC --> PODS[API Catalog pods\nFlask + React]
    PODS --> KC[Keycloak OIDC]
    PODS --> GH[GitHub API]
    PODS --> SEC[Kubernetes Secret or AWS Secrets Manager integration]
```

## Services and components

- Amazon EKS
- AWS Load Balancer Controller
- Internal Application Load Balancer
- ACM certificate
- Internal DNS
- Amazon ECR
- Keycloak
- GitHub/GitHub Enterprise
- Kubernetes ConfigMap
- Kubernetes Secret, External Secrets, or Secrets Store CSI Driver
- CloudWatch/container log collection according to cluster standards

## Deployment files

Use:

```text
deploy/eks/
deploy/keycloak/
```

The Kubernetes manifests include:

- Namespace
- ServiceAccount without API token mounting
- ConfigMap
- Deployment with two replicas
- ClusterIP Service
- Internal ALB Ingress
- PodDisruptionBudget
- Kustomization
- Secret example

## Authentication responsibilities

### Keycloak

- Authenticate employees
- Maintain company SSO
- Return identity claims
- Return the `groups` claim

### Flask

- Start Authorization Code login
- Validate OIDC state, issuer, token signature, nonce, and audience through Authlib
- Fetch UserInfo
- Enforce configured Keycloak group membership
- Create the application session
- Protect API and frontend routes
- Clear local session and initiate logout

### React

- Display the signed-in user
- Redirect to login when an API request receives HTTP 401
- Provide a Sign out control
- Never process Keycloak tokens

### Ingress/ALB

- Terminate HTTPS
- Forward requests to the Kubernetes Service
- Perform health checks against `/api/health`
- Not perform OIDC authentication

## Secrets

Required secret values:

```text
GITHUB_ACCESS_TOKEN
KEYCLOAK_CLIENT_SECRET
SESSION_SECRET
```

Every replica must have the same `SESSION_SECRET`.

Kubernetes Secret values are not inherently encrypted merely because they are Base64 encoded. Use the organization's standard encryption-at-rest and AWS Secrets Manager integration.

## Network access

Pods require outbound connectivity to:

- Keycloak issuer/discovery/token/UserInfo endpoints
- GitHub API or GitHub Enterprise

Employee browsers require connectivity to:

- Catalog hostname
- Keycloak login hostname

## Production settings

```env
AUTH_MODE=keycloak
PUBLIC_BASE_URL=https://api-catalog.internal.company.com
SESSION_COOKIE_SECURE=true
TRUST_PROXY_HEADERS=true
KEYCLOAK_ISSUER_URL=https://keycloak.company.com/realms/api-catalog
KEYCLOAK_CLIENT_ID=api-catalog-web
KEYCLOAK_GROUP_CLAIM=groups
KEYCLOAK_REQUIRED_GROUPS=/api-catalog-users
KEYCLOAK_SCOPES=openid profile email
KEYCLOAK_IDP_HINT=entra
```

## Rollout order

1. Create/approve the AD/Entra security group used for catalog access.
2. Create the Entra App Registration used by Keycloak and configure its group claim.
3. Create the Keycloak `api-catalog` realm and Microsoft Identity Provider.
4. Map the approved Entra group Object ID to Keycloak `/api-catalog-users`.
5. Create/import the `api-catalog-web` Keycloak client and Group Membership mapper.
6. Build and push the API Catalog image to ECR.
7. Create Kubernetes secrets.
8. Update ConfigMap, image, hostname, and certificate ARN.
9. Apply manifests.
10. Verify `/api/health` through the ALB.
11. Open the catalog and complete Microsoft SSO through Keycloak.
12. Test a user without the AD/Entra group and confirm HTTP 403/access-denied behavior.
