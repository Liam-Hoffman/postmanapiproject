# Troubleshooting

## Setup fails with `NameError: name 'backend' is not defined`

Cause: an older build passed an inline Python expression through PowerShell and lost quotes.

Resolution:

- Use the current build
- Confirm `backend/verify_installation.py` exists
- Rerun `setup.bat`

## Setup reports a null-valued expression

This was a secondary error after failed repository URL parsing in an older script.

Use the current `setup.ps1`, which checks command output before calling string methods.

## Only some APIs appear

Run:

```bat
discovery-report.bat
```

Or:

```text
GET /api/discovery?refresh=true
```

Review:

```text
ref
searchRoot
extensionCandidateCount
matchedSpecCount
rejectedFiles
excludedBySearchRootPaths
recursiveTreeTruncated
traversalMode
```

Common causes:

- File is not on the default branch
- Extension is not configured
- `GITHUB_SEARCH_ROOT` excludes the file
- Invalid JSON/YAML
- Missing OpenAPI marker
- Missing `info.title`
- Missing `paths`
- Git submodule content is not part of the parent repository tree

## GitHub returns 401

Check:

- Token was copied correctly
- Token has not expired
- Secret does not include surrounding quotes
- Token belongs to the correct GitHub host

Rotate the token when uncertain.

## GitHub returns 403

Possible causes:

- Organization policy blocks the token
- Fine-grained PAT is awaiting approval
- SAML SSO authorization is required
- Rate limit exhausted
- Repository permission is missing

Check `/api/source-health` and GitHub organization policies.

## GitHub returns 404 for a private repository

GitHub often returns 404 when the caller lacks private repository access.

Check:

- Repository URL
- Owner and repository spelling
- Token repository selection
- Contents read permission

## GitHub Enterprise cannot be reached

Check:

- DNS from the runtime
- VPC/company network routes
- Firewall rules
- Enterprise TLS certificate trust
- API base URL mapping
- Proxy requirements

## `/api/health` works but catalog fails

`/api/health` is local-only. Check:

```text
/api/source-health
/api/discovery?refresh=true
```

The likely problem is GitHub access, parsing, or scanning.

## `/api/source-health` works but scan fails

Possible causes:

- Rate limiting during many blob requests
- Candidate file too large or invalid
- Unexpected GitHub API response
- Network timeout
- YAML parsing issue

Increase timeout carefully:

```env
GITHUB_REQUEST_TIMEOUT_SECONDS=60
```

Reduce concurrency:

```env
GITHUB_SCAN_WORKERS=4
```

## Endpoint search misses results

Check:

- Detail-loading progress completed
- Operation includes method/path/summary/description/operation ID/tag
- API is not excluded by API search
- Search term is not only in response schemas, which are not part of endpoint search text

## API name is incorrect

The title comes from `info.title`.

The displayed major version uses the first numeric segment from `info.version`.

Examples:

```text
2.7.1      → V2
v3-beta    → V3
2026-07-01 → V2026
```

Date-style versions therefore display the year as the major version.

## External schema fields are missing

External relative `$ref` files are not resolved.

Bundle the OpenAPI document or replace references with local JSON Pointers.

## Frontend shows `Frontend build not found`

Run:

```bash
npm --prefix frontend install
npm --prefix frontend run build
```

For local development, use `start-dev.bat` or `start-dev.sh`.

## Docker frontend dependency install fails

The current Dockerfile uses `npm install` because the source archive does not include a lockfile. For production reproducibility, generate and commit `frontend/package-lock.json`, pin reviewed versions, and then change the Dockerfile back to `npm ci`.

## EKS pod or ALB target is unhealthy

Check:

- Container listens on `0.0.0.0:8080`
- Service targets the named `http` container port
- Ingress health path is `/api/health`
- ALB target type is `ip`
- Pod startup/readiness/liveness probe events
- Pod logs
- Gunicorn started successfully
- Secret and ConfigMap names exist

## SSO redirects repeatedly

Check:

- `PUBLIC_BASE_URL` exactly matches the browser hostname
- Keycloak Valid Redirect URI is exactly `https://<host>/auth/callback`
- Keycloak Valid Post Logout Redirect URI is exactly `https://<host>/auth/logged-out`
- `KEYCLOAK_ISSUER_URL` is the realm issuer
- Client authentication and Standard Flow are enabled
- Client ID and secret are correct
- Ingress forwards `X-Forwarded-*` headers and `TRUST_PROXY_HEADERS=true`
- Every pod has the same `SESSION_SECRET`
- Browser cookies are allowed and Secure cookies are used only over HTTPS
- System clocks are synchronized

## User signs in but receives access denied

Check:

- User is assigned to the exact configured Keycloak group
- `KEYCLOAK_REQUIRED_GROUPS` matches case and full path
- Group Membership mapper claim name matches `KEYCLOAK_GROUP_CLAIM`
- Mapper includes the claim in ID token and UserInfo
- Full group path setting matches the configured value
- User logged out and back in after group assignment

## Updated secret is not used

Environment variables are set when a pod starts. Restart or roll out the Deployment after updating the Kubernetes/external secret.

## Refresh appears inconsistent

Cause: independent caches in multiple EKS pods.

Resolution:

- Roll out/restart all pods
- Use one Gunicorn worker for simple deployments
- Add a shared cache in a future version

## Setup fails with `No module named 'requests'`

Cause: the Keycloak/Authlib HTTP client requires the Python `requests` package. An earlier Keycloak build added Authlib but did not list `requests` in `backend/requirements.txt`.

Current-build resolution:

```bat
setup.bat
```

The corrected requirements file installs:

```text
requests>=2.32,<3
```

Immediate repair for an already extracted older build:

```powershell
.\.venv\Scripts\python.exe -m pip install "requests>=2.32,<3"
.\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
.\.venv\Scripts\python.exe backend\verify_installation.py dependencies
.\.venv\Scripts\python.exe backend\verify_installation.py imports
```

Then rerun:

```bat
setup.bat
```

## Microsoft SSO redirects to `AADSTS50011`

Cause: the redirect URI in the Entra App Registration does not exactly match the Keycloak broker callback.

The Entra application represents **Keycloak**, so its redirect URI is the Keycloak Identity Provider broker endpoint, not the API Catalog `/auth/callback` URL.

For local testing, copy the Redirect URI shown on the Keycloak `entra` Identity Provider page. It should be under:

```text
http://localhost:8180/realms/api-catalog-local/broker/entra/endpoint
```

For production, copy the corresponding HTTPS Keycloak broker URI.

## The app shows the Keycloak login page instead of Microsoft

Check:

```env
KEYCLOAK_IDP_HINT=entra
```

and confirm the Keycloak Identity Provider alias is exactly:

```text
entra
```

If the alias does not exist, Keycloak falls back to its own login page.

## Microsoft login succeeds but the API Catalog returns 403

Check the complete claim mapping chain:

1. The employee is a member of the approved AD/Entra security group.
2. The Entra App Registration emits a `groups` claim.
3. The claim includes the approved group's immutable Entra Object ID.
4. The Keycloak `entra` Identity Provider has an **Advanced Claim to Group** mapper matching that Object ID.
5. The mapper targets `/api-catalog-users` and uses `Force` sync for repeated logins.
6. The API Catalog Keycloak client has a Group Membership mapper that emits full group paths as `groups` in UserInfo/ID token.
7. The app uses:

```env
KEYCLOAK_GROUP_CLAIM=groups
KEYCLOAK_REQUIRED_GROUPS=/api-catalog-users
```

Sign out before retesting so the application creates a fresh authorization session.

## Entra does not emit the expected group

Large corporate memberships can exceed Microsoft Entra's JWT group-claim limit. Prefer configuring the Entra application to emit only groups assigned/relevant to the application when your tenant process supports that approach.

Also verify that the expected group is in scope for the application's group-claim configuration and that directory synchronization has completed.

## `start-dev.bat` fails in Keycloak mode during source-health

The current build detects `AUTH_MODE=keycloak` and verifies GitHub directly through `backend/verify_installation.py github-access` instead of calling the protected `/api/source-health` endpoint. If you see the old 401 startup behavior, confirm you are using this Entra-broker build rather than an earlier Keycloak ZIP.

