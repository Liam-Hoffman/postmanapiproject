# Configuration Reference

Configuration is read from process environment variables. Local scripts load the root `.env`.

## Required values

### `GITHUB_REPOSITORY_URL`

Repository root URL.

Examples:

```env
GITHUB_REPOSITORY_URL=https://github.com/company/documentation-repo
GITHUB_REPOSITORY_URL=https://github.company.com/company/documentation-repo
```

The application automatically determines the REST API base URL.

### `GITHUB_ACCESS_TOKEN`

Token used for backend GitHub API requests.

```env
GITHUB_ACCESS_TOKEN=github_pat_...
```

`GITHUB_TOKEN` remains a backwards-compatible alias when `GITHUB_ACCESS_TOKEN` is empty.

Do not expose either variable to Vite or browser code.

## GitHub scan settings

### `GITHUB_SEARCH_ROOT`

Optional repository directory prefix.

```env
GITHUB_SEARCH_ROOT=services/apis
```

An empty value scans the full repository tree.

### `GITHUB_SPEC_EXTENSIONS`

Comma-separated candidate extensions.

Default:

```env
GITHUB_SPEC_EXTENSIONS=.json,.yml,.yaml
```

Values without a leading period are normalized.

### `GITHUB_SCAN_WORKERS`

Number of concurrent candidate-validation workers.

Default:

```env
GITHUB_SCAN_WORKERS=8
```

Minimum: `1`  
Maximum: `24`

### `GITHUB_API_VERSION`

GitHub REST API version header.

Default:

```env
GITHUB_API_VERSION=2022-11-28
```

Review this value against the GitHub environment's supported API versions before changing it.

### `GITHUB_REQUEST_TIMEOUT_SECONDS`

Timeout for one GitHub request.

Default:

```env
GITHUB_REQUEST_TIMEOUT_SECONDS=30
```

Minimum: `1`

### `GITHUB_MAX_RETRIES`

Maximum retry count for retryable responses.

Default:

```env
GITHUB_MAX_RETRIES=3
```

Minimum: `0`  
Maximum: `8`

Retryable cases include:

- HTTP 429
- Selected 5xx responses
- Rate-limited HTTP 403
- Network failures

### `GITHUB_RETRY_BUFFER_SECONDS`

Additional delay added to retry timing.

Default:

```env
GITHUB_RETRY_BUFFER_SECONDS=1
```

Minimum: `0`

## Application settings

### `APP_ENV`

Environment label returned by `/api/health`.

Local default:

```env
APP_ENV=development
```

Docker production value:

```env
APP_ENV=production
```

### `CATALOG_HOST`

Flask bind host.

Local default:

```env
CATALOG_HOST=127.0.0.1
```

Container value:

```env
CATALOG_HOST=0.0.0.0
```

### `CATALOG_PORT`

Backend port.

Default:

```env
CATALOG_PORT=8080
```

### `CATALOG_CACHE_TTL_SECONDS`

Process-local catalog cache duration.

Default:

```env
CATALOG_CACHE_TTL_SECONDS=900
```

Set to `0` to disable time-based reuse, although each request may then trigger an expensive repository scan.

## Development-only frontend setting

### `VITE_API_TARGET`

Optional Vite proxy target.

Default behavior:

```text
http://<CATALOG_HOST>:<CATALOG_PORT>
```

Example:

```env
VITE_API_TARGET=http://127.0.0.1:8080
```

Do not put secrets in any `VITE_*` variable because Vite variables can be bundled into frontend assets.

## Example local `.env`

```env
APP_ENV=development

GITHUB_REPOSITORY_URL=https://github.com/company/documentation-repo
GITHUB_ACCESS_TOKEN=github_pat_replace_me
GITHUB_SEARCH_ROOT=
GITHUB_SPEC_EXTENSIONS=.json,.yml,.yaml
GITHUB_SCAN_WORKERS=8
GITHUB_API_VERSION=2022-11-28
GITHUB_REQUEST_TIMEOUT_SECONDS=30
GITHUB_MAX_RETRIES=3
GITHUB_RETRY_BUFFER_SECONDS=1

CATALOG_HOST=127.0.0.1
CATALOG_PORT=8080
CATALOG_CACHE_TTL_SECONDS=900
```

## Example ECS environment configuration

Normal environment variables:

```text
APP_ENV=production
CATALOG_HOST=0.0.0.0
CATALOG_PORT=8080
GITHUB_REPOSITORY_URL=https://github.com/company/documentation-repo
GITHUB_SPEC_EXTENSIONS=.json,.yml,.yaml
GITHUB_SCAN_WORKERS=8
CATALOG_CACHE_TTL_SECONDS=900
```

Secret injection:

```text
GITHUB_ACCESS_TOKEN → AWS Secrets Manager
```


## Application authentication settings

### `AUTH_MODE`

```text
disabled
keycloak
```

Use `disabled` for ordinary local development and `keycloak` in EKS.

### `PUBLIC_BASE_URL`

Exact browser-visible base URL. Used to build the callback and logout return URLs.

### `SESSION_SECRET`

Shared signing secret for the HTTP-only Flask session cookie. Minimum 32 characters. All pods must use the same value.

### `SESSION_COOKIE_NAME`

Default: `api_catalog_session`

### `SESSION_COOKIE_SECURE`

Set `true` in EKS/HTTPS and `false` only for local HTTP testing.

### `SESSION_LIFETIME_SECONDS`

Default: `28800` (eight hours).

### `TRUST_PROXY_HEADERS`

Set `true` behind the EKS ingress. The app trusts one layer of forwarded proxy headers.

### `KEYCLOAK_ISSUER_URL`

Realm issuer, for example:

```text
https://keycloak.company.com/realms/api-catalog
```

### `KEYCLOAK_CLIENT_ID` and `KEYCLOAK_CLIENT_SECRET`

Confidential OIDC client credentials.

### `KEYCLOAK_GROUP_CLAIM`

Default: `groups`. Dotted claim paths are supported.

### `KEYCLOAK_REQUIRED_GROUPS`

Comma-separated exact group values. Membership in any value grants access.

### `KEYCLOAK_SCOPES`

Default: `openid profile email`.

### `KEYCLOAK_PROMPT`

Optional OIDC `prompt` parameter. Leave empty for normal SSO behavior.

### `KEYCLOAK_IDP_HINT`

Optional Keycloak identity-provider alias sent as `kc_idp_hint`. Set to `entra` for this architecture so employees are sent directly to Microsoft Entra rather than stopping on the Keycloak login selector. Leave empty when testing local Keycloak users.
