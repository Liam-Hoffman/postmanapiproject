# Operations Runbook

## Service objectives

The catalog is a read-only internal documentation service. The primary dependencies are:

- EKS workload and Kubernetes Service
- Internal Application Load Balancer / Ingress
- Keycloak realm, client, and access group
- GitHub repository and API
- GitHub and Keycloak client secrets
- Shared application session secret
- Internal DNS and TLS

## Health checks

### Application health

```text
GET /api/health
```

Use for Kubernetes and ALB health checks. It does not call GitHub or Keycloak.

### Source health

```text
GET /api/source-health
```

Use to confirm:

- Repository URL parsing
- Token authentication
- Repository visibility
- Default branch lookup

Do not poll this endpoint at high frequency because it calls GitHub.

### Discovery health

```text
GET /api/discovery?refresh=true
```

Use for a full scan diagnostic.

## Standard startup validation

1. Confirm the Deployment has the expected ready replicas.
2. Confirm ALB targets are healthy.
3. Open `/api/health`.
4. Complete a Keycloak login with an allowed-group test user.
5. Open `/api/source-health` after login.
6. Confirm expected API count.
7. Run one API and one endpoint search.
8. Open a detailed API view.
9. Test a user without the group and confirm access is denied.
10. Confirm GitHub source link format.

## Refresh procedure

User-level:

```text
Select Refresh catalog
```

API:

```text
GET /api/catalog?refresh=true
```

Important: refresh affects the pod/process handling that request. Roll out all pods for globally consistent cache invalidation.

## GitHub token rotation

1. Create the replacement token.
2. Confirm repository read access.
3. Update the Kubernetes/external secret source.
4. Roll out the EKS Deployment.
5. Complete Keycloak login and confirm `/api/source-health`.
6. Confirm catalog refresh.
7. Revoke the old token.
8. Record rotation date and owner.

## Keycloak client-secret rotation

1. Generate or rotate the confidential-client secret in Keycloak according to identity-team procedure.
2. Update the Kubernetes/external secret source.
3. Roll out the Deployment.
4. Complete a fresh login and callback.
5. Remove the old credential after validation when dual-secret rotation is supported by company tooling.

## Deployment procedure

1. Build and test the image.
2. Tag the image with the commit SHA.
3. Push to ECR.
4. Update the image tag in the EKS Deployment or release configuration.
5. Apply the manifests/Helm release.
6. Run `kubectl rollout status deployment/api-catalog -n api-catalog`.
7. Confirm healthy pods and ALB targets.
8. Run Keycloak login and group-denial smoke tests.
9. Retain the previous immutable image tag for rollback.

## Rollback

1. Restore the last known-good immutable image tag.
2. Apply the Deployment/release configuration.
3. Wait for Kubernetes rollout completion.
4. Confirm `/api/health`.
5. Complete a Keycloak login.
6. Confirm `/api/source-health` after authentication.
7. Document the failed revision and symptoms.

## Recommended alarms

- Kubernetes unavailable replicas above zero
- Pod restart count
- ALB unhealthy target count above zero
- ALB and target 5xx responses
- Elevated target response time
- Pod CPU and memory utilization
- Keycloak callback failures or access-denied spikes
- GitHub rate-limit or 403 patterns in logs

## Logs

Container output is written to stdout/stderr and should be sent to CloudWatch Logs.

Expected messages include:

```text
[Catalog] Scanning GitHub monorepo ...
[GitHub] Found ... JSON/YAML candidates ...
[Catalog] Validated ... and found ... OpenAPI specifications ...
```

## Capacity considerations

Initial scans download and parse all JSON/YAML candidates. Resource usage grows with:

- Repository tree size
- Candidate file count
- Specification size
- Schema complexity
- `GITHUB_SCAN_WORKERS`
- Number of process/container caches

Start with:

```text
250m CPU request / 1 CPU limit
512 MiB request / 1 GiB limit
2 EKS replicas
1 Gunicorn worker per pod
8 threads per worker
```

Monitor and adjust.

## Cache strategy

Current:

```text
In-memory per process
```

Operational options:

1. Keep one worker per pod
2. Accept independent caches
3. Restart/roll out all pods after important documentation changes
4. Add Redis/shared cache in a future release

## Backup and disaster recovery

No application database exists.

Recovery sources:

- Application source repository
- ECR image
- Kubernetes manifests or Helm release
- Kubernetes/external secrets configuration
- GitHub documentation repository
- Infrastructure configuration

A full redeployment recreates runtime state.

## Ownership matrix

Document company-specific owners:

| Responsibility | Owner |
|---|---|
| Application source | `<team>` |
| Documentation repository | `<team>` |
| GitHub token rotation | `<team/person>` |
| AWS infrastructure | `<platform team>` |
| SSO application | `<identity team>` |
| DNS and certificate | `<network/platform team>` |
| On-call support | `<team>` |
