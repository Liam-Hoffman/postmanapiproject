# Security Model

## Trust boundaries

```text
Browser
  │
  ▼
Trusted reverse proxy / ALB
  │
  ▼
Flask application
  │
  ▼
GitHub API
```

## GitHub token

The token is:

- Read by the backend from environment variables
- Added to GitHub requests as a Bearer token
- Excluded from browser payloads
- Excluded from Git through `.gitignore`
- Entered through hidden input in Windows setup
- Expected to be stored in AWS Secrets Manager in production

The token should have the minimum repository access required.

## Frontend secret isolation

Never place the token in:

```text
frontend source
browser local storage
browser session storage
VITE_* variables
HTML
client-side configuration JSON
```

Anything bundled by Vite must be considered visible to users.

## Authentication

The application implements Keycloak OIDC directly in Flask using a confidential client and Authorization Code flow. EKS Ingress provides routing and TLS, not authentication. Flask protects frontend and API routes, validates the OIDC response through Authlib, and requires configured Keycloak group membership.

## Authorization

Current model:

```text
Only authenticated users in at least one configured Keycloak group receive read-only catalog access.
```

The group is evaluated during login. Existing sessions remain valid until logout or session expiration.

## Data sensitivity

The catalog may reveal:

- Internal API names
- Paths
- Operation summaries
- Schema fields
- Server URLs
- Security-scheme names
- Repository paths
- Owners and support channels
- Raw OpenAPI definitions

Treat the entire application as internal confidential documentation unless reviewed for broader publication.

## Source links

GitHub source URLs are sent to the browser. They do not contain the backend token.

## Logging

The GitHub client logs request method and URL. It does not intentionally log the token.

Review error responses and logs for:

- Internal hostnames
- Repository names
- GitHub upstream URLs
- OpenAPI parsing errors

Do not log environment variables or full request headers.

## Kubernetes and external secret injection

When Kubernetes or an external-secret controller injects secret values as environment variables:

- The value is available to the application process
- A pod restart/rollout is required to pick up changed environment values
- Secret access and deployment permissions should be restricted
- Operators with pod-exec or debugging privileges may be able to inspect process environment

For stronger rotation behavior, a future version can retrieve the secret programmatically at runtime.

## Keycloak client secret

The Keycloak confidential-client secret is read only by the Flask backend. In EKS, provide it through the company-standard Kubernetes/AWS Secrets Manager integration and restrict access to the workload and deployment operators.

## Network controls

Recommended:

- EKS worker nodes/pods in approved private networking
- Internal ALB/Ingress with HTTPS only
- ClusterIP service; no direct public pod exposure
- Security groups/network policy according to company EKS standards
- Controlled outbound access to GitHub and Keycloak
- Internal DNS and private ALB for the internal catalog
- AWS WAF only when required by platform policy

## Dependency management

The project currently uses broad dependency ranges and several frontend dependencies marked `latest`.

Before production:

- Commit lockfiles
- Use `npm ci`
- Pin reviewed dependency versions
- Run vulnerability scanning
- Scan the ECR image
- Establish an upgrade cadence

## Known security limitations

- No application-level user audit log
- No multi-role or per-API authorization beyond the configured allow-list group(s)
- No Content Security Policy configuration
- No request-rate limiting in Flask
- No built-in CSRF concern for read-only endpoints, but future write operations would require review
- Raw specification content is rendered as text, not executed
- External `$ref` content is not fetched, reducing one class of server-side fetch risk


## Keycloak session security

- Keycloak tokens are used only during the server-side callback and are not stored in the browser session.
- The browser cookie is signed, HTTP-only, `SameSite=Lax`, and Secure in production.
- All replicas require the same `SESSION_SECRET`.
- Only the matched authorized group is retained; unrelated group membership is not exposed to React.
- The callback requires Authlib's OIDC state and ID-token validation.
- Access-denied users do not receive an application session.
- Group removal takes effect after current application sessions expire unless the user logs out sooner.
