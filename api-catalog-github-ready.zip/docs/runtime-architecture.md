# Runtime Architecture

## Component diagram

```mermaid
flowchart LR
    U[Browser user] -->|HTTPS or local HTTP| F[React/Vite frontend]
    F -->|/api requests| A[Flask application]
    A --> C[CatalogService]
    C --> G[GitHubMonorepoClient]
    G -->|Bearer token| GH[GitHub REST API]
    C --> P[OpenAPI parser and normalizer]
    C --> M[(In-memory catalog and detail caches)]
    A -->|Production static files| D[frontend/dist]
```

For the EKS hosting model:

```mermaid
flowchart LR
    E[Employees] --> ALB[Internal ALB / EKS Ingress]
    ALB --> EKS[EKS API Catalog pods]
    EKS -->|OIDC authorization code flow| IDP[Keycloak]
    EKS --> GH[GitHub API]
    EKS --> SM[Kubernetes or external secrets]
    EKS --> CW[Cluster logging / CloudWatch]
    ECR[Amazon ECR] --> EKS
```


## Frontend

Technology:

- React
- TypeScript
- Vite
- React Router

Responsibilities:

- Dashboard and detailed documentation UI
- API metadata search
- Endpoint search
- Sorting
- Endpoint expansion
- Operation navigation
- Raw specification display
- Theme persistence

The frontend calls relative `/api` URLs and uses relative `/auth` routes for login/logout. It never receives GitHub or Keycloak tokens.

## Backend

Technology:

- Python
- Flask
- PyYAML
- Gunicorn in the Docker production image

Responsibilities:

- Runtime configuration
- GitHub authentication
- Repository-tree traversal
- JSON/YAML candidate selection
- OpenAPI validation
- Metadata and operation normalization
- Cache management
- Health and diagnostics endpoints
- Keycloak OIDC login and group authorization
- Signed application sessions
- Static frontend serving in production

## GitHub discovery sequence

1. Parse the configured repository URL.
2. Determine:
   - Host
   - Owner
   - Repository
   - GitHub.com or GitHub Enterprise API base URL
3. Read repository metadata.
4. Use the repository default branch.
5. Request a recursive Git tree.
6. If GitHub marks the response as truncated, walk every subtree explicitly.
7. Select candidate files using configured extensions.
8. Apply `GITHUB_SEARCH_ROOT` when set.
9. Download each candidate by Git blob SHA.
10. Parse as JSON first, then YAML.
11. Validate that the document is OpenAPI/Swagger.
12. Normalize metadata and operations.
13. Cache catalog and detail results.

## OpenAPI validation

A candidate must be an object containing:

- `openapi`, or `swagger: "2.0"`
- `info`
- `info.title`
- `paths`

Invalid and non-OpenAPI files are recorded in the discovery report with a reason.

## Normalized data model

The backend presents the frontend with a provider-neutral catalog model. Important fields include:

```text
id
name
version
description
owner
lifecycle
domain
tags
servers
securitySchemes
operationCount
operations
sourcePath
sourceUrl
sourceRef
sourceSha
```

The UI does not consume raw GitHub tree or blob response shapes.

## Caching

`CatalogService` uses process-local memory:

- Catalog cache
- Detail cache
- Cache timestamp
- Spec index

Default TTL:

```text
900 seconds
```

A forced refresh rebuilds the catalog and clears that process's detail cache.

### Production implication

Caches are not shared between:

- Gunicorn workers
- EKS pods
- Separate application instances

The current Dockerfile starts one Gunicorn worker with eight threads:

```text
--workers 1 --threads 8
```

Each EKS pod still has an independent catalog cache. Multiple replicas can serve authenticated users without sticky sessions because the signed session cookie is stateless, but repository refreshes and cache age can differ by pod. Implement a shared cache such as Redis if exact cross-pod cache consistency is required.

## Concurrency

OpenAPI candidate validation uses a bounded thread pool controlled by:

```env
GITHUB_SCAN_WORKERS=8
```

Allowed range:

```text
1 through 24
```

Higher values can reduce scan time but increase concurrent GitHub requests, CPU use, and memory use.

## Static serving

During development:

```text
Vite serves the frontend
Flask serves /api
```

In the Docker production image:

```text
Gunicorn runs Flask
Flask serves frontend/dist
Flask serves /api
```

Unknown frontend routes return `frontend/dist/index.html`, enabling React Router deep links.

## Network dependencies

The runtime needs outbound access to:

- GitHub.com API, or
- The configured GitHub Enterprise API endpoint

In EKS private networking, provide NAT, company routing, proxy configuration, or another approved egress path to both GitHub and Keycloak.

## Persistence

The application has no database and stores no durable catalog state. Restarting the process clears all caches. GitHub remains the source of truth.


## Application-level authentication runtime

`backend/auth.py` initializes Authlib from the Keycloak realm discovery document. It registers login, callback, logout, logged-out, and identity routes plus a Flask `before_request` guard.

The session is stateless across pods because the signed cookie contains only safe user metadata and the matched allowed group. All pods must share `SESSION_SECRET`. Keycloak tokens are discarded after callback processing.
