import { useMemo, useState } from 'react'
import type { ReactNode } from 'react'
import type { ApiItem, Operation, RequestField } from '../types'
import { formatDate, htmlToText } from '../lib/text'
import { apiDisplayName, operationAnchor, operationSearchText } from '../lib/catalog'

const METHOD_ORDER = ['GET','POST','PUT','PATCH','DELETE','HEAD','OPTIONS','TRACE']
interface FieldNode { field: RequestField; children: FieldNode[] }
function parentPath(path:string){const i=path.lastIndexOf('.');return i===-1?'':path.slice(0,i)}
function buildTree(fields:RequestField[]){const nodes=new Map<string,FieldNode>();const roots:FieldNode[]=[];fields.forEach((f,i)=>{const p=f.path||f.name||`field-${i}`;nodes.set(p,{field:{...f,path:p},children:[]})});nodes.forEach((n,p)=>{const parent=nodes.get(parentPath(p));if(parent){parent.children.push(n)}else{roots.push(n)}});return roots}

export function ApiExplorer({api}:{api:ApiItem}){
  const [search,setSearch]=useState('')
  const [tab,setTab]=useState<'reference'|'spec'>('reference')
  const [copyStatus,setCopyStatus]=useState('')
  const query=search.trim().toLowerCase()
  const operations=useMemo(()=>(api.operations||[]).filter(op=>!query||operationSearchText(op).includes(query)),[api.operations,query])
  const groups=useMemo(()=>METHOD_ORDER.map(method=>[method,operations.filter(op=>op.method.toUpperCase()===method)] as const).filter(([,ops])=>ops.length),[operations])
  async function copySpecification(){
    try{
      await navigator.clipboard.writeText(api.definitionText||'')
      setCopyStatus('Copied')
    }catch{
      setCopyStatus('Copy failed')
    }
    window.setTimeout(()=>setCopyStatus(''),1800)
  }
  return <div className="explorer-shell">
    <nav className="operation-nav">
      <section className="detail-api-summary" aria-label="API summary">
        <div className="detail-api-summary__title">
          <span className="detail-api-summary__eyebrow">API</span>
          <strong>{apiDisplayName(api)}</strong>
        </div>
        <div className="detail-api-summary__meta">
          <span>{api.operationCount ?? api.operations?.length ?? 0} operation{(api.operationCount ?? api.operations?.length ?? 0) === 1 ? '' : 's'}</span>
          {api.lifecycle && <span>{api.lifecycle}</span>}
          {api.version && <span>v{api.version}</span>}
        </div>
      </section>
      <label className="operation-search-label" htmlFor="api-operation-search">Search this API</label>
      <input id="api-operation-search" type="search" value={search} onChange={e=>setSearch(e.target.value)} placeholder="Endpoints, fields, or methods…" />
      <div className="explorer-tabs" role="tablist" aria-label="API detail views">
        <button type="button" role="tab" aria-selected={tab==='reference'} aria-controls="api-reference-panel" className={tab==='reference'?'nav-tab active':'nav-tab'} onClick={()=>setTab('reference')}>Overview & operations</button>
        <button type="button" role="tab" aria-selected={tab==='spec'} aria-controls="api-spec-panel" className={tab==='spec'?'nav-tab active':'nav-tab'} onClick={()=>setTab('spec')}>Raw specification</button>
      </div>
      {tab==='reference'&&<div className="operation-tree">{groups.map(([method,ops])=><details key={`${method}-${Boolean(query)}`} open={query ? true : undefined}>
        <summary><span className={`method method-${method.toLowerCase()}`}>{method}</span><strong>{method}</strong><span>{ops.length}</span></summary>
        {ops.map((op,index)=><a key={operationAnchor(op,index)} href={`#${operationAnchor(op,index)}`}>{op.summary||op.operationId||op.path}</a>)}
      </details>)}</div>}
    </nav>
    <article className="reference-pane">
      {tab==='spec'?<div id="api-spec-panel" role="tabpanel"><div className="reference-actions"><button type="button" className="secondary" onClick={()=>void copySpecification()}>{copyStatus||'Copy specification'}</button><span className="sr-only" role="status" aria-live="polite">{copyStatus}</span></div><pre className="spec"><code>{api.definitionText||'Specification unavailable.'}</code></pre></div>:<div id="api-reference-panel" role="tabpanel" aria-labelledby="api-reference-title">
        <div className="api-reference-sticky-shell">
          <header className="api-reference-sticky-header">
            <div className="eyebrow">{api.workspace.name}</div>
            <h1 id="api-reference-title">{apiDisplayName(api)}</h1>
          </header>
        </div>
        <section className="api-overview" aria-label="API overview">{api.description&&<p>{htmlToText(api.description)}</p>}
          {api.sourceUrl&&<a className="github-source-link" href={api.sourceUrl} target="_blank" rel="noreferrer">View source specification on GitHub <span aria-hidden="true">↗</span></a>}
          <div className="detail-summary"><div><strong>Version</strong><span>{api.version||'Unspecified'}</span></div><div><strong>Owner</strong><span>{api.owner||'Unspecified'}</span></div><div><strong>Operations</strong><span>{api.operationCount??operations.length}</span></div><div><strong>Updated</strong><span>{formatDate(api.updatedAt)}</span></div></div>
        </section>
        {!!api.servers?.length&&<section><h3>Servers</h3><div className="server-list">{api.servers.map(server=><code key={server}>{server}</code>)}</div></section>}
        <section><div className="section-title-row"><h3>Operations</h3><span>{operations.length} shown</span></div>{groups.map(([method,ops])=><details className="operation-group reference-group" key={`${method}-${Boolean(query)}`} open={query ? true : undefined}>
          <summary><span className={`method method-${method.toLowerCase()}`}>{method}</span><strong>{method} operations</strong><span className="operation-count">{ops.length}</span><span className="group-chevron">›</span></summary>
          <div className="operation-group-content">{ops.map((op,index)=><OperationCard key={operationAnchor(op,index)} op={op} id={operationAnchor(op,index)} expandAll={Boolean(query)}/>)}</div>
        </details>)}</section>
      </div>}
    </article>
  </div>
}

function FieldTable({fields,expandAll}:{fields:RequestField[];expandAll:boolean}){
  const tree=useMemo(()=>buildTree(fields),[fields]);const [expanded,setExpanded]=useState<Set<string>>(new Set())
  function toggle(path:string){setExpanded(current=>{const next=new Set(current);if(next.has(path)){next.delete(path)}else{next.add(path)}return next})}
  function rows(nodes:FieldNode[],depth=0):ReactNode[]{return nodes.flatMap(node=>{const path=node.field.path||node.field.name;const children=node.children.length>0;const open=expandAll||expanded.has(path);const row=<tr key={path} className={`${node.field.required?'required-field-row':''} ${children?'object-field-row':''}`}><td><div className="field-name-cell" style={{paddingLeft:depth*22}}>{children?<button type="button" className="field-expander" aria-expanded={open} aria-label={`${open?'Collapse':'Expand'} ${node.field.name||path}`} onClick={()=>toggle(path)}><span className="field-chevron" aria-hidden="true">›</span></button>:<span className="field-expander-spacer"/>}<div><div className="field-code-line"><code>{node.field.name||path.split('.').at(-1)}</code>{node.field.required&&<span className="required-asterisk" aria-label="Required field">*</span>}{children&&<span className="object-pill">{node.children.length} fields</span>}</div>{node.field.description&&<small>{htmlToText(node.field.description)}</small>}</div></div></td><td>{node.field.location||'body'}</td><td><code>{node.field.type||'unknown'}</code></td><td>{node.field.required?<span className="required-badge"><span aria-hidden="true">*</span> Required</span>:<span className="optional-badge">Optional</span>}</td></tr>;return children&&open?[row,...rows(node.children,depth+1)]:[row]})}
  return <div className="table-wrap"><table className="request-fields-table"><thead><tr><th>Field</th><th>In</th><th>Type</th><th>Importance</th></tr></thead><tbody>{rows(tree)}</tbody></table></div>
}
function OperationCard({op,id,expandAll}:{op:Operation;id:string;expandAll:boolean}){return <article className="operation" id={id}><div className="operation-title"><span className={`method method-${op.method.toLowerCase()}`}>{op.method}</span><code>{op.path}</code><a className="anchor-link" href={`#${id}`}>#</a></div><h4>{op.summary||op.operationId||'No summary'}</h4>{op.description&&<p>{htmlToText(op.description)}</p>}{!!op.requestFields?.length&&<FieldTable fields={op.requestFields} expandAll={expandAll}/>} {op.requestBodyExample?<div className="example"><strong>Example request body</strong><pre><code>{typeof op.requestBodyExample.example==='string'?op.requestBodyExample.example:JSON.stringify(op.requestBodyExample.example,null,2)}</code></pre></div>:!['GET','HEAD','OPTIONS','TRACE'].includes(op.method.toUpperCase())&&<p className="muted">No request body is defined for this operation.</p>}</article>}
