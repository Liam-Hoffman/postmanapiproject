import type { AuthState } from '../lib/api'

interface Props {
  summary: string
  apiSearch: string
  endpointSearch: string
  sort: string
  apiCount: number
  endpointCount: number
  loading: boolean
  darkMode: boolean
  sourceProvider?: string
  auth: AuthState
  onLogout(): void
  onApiSearch(value: string): void
  onEndpointSearch(value: string): void
  onSort(value: string): void
  onRefresh(): void
  onTheme(): void
}

function userInitials(name: string, username: string): string {
  const parts = (name || username).trim().split(/\s+/).filter(Boolean)
  if (!parts.length) return 'U'
  return `${parts[0][0] || ''}${parts.length > 1 ? parts.at(-1)?.[0] || '' : ''}`.toUpperCase()
}

export function Sidebar(props: Props) {
  return <aside className="catalog-sidebar dashboard-sidebar">
    <header className="brand-block dashboard-brand">
      <div className="dashboard-brand__identity">
        <div className="dashboard-brand__mark" aria-hidden="true">API</div>
        <div>
          <div className="eyebrow">Internal Developer Portal</div>
          <h1>API Catalog</h1>
        </div>
      </div>
      <p className="dashboard-brand__summary">{props.summary}</p>
      <div className="actions sidebar-actions dashboard-brand__actions">
        <button
          className="sidebar-action-button sidebar-action-button--primary"
          onClick={props.onRefresh}
          disabled={props.loading}
        >
          {props.loading ? 'Refreshing…' : 'Refresh catalog'}
        </button>
        <button
          className="sidebar-action-button sidebar-action-button--secondary"
          onClick={props.onTheme}
          aria-label={`Switch to ${props.darkMode ? 'light' : 'dark'} theme`}
          aria-pressed={props.darkMode}
        >
          {props.darkMode ? 'Light theme' : 'Dark theme'}
        </button>
      </div>
    </header>

    {props.auth.enabled && props.auth.user && <section className="dashboard-user-card" aria-label="Signed-in user">
      <div className="dashboard-user-card__avatar" aria-hidden="true">
        {userInitials(props.auth.user.name, props.auth.user.username)}
      </div>
      <div className="dashboard-user-card__identity">
        <span>Signed in via SSO</span>
        <strong>{props.auth.user.name || props.auth.user.username}</strong>
        <small>{props.auth.user.email || props.auth.user.username}</small>
      </div>
      <button type="button" className="dashboard-user-card__logout" onClick={props.onLogout}>
        Sign out
      </button>
    </section>}

    <section className="dashboard-stat-grid" aria-label="Catalog summary">
      <div className="dashboard-stat-card">
        <span>Visible APIs</span>
        <strong>{props.apiCount}</strong>
        <small>Matching current filters</small>
      </div>
      <div className="dashboard-stat-card">
        <span>Endpoints</span>
        <strong>{props.endpointCount}</strong>
        <small>Available in visible APIs</small>
      </div>
    </section>

    <section className="sidebar-panel dashboard-controls">
      <div className="dashboard-section-heading">
        <div>
          <span className="dashboard-section-heading__eyebrow">Discover</span>
          <strong>Search and organize</strong>
        </div>
      </div>

      <div className="catalog-search-group" role="group" aria-label="Catalog searches">
        <div className="catalog-search-control">
          <label htmlFor="catalog-api-search">Search APIs</label>
          <div className="catalog-search-input">
            <input
              id="catalog-api-search"
              value={props.apiSearch}
              onChange={event => props.onApiSearch(event.target.value)}
              type="search"
              placeholder="Name, owner, lifecycle, path…"
            />
            {props.apiSearch && <button type="button" onClick={() => props.onApiSearch('')} aria-label="Clear API search">Clear</button>}
          </div>
          <small>Filters API metadata without opening operations.</small>
        </div>

        <div className="catalog-search-control">
          <label htmlFor="catalog-endpoint-search">Search endpoints</label>
          <div className="catalog-search-input">
            <input
              id="catalog-endpoint-search"
              value={props.endpointSearch}
              onChange={event => props.onEndpointSearch(event.target.value)}
              type="search"
              placeholder="Method, route, summary, tag…"
            />
            {props.endpointSearch && <button type="button" onClick={() => props.onEndpointSearch('')} aria-label="Clear endpoint search">Clear</button>}
          </div>
          <small>Shows APIs containing matching endpoints.</small>
        </div>
      </div>

      <label className="dashboard-sort-control">
        <span>Sort APIs</span>
        <select value={props.sort} onChange={event => props.onSort(event.target.value)}>
          <option value="name">Name</option>
          <option value="updated">Recently updated</option>
          <option value="operations">Most endpoints</option>
        </select>
      </label>

      <div className="sidebar-help dashboard-scope-note">
        <strong>Catalog scope</strong>
        <span>{props.sourceProvider === 'mock'
          ? 'Local sample APIs exercise catalog search, endpoint previews, and detail pages without a repository connection.'
          : 'JSON and YAML files are scanned recursively and included only when their contents are valid OpenAPI documents.'}</span>
      </div>
    </section>
  </aside>
}
