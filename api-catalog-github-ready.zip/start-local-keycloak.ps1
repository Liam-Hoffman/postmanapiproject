$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw "Docker was not found. Install/start Docker Desktop and rerun this script."
}
& docker compose -f "deploy\local-sso\docker-compose.yml" up -d
if ($LASTEXITCODE -ne 0) { throw "Docker Compose failed to start local Keycloak." }
Write-Host "Local Keycloak is starting at http://localhost:8180" -ForegroundColor Green
Write-Host "Admin Console: http://localhost:8180/admin  (admin / admin)" -ForegroundColor Cyan
Write-Host "Realm issuer: http://localhost:8180/realms/api-catalog-local" -ForegroundColor Cyan
