@echo off
docker compose -f "%~dp0deploy\local-sso\docker-compose.yml" down
