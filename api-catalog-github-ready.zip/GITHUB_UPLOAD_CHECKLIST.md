# GitHub upload checklist

## Safe to upload

The repository is structured so source, documentation, example configuration,
Dockerfiles, CodeBuild definitions, and Kubernetes templates can be committed.

Before the first push:

1. Run `git status --ignored` and confirm `.env`, `.venv`, `node_modules`,
   `frontend/node_modules`, `frontend/dist`, TypeScript build info, Python caches,
   and generated Vite config files are ignored.
2. Run `bash scripts/ci-verify.sh` from Git Bash/WSL, or use the equivalent secret
   scan in the company pipeline.
3. Run `npm run lint` and `npm run build`.
4. Run `verify.ps1 -SkipFrontendBuild` on Windows.
5. Render both deployment stacks:

   ```text
   kubectl kustomize deploy/eks
   kubectl kustomize deploy/keycloak-eks
   ```

6. Review every placeholder listed below.
7. Commit from the repository root and push to the intended private GitHub
   organization/repository.

## Never upload

- `.env`
- GitHub access tokens
- Keycloak or Entra client secrets
- RDS credentials
- Session secrets
- Bootstrap administrator credentials
- Kubeconfig files
- AWS access keys
- Exported production Keycloak realms containing credentials

If any real credential was previously copied into a tracked file, rotate the
credential before pushing; deleting it from the latest commit is insufficient.

## Deployment placeholders

API Catalog:

- ECR account/region/image tag
- GitHub repository URL
- Catalog hostname
- Keycloak issuer/client/group
- ACM certificate ARN

Keycloak:

- ECR account/region/image tag
- RDS endpoint
- Keycloak hostname
- ACM certificate ARN

The CodeBuild buildspecs substitute immutable image URIs. Environment-specific
infrastructure values should be supplied through a production Kustomize overlay
or controlled pipeline rendering step.

## Secrets Manager names expected by examples

```text
api-catalog/application/production
api-catalog/keycloak/production
```

The examples expect synchronized Kubernetes Secrets named:

```text
api-catalog/api-catalog-secrets
keycloak/keycloak-secrets
```
