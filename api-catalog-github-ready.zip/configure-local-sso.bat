@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0configure-local-sso.ps1" %*
