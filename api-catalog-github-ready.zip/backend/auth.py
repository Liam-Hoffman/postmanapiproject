from __future__ import annotations

import json
import time
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlencode, urlparse

from authlib.integrations.base_client.errors import OAuthError
from authlib.integrations.flask_client import OAuth
from flask import (
    Flask,
    jsonify,
    redirect,
    render_template,
    request,
    session,
)
from werkzeug.middleware.proxy_fix import ProxyFix

import config


@dataclass(frozen=True)
class AuthUser:
    subject: str
    username: str
    name: str
    email: str
    authorized_groups: tuple[str, ...]

    def to_public_dict(self) -> dict[str, Any]:
        return {
            "subject": self.subject,
            "username": self.username,
            "name": self.name,
            "email": self.email,
            "authorizedGroups": list(self.authorized_groups),
        }


def _safe_next_url(value: str | None) -> str:
    candidate = (value or "/").strip()
    parsed = urlparse(candidate)
    if parsed.scheme or parsed.netloc or not candidate.startswith("/"):
        return "/"
    if candidate.startswith("//") or "\\" in candidate:
        return "/"
    return candidate


def _claim_value(claims: dict[str, Any], dotted_name: str) -> Any:
    current: Any = claims
    for part in dotted_name.split("."):
        if not isinstance(current, dict) or part not in current:
            return None
        current = current[part]
    return current


def _claim_strings(value: Any) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, (list, tuple, set)):
        return tuple(str(item).strip() for item in value if str(item).strip())
    if isinstance(value, str):
        stripped = value.strip()
        if not stripped:
            return ()
        if stripped.startswith("["):
            try:
                parsed = json.loads(stripped)
            except json.JSONDecodeError:
                parsed = None
            if isinstance(parsed, list):
                return tuple(
                    str(item).strip()
                    for item in parsed
                    if str(item).strip()
                )
        return (stripped,)
    return (str(value).strip(),)


def _session_user() -> AuthUser | None:
    payload = session.get("auth_user")
    expires_at = int(session.get("auth_expires_at") or 0)
    if not isinstance(payload, dict) or expires_at <= int(time.time()):
        session.clear()
        return None
    subject = str(payload.get("subject") or "").strip()
    if not subject:
        session.clear()
        return None
    return AuthUser(
        subject=subject,
        username=str(payload.get("username") or "").strip(),
        name=str(payload.get("name") or "").strip(),
        email=str(payload.get("email") or "").strip(),
        authorized_groups=tuple(payload.get("authorizedGroups") or ()),
    )


class KeycloakAuth:
    def __init__(self, app: Flask):
        self.app = app
        self.oauth: OAuth | None = None
        self.client = None

        if config.TRUST_PROXY_HEADERS:
            app.wsgi_app = ProxyFix(
                app.wsgi_app,
                x_for=1,
                x_proto=1,
                x_host=1,
                x_port=1,
                x_prefix=1,
            )

        app.config.update(
            SECRET_KEY=config.SESSION_SECRET or "local-auth-disabled",
            SESSION_COOKIE_NAME=config.SESSION_COOKIE_NAME,
            SESSION_COOKIE_HTTPONLY=True,
            SESSION_COOKIE_SECURE=config.SESSION_COOKIE_SECURE,
            SESSION_COOKIE_SAMESITE="Lax",
            PERMANENT_SESSION_LIFETIME=config.SESSION_LIFETIME_SECONDS,
            PREFERRED_URL_SCHEME=(
                "https"
                if config.PUBLIC_BASE_URL.startswith("https://")
                else "http"
            ),
        )

        config.validate_auth_configuration()
        if config.AUTH_ENABLED:
            self.oauth = OAuth(app)
            self.client = self.oauth.register(
                name="keycloak",
                client_id=config.KEYCLOAK_CLIENT_ID,
                client_secret=config.KEYCLOAK_CLIENT_SECRET,
                server_metadata_url=(
                    f"{config.KEYCLOAK_ISSUER_URL}/.well-known/"
                    "openid-configuration"
                ),
                client_kwargs={"scope": config.KEYCLOAK_SCOPES},
            )

        self._register_routes()
        self._register_request_guards()

    @property
    def callback_url(self) -> str:
        return f"{config.PUBLIC_BASE_URL}/auth/callback"

    @property
    def logged_out_url(self) -> str:
        return f"{config.PUBLIC_BASE_URL}/auth/logged-out"

    def current_user(self) -> AuthUser | None:
        if not config.AUTH_ENABLED:
            return None
        return _session_user()

    def _register_routes(self) -> None:
        app = self.app

        @app.get("/auth/login")
        def auth_login():
            destination = _safe_next_url(request.args.get("next"))
            if not config.AUTH_ENABLED:
                return redirect(destination)
            if _session_user() is not None:
                return redirect(destination)
            if self.client is None:
                return render_template(
                    "auth_error.html",
                    title="Authentication unavailable",
                    message="The Keycloak OIDC client is not initialized.",
                ), 503

            session["auth_next"] = destination
            authorize_kwargs: dict[str, str] = {}
            if config.KEYCLOAK_PROMPT:
                authorize_kwargs["prompt"] = config.KEYCLOAK_PROMPT
            if config.KEYCLOAK_IDP_HINT:
                # Keycloak forwards directly to the configured upstream identity
                # provider (for this app: Microsoft Entra) instead of displaying
                # its own login selector.
                authorize_kwargs["kc_idp_hint"] = config.KEYCLOAK_IDP_HINT
            return self.client.authorize_redirect(
                self.callback_url,
                **authorize_kwargs,
            )

        @app.get("/auth/callback")
        def auth_callback():
            if not config.AUTH_ENABLED or self.client is None:
                return redirect("/")
            try:
                token = self.client.authorize_access_token()
                claims = dict(token.get("userinfo") or {})
                userinfo = self.client.userinfo(token=token)
                claims.update(dict(userinfo or {}))
            except OAuthError as exc:
                app.logger.warning("Keycloak callback failed: %s", exc.error)
                session.clear()
                return render_template(
                    "auth_error.html",
                    title="Sign-in failed",
                    message=(
                        "Keycloak could not complete the OpenID Connect sign-in. "
                        "Please try again or contact the application support team."
                    ),
                ), 401
            except Exception:
                app.logger.exception("Unexpected Keycloak callback failure")
                session.clear()
                return render_template(
                    "auth_error.html",
                    title="Sign-in failed",
                    message=(
                        "The authentication response could not be processed. "
                        "Please try again or contact the application support team."
                    ),
                ), 401

            subject = str(claims.get("sub") or "").strip()
            if not subject:
                session.clear()
                return render_template(
                    "auth_error.html",
                    title="Invalid identity response",
                    message="The Keycloak response did not include a subject claim.",
                ), 401

            user_groups = _claim_strings(
                _claim_value(claims, config.KEYCLOAK_GROUP_CLAIM)
            )
            matched_groups = tuple(
                group
                for group in config.KEYCLOAK_REQUIRED_GROUPS
                if group in user_groups
            )
            if not matched_groups:
                app.logger.warning(
                    "Keycloak access denied for subject=%s: required group missing",
                    subject,
                )
                session.clear()
                return render_template(
                    "access_denied.html",
                    required_groups=config.KEYCLOAK_REQUIRED_GROUPS,
                    logout_url="/auth/logout",
                ), 403

            username = str(
                claims.get("preferred_username")
                or claims.get("username")
                or claims.get("email")
                or subject
            ).strip()
            name = str(claims.get("name") or username).strip()
            email = str(claims.get("email") or "").strip()
            expires_at = int(time.time()) + config.SESSION_LIFETIME_SECONDS

            user = AuthUser(
                subject=subject,
                username=username,
                name=name,
                email=email,
                authorized_groups=matched_groups,
            )
            destination = _safe_next_url(session.get("auth_next", "/"))
            session.clear()
            session.permanent = True
            session["auth_user"] = user.to_public_dict()
            session["auth_expires_at"] = expires_at
            return redirect(destination)

        @app.route("/auth/logout", methods=["GET", "POST"])
        def auth_logout():
            session.clear()
            if not config.AUTH_ENABLED:
                return redirect("/")
            params = urlencode(
                {
                    "client_id": config.KEYCLOAK_CLIENT_ID,
                    "post_logout_redirect_uri": self.logged_out_url,
                }
            )
            return redirect(
                f"{config.KEYCLOAK_ISSUER_URL}/protocol/openid-connect/"
                f"logout?{params}"
            )

        @app.get("/auth/logged-out")
        def auth_logged_out():
            session.clear()
            return render_template("logged_out.html", login_url="/auth/login")

        @app.get("/api/auth/me")
        def auth_me():
            if not config.AUTH_ENABLED:
                return jsonify(
                    {
                        "enabled": False,
                        "authenticated": True,
                        "user": None,
                        "requiredGroups": [],
                    }
                )
            user = _session_user()
            if user is None:
                return jsonify(
                    {
                        "enabled": True,
                        "authenticated": False,
                        "user": None,
                        "loginUrl": "/auth/login",
                    }
                ), 401
            return jsonify(
                {
                    "enabled": True,
                    "authenticated": True,
                    "user": user.to_public_dict(),
                    "requiredGroups": list(config.KEYCLOAK_REQUIRED_GROUPS),
                }
            )

    def _register_request_guards(self) -> None:
        app = self.app

        @app.before_request
        def require_keycloak_session():
            if not config.AUTH_ENABLED:
                return None
            if request.path == "/api/health" or request.path.startswith("/auth/"):
                return None
            if _session_user() is not None:
                return None
            if request.path.startswith("/api/"):
                return jsonify(
                    {
                        "error": "Authentication required",
                        "details": "Sign in through Keycloak to access the API catalog.",
                        "loginUrl": "/auth/login",
                    }
                ), 401
            next_path = _safe_next_url(request.full_path.rstrip("?"))
            return redirect(f"/auth/login?{urlencode({'next': next_path})}")

        @app.after_request
        def add_security_headers(response):
            response.headers.setdefault("X-Content-Type-Options", "nosniff")
            response.headers.setdefault("X-Frame-Options", "DENY")
            response.headers.setdefault("Referrer-Policy", "same-origin")
            if config.AUTH_ENABLED and (
                request.path.startswith("/api/")
                or (response.content_type or "").startswith("text/html")
            ):
                response.headers["Cache-Control"] = "no-store, private"
                response.headers["Pragma"] = "no-cache"
            return response
