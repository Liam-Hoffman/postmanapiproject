from __future__ import annotations

import argparse
import sys
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent.parent
load_dotenv(PROJECT_ROOT / ".env", override=False)

import config
from github_client import GitHubMonorepoClient, parse_repository_url


def verify_dependencies() -> None:
    import flask
    import dotenv
    import yaml
    import authlib
    import requests

    del flask, dotenv, yaml, authlib, requests
    print("Backend dependencies verified")


def verify_auth_configuration() -> None:
    config.validate_auth_configuration()
    print(
        "Authentication configuration verified: "
        f"mode={config.AUTH_MODE}"
        + (
            f", issuer={config.KEYCLOAK_ISSUER_URL}, "
            f"groups={','.join(config.KEYCLOAK_REQUIRED_GROUPS)}"
            if config.AUTH_ENABLED
            else ""
        )
    )


def verify_repository_url() -> None:
    location = parse_repository_url(config.GITHUB_REPOSITORY_URL)
    print(location.repository_url)


def verify_imports() -> None:
    import app
    import catalog
    import github_client
    import auth

    del app, catalog, github_client, auth
    print("Backend application imports verified")


def discovery_report() -> None:
    import json

    client = GitHubMonorepoClient(
        config.GITHUB_REPOSITORY_URL,
        config.GITHUB_ACCESS_TOKEN,
    )
    _, _, discovered = client.discover_openapi_specs(force=True)
    report = client.get_discovery_report()
    report["normalizedDiscoveredCount"] = len(discovered)
    print(json.dumps(report, indent=2))


def verify_github_access() -> None:
    client = GitHubMonorepoClient(
        config.GITHUB_REPOSITORY_URL,
        config.GITHUB_ACCESS_TOKEN,
    )
    health = client.health()
    print(
        "GitHub access verified: "
        f"{health['repository']} @ {health['ref']} "
        f"(authenticated={health['authenticated']})"
    )


COMMANDS = {
    "auth-config": verify_auth_configuration,
    "dependencies": verify_dependencies,
    "repository-url": verify_repository_url,
    "imports": verify_imports,
    "github-access": verify_github_access,
    "discovery": discovery_report,
}


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Verify GitHub Monorepo API Catalog installation."
    )
    parser.add_argument("check", choices=sorted(COMMANDS))
    args = parser.parse_args()

    try:
        COMMANDS[args.check]()
    except Exception as exc:
        print(f"Verification failed: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
