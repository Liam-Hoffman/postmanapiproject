[CmdletBinding()]
param(
    [switch]$Microsoft,
    [string]$SessionSecret
)

$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

if (-not (Test-Path ".env")) {
    Copy-Item ".env.example" ".env"
}

function Set-EnvValue([string]$Name, [string]$Value) {
    $envText = Get-Content ".env" -Raw
    $pattern = "(?m)^" + [regex]::Escape($Name) + "=.*$"
    $line = "$Name=$Value"
    if ($envText -match $pattern) {
        $envText = [regex]::Replace($envText, $pattern, [System.Text.RegularExpressions.MatchEvaluator]{ param($match) $line })
    } else {
        $envText = $envText.TrimEnd() + "`r`n$line`r`n"
    }
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [System.IO.File]::WriteAllText((Join-Path $ProjectRoot ".env"), $envText, $utf8NoBom)
}

if (-not $SessionSecret) {
    $bytes = New-Object byte[] 32
    [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($bytes)
    $SessionSecret = ($bytes | ForEach-Object { $_.ToString("x2") }) -join ""
}

Set-EnvValue "AUTH_MODE" "keycloak"
Set-EnvValue "CATALOG_SOURCE" "mock"
Set-EnvValue "PUBLIC_BASE_URL" "http://127.0.0.1:5173"
Set-EnvValue "SESSION_SECRET" $SessionSecret
Set-EnvValue "SESSION_COOKIE_SECURE" "false"
Set-EnvValue "TRUST_PROXY_HEADERS" "false"
Set-EnvValue "KEYCLOAK_ISSUER_URL" "http://localhost:8180/realms/api-catalog-local"
Set-EnvValue "KEYCLOAK_CLIENT_ID" "api-catalog-local"
Set-EnvValue "KEYCLOAK_CLIENT_SECRET" "local-api-catalog-client-secret"
Set-EnvValue "KEYCLOAK_GROUP_CLAIM" "groups"
Set-EnvValue "KEYCLOAK_REQUIRED_GROUPS" "/api-catalog-users"
Set-EnvValue "KEYCLOAK_SCOPES" "openid profile email"
Set-EnvValue "KEYCLOAK_PROMPT" ""
Set-EnvValue "KEYCLOAK_IDP_HINT" $(if ($Microsoft) { "entra" } else { "" })

Write-Host "Local Keycloak authentication enabled in .env." -ForegroundColor Green
if ($Microsoft) {
    Write-Host "Microsoft Entra broker redirect enabled (KEYCLOAK_IDP_HINT=entra)." -ForegroundColor Green
    Write-Host "Configure the Entra OIDC Identity Provider in local Keycloak before signing in." -ForegroundColor Yellow
} else {
    Write-Host "Local-only login mode enabled. Use allowed-user / CatalogTest123! for the allow test." -ForegroundColor Cyan
    Write-Host "Use denied-user / CatalogTest123! for the deny test." -ForegroundColor Cyan
}
Write-Host "Mock catalog data enabled (CATALOG_SOURCE=mock); no GitHub credentials are required." -ForegroundColor Green
Write-Host "Run start-dev.bat, then open http://127.0.0.1:5173" -ForegroundColor Cyan
