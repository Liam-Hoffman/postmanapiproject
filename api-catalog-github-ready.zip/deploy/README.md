# Deployment Assets

- [`eks/`](eks/) contains the Kubernetes manifests and EKS deployment guide.
- [`keycloak/`](keycloak/) contains the confidential-client template and Keycloak group-mapper guide.
- [`keycloak-eks/`](keycloak-eks/) deploys Keycloak as a separate workload in the same EKS cluster, backed by RDS PostgreSQL.
- [`codepipeline/`](codepipeline/) documents GitHub, CodeBuild, ECR, and EKS pipeline configuration.

The application performs OIDC authentication and Keycloak group authorization inside Flask. The EKS Ingress/ALB terminates TLS and forwards traffic only; it does not perform authentication.

Deploy Keycloak and configure its Microsoft Entra broker before deploying the API Catalog.
