# EKS Deployment

This deployment uses application-level Keycloak authentication. Keycloak brokers corporate authentication to Microsoft Entra and maps the approved AD/Entra group to `/api-catalog-users`. The AWS load balancer terminates TLS and forwards traffic; it does **not** perform OIDC authentication.

## Prerequisites

- EKS cluster
- AWS Load Balancer Controller
- Internal DNS name and ACM certificate
- ECR image
- Network routes from pods to GitHub and Keycloak
- Keycloak realm/client, Microsoft Entra Identity Provider, and Entra-group mapper
- Kubernetes Secret or external-secret integration

## 1. Replace deployment values

Edit:

```text
deploy/eks/configmap.yaml
deploy/eks/deployment.yaml
deploy/eks/ingress-alb.yaml
```

Replace:

- GitHub repository URL
- Public application hostname
- Keycloak issuer/client/group
- ECR image URI and immutable tag
- ACM certificate ARN

## 2. Create secrets

Preferred: create the secret from AWS Secrets Manager using the company-standard External Secrets or Secrets Store CSI Driver integration.

Simple manual example:

```bash
kubectl create namespace api-catalog

kubectl -n api-catalog create secret generic api-catalog-secrets \\
  --from-literal=GITHUB_ACCESS_TOKEN='github_pat_...' \\
  --from-literal=KEYCLOAK_CLIENT_SECRET='...' \\
  --from-literal=SESSION_SECRET="$(openssl rand -hex 32)"
```

Every replica must receive the same `SESSION_SECRET`; otherwise login cookies will fail when requests move between pods.

## 3. Apply manifests

```bash
kubectl apply -k deploy/eks
```

The example secret is intentionally excluded from `kustomization.yaml`.

## 4. Validate

```bash
kubectl -n api-catalog rollout status deployment/api-catalog
kubectl -n api-catalog get pods,service,ingress
kubectl -n api-catalog logs deployment/api-catalog
```

Open:

```text
https://api-catalog.internal.company.com
```

Expected flow:

1. Flask redirects the browser to Keycloak with `kc_idp_hint=entra`.
2. Keycloak redirects the employee to Microsoft Entra.
3. Entra performs corporate SSO/MFA and returns the employee identity plus configured group claims to Keycloak.
4. Keycloak maps the approved Entra group Object ID to `/api-catalog-users`.
5. Keycloak redirects to the application's `/auth/callback`.
6. Flask validates the OIDC response through Authlib and requires `/api-catalog-users`.
7. Flask creates a signed, HTTP-only application session.
8. React loads the protected catalog and displays the signed-in user.

## Health probes

`/api/health` is intentionally unauthenticated for Kubernetes and ALB health checks. All catalog, source-health, discovery, specification, frontend, and identity-detail routes require an authenticated application session when `AUTH_MODE=keycloak`.

## Scaling behavior

The auth session is a signed cookie containing only safe user details and the matched access group. Keycloak tokens are not stored in the cookie. Replicas require the same `SESSION_SECRET` but do not require sticky sessions or Redis.

Catalog data caches remain process-local. Different pods can refresh independently. A shared cache can be added later if exact cross-pod cache consistency is required.

## Kubernetes references

- [Kubernetes Secrets](https://kubernetes.io/docs/concepts/configuration/secret/)
- [Inject environment variables into containers](https://kubernetes.io/docs/tasks/inject-data-application/define-environment-variable-container/)
- [Kubernetes Ingress](https://kubernetes.io/docs/concepts/services-networking/ingress/)


## Identity-provider setup

Configure the Microsoft Entra broker and group mapping before deploying the application. See [`../keycloak/entra-broker.md`](../keycloak/entra-broker.md).
