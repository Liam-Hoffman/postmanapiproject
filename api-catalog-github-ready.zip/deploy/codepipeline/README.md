# CodePipeline and CodeBuild setup

The repository contains two independent build specifications:

- `buildspec.yml`: test, build, and push the API Catalog image
- `buildspec-keycloak.yml`: build and push the optimized Keycloak image

Use separate CodeBuild projects and preferably separate pipelines. Keycloak
changes should not be redeployed for ordinary API Catalog UI changes.

## Source

Connect GitHub through AWS CodeConnections. Do not create a GitHub personal
access token for the source stage. Limit the GitHub App installation to this
repository.

## CodeBuild projects

Use an AWS managed Linux image with Docker, Bash, Node.js 22, Python 3.13, AWS
CLI, and `kubectl`. Enable privileged mode because both builds invoke Docker.

Provide these non-secret environment variables for the catalog build:

```text
AWS_ACCOUNT_ID=<AWS account ID>
ECR_REPOSITORY=api-catalog
```

For the Keycloak build project, use:

```text
AWS_ACCOUNT_ID=<AWS account ID>
ECR_REPOSITORY=api-catalog-keycloak
```

`AWS_DEFAULT_REGION` is supplied by CodeBuild. The build specifications tag
images with the first 12 characters of `CODEBUILD_RESOLVED_SOURCE_VERSION` and
export the immutable image URI.

The CodeBuild role requires CloudWatch Logs and pipeline-artifact permissions,
plus these actions scoped to the two ECR repositories where possible:

```text
ecr:GetAuthorizationToken
ecr:BatchCheckLayerAvailability
ecr:GetDownloadUrlForLayer
ecr:BatchGetImage
ecr:InitiateLayerUpload
ecr:UploadLayerPart
ecr:CompleteLayerUpload
ecr:PutImage
```

Runtime application, RDS, Entra, and Keycloak secrets are not needed by either
build and must not be added to CodeBuild.

## Deploy actions

Each build outputs a pipeline artifact containing a rendered manifest bundle,
the Kustomize source with the immutable image substituted, and
`imageDetail.json`.

Use CodePipeline V2 Amazon EKS deploy actions, or a dedicated least-privilege
deployment CodeBuild project, to apply the corresponding artifact. Give the
deployment role an EKS access entry and namespace-scoped Kubernetes privileges.

Recommended ordering:

```text
Keycloak: GitHub -> build/push -> approval -> deploy keycloak -> readiness test
Catalog:  GitHub -> test/build/push -> approval -> deploy catalog -> smoke test
```

If the EKS API endpoint is private, place the deployment action/build compute in
the VPC and permit it to reach the cluster endpoint and the pipeline artifact
bucket.

## Required AWS resources

- ECR repositories `api-catalog` and `api-catalog-keycloak`
- CodeConnections GitHub connection
- Two CodeBuild projects with privileged Docker builds
- CodePipeline V2 pipeline(s)
- EKS access entry for the deployment role
- Pipeline artifact bucket and KMS key according to company policy
- External Secrets Operator/SecretStore or another approved secret synchronizer
- RDS PostgreSQL for Keycloak
- Internal ALB, Route 53 records, and ACM certificate(s)

Never replace manifest placeholders with production secret values. Only
non-secret hostnames, ARNs, repository URLs, RDS endpoint, and image locations
belong in rendered deployment configuration.
