# Keycloak on the API Catalog EKS cluster

This directory deploys Keycloak as an independent workload in the same EKS
cluster as the API Catalog. It intentionally does not deploy PostgreSQL. Use an
encrypted private Amazon RDS or Aurora PostgreSQL database so identity state,
realm configuration, and sessions survive pod and node replacement.

## Architecture

- Namespace: `keycloak`
- Workload: two Keycloak replicas
- Runtime image: produced from `Dockerfile.keycloak`
- Database: private RDS/Aurora PostgreSQL
- Public endpoint: internal ALB at `keycloak.internal.company.com`
- Health/metrics: container management port `9000`, not exposed by the Service
- Secrets: Kubernetes Secret `keycloak-secrets`, preferably synchronized from
  AWS Secrets Manager

## Required substitutions

Before deployment, replace:

- `REPLACE_WITH_RDS_ENDPOINT` in `configmap.yaml`
- `keycloak.internal.company.com` in `configmap.yaml` and `ingress-alb.yaml`
- The ACM certificate ARN in `ingress-alb.yaml`
- The example ECR account/region/image in `deployment.yaml` (CodeBuild replaces
  the image automatically in its output artifact)

The RDS database must contain a database named `keycloak`. Its security group
should accept PostgreSQL port `5432` only from the Keycloak workload/node or pod
security group.

## Secrets Manager value

Create `api-catalog/keycloak/production` as JSON:

```json
{
  "KC_DB_USERNAME": "keycloak",
  "KCRAW_DB_PASSWORD": "generated-rds-password",
  "KC_BOOTSTRAP_ADMIN_USERNAME": "generated-bootstrap-name",
  "KC_BOOTSTRAP_ADMIN_PASSWORD": "generated-bootstrap-password"
}
```

Apply `external-secret.example.yaml` after replacing the secret name/store if
External Secrets Operator is available. Otherwise create `keycloak-secrets`
through an approved deployment process. Never add real values to this folder.

After the first login, create named administrator accounts, require MFA, store
break-glass access in the company secret system, and rotate the bootstrap
password.

## Deployment order

1. Provision RDS and its security groups.
2. Create the AWS Secrets Manager value and `keycloak-secrets` synchronization.
3. Replace hostname, certificate, and database endpoint placeholders.
4. Build/push the Keycloak image using `buildspec-keycloak.yml`.
5. Deploy the rendered Keycloak artifact.
6. Wait for both pods and the ALB target group to become healthy.
7. Configure the `api-catalog` realm, Entra broker, group mapper, and catalog
   confidential client using `../keycloak/entra-broker.md`.
8. Put the generated catalog client secret in the API Catalog application
   Secrets Manager value.
9. Deploy the API Catalog.

Render locally without contacting a cluster:

```bash
kubectl kustomize deploy/keycloak-eks
```

The example manifests use `sslmode=require`. If company policy requires server
certificate verification, mount the current AWS RDS CA bundle into Keycloak,
add it to the Keycloak truststore, and use `sslmode=verify-full`.
