# Local SSO Testing

This folder provides a disposable Keycloak 26.7.1 environment for testing the API Catalog authentication flow on Windows, macOS, or Linux.

Two test modes are supported:

1. **Local-only Keycloak** — verifies the Flask OIDC flow and group allow/deny behavior without Microsoft.
2. **Real Microsoft Entra SSO through local Keycloak** — verifies the complete production-style path: API Catalog → Keycloak → Microsoft Entra → AD/Entra group mapping → API Catalog.

## Start local Keycloak

From the project root on Windows:

```bat
start-local-keycloak.bat
```

Or directly:

```bash
docker compose -f deploy/local-sso/docker-compose.yml up -d
```

Keycloak:

```text
http://localhost:8180
```

Admin Console:

```text
http://localhost:8180/admin
username: admin
password: admin
```

The imported realm is `api-catalog-local` and already contains:

- Confidential client `api-catalog-local`
- Client secret `local-api-catalog-client-secret`
- Callback `http://127.0.0.1:5173/auth/callback`
- Group `/api-catalog-users`
- Group Membership protocol mapper emitting `groups`
- `allowed-user` in `/api-catalog-users`
- `denied-user` with no access group

Both local users use password:

```text
CatalogTest123!
```

## Test the application without Microsoft first

Run:

```bat
configure-local-sso.bat
setup.bat -Mock
start-dev.bat
```

`configure-local-sso.bat` also sets `CATALOG_SOURCE=mock`, so the catalog
renders Payments, Customer Profile, and Inventory examples without GitHub
credentials. After SSO works, set it back to `github` to test the monorepo.

On an existing installation, you can skip `setup.bat -Mock` when `.venv` and
`frontend/node_modules` are already present.

Open:

```text
http://127.0.0.1:5173
```

Expected:

- `allowed-user` → catalog opens
- `denied-user` → HTTP 403 access denied

This proves Flask → Keycloak and Keycloak-group enforcement before adding Entra.

## Test real Microsoft Entra SSO

You need permission to create/configure an Entra App Registration, or assistance from whoever owns that permission.

### A. Create the Entra application

Create a single-tenant Web application registration for the local Keycloak broker. Use the **Redirect URI shown by the Entra OIDC Identity Provider page in Keycloak**. For this local environment it should resolve to the broker endpoint under:

```text
http://localhost:8180/realms/api-catalog-local/broker/entra/endpoint
```

Copy the actual Keycloak-generated Redirect URI rather than typing it from memory.

Create a client secret and record:

```text
Tenant ID
Application (client) ID
Client secret VALUE
```

### B. Configure Entra group claims

In the Entra application, configure the token to emit a `groups` claim. Prefer the Entra **Groups assigned to the application** option when your tenant process supports it, so unrelated corporate memberships are not emitted.

Use the immutable Object ID for the access group, for example:

```text
API-Catalog-Users
Object ID: 11111111-2222-3333-4444-555555555555
```

### C. Add Microsoft Entra as a generic OIDC Identity Provider

Keycloak Admin Console:

```text
Realm: api-catalog-local
Identity Providers
Add provider
OpenID Connect v1.0
```

Use alias:

```text
entra
```

Use the tenant-specific Entra discovery document:

```text
https://login.microsoftonline.com/<TENANT-ID>/v2.0/.well-known/openid-configuration
```

Import/provider-discovery fills the authorization, token, issuer, UserInfo, and JWKS settings. Configure the Entra application client ID and client secret and request `openid profile email`. Set Sync Mode to `Force` so identity-provider mappers are reevaluated on subsequent broker logins.

Using the generic OIDC provider is intentional: the authorization data we need is the Entra OIDC `groups` claim, which the Advanced Claim to Group mapper can evaluate directly.

### D. Map the Entra group into Keycloak

Create/confirm realm group:

```text
/api-catalog-users
```

On the `entra` Identity Provider add a mapper:

```text
Mapper type: Advanced Claim to Group
Sync Mode Override: Force
Claim: groups
Expected value: <API-Catalog-Users Entra Object ID>
Regex Claim Values: Off
Group: /api-catalog-users
```

The incoming Entra `groups` array therefore becomes a simple Keycloak membership that the application understands.

### E. Enable Microsoft auto-redirect in the app

Run:

```bat
configure-local-sso.bat -Microsoft
```

This sets:

```env
KEYCLOAK_IDP_HINT=entra
```

The Flask login request sends Keycloak `kc_idp_hint=entra`, so the user is redirected to Microsoft's sign-in page rather than seeing the Keycloak login selector.

Then:

```bat
start-dev.bat
```

Open:

```text
http://127.0.0.1:5173
```

Expected flow:

```text
API Catalog
  → local Keycloak
  → Microsoft Entra sign-in
  → local Keycloak group mapper
  → Flask group check
  → catalog or 403
```

## Group-removal test

1. Sign in successfully while assigned to `API-Catalog-Users`.
2. Sign out of the catalog.
3. Remove the test account from the Entra/AD group (allow time for directory synchronization/claim updates as applicable).
4. Sign in again.
5. Keycloak should no longer map `/api-catalog-users`, and Flask should return 403.

The existing Flask session is intentionally not revalidated on every request. A previously authorized session remains valid until logout or application-session expiry.

## Reset local Keycloak

Stop but keep data:

```bat
stop-local-keycloak.bat
```

Delete all local Keycloak data and re-import the realm:

```bash
docker compose -f deploy/local-sso/docker-compose.yml down -v
docker compose -f deploy/local-sso/docker-compose.yml up -d
```
