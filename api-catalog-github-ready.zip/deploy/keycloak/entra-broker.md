# Microsoft Entra → Keycloak → API Catalog

## Target login experience

Employees see Microsoft corporate sign-in, not a separate Keycloak username/password page:

```text
API Catalog
  → Keycloak (broker)
  → Microsoft Entra
  → AD/Entra group claim
  → Keycloak group mapper
  → API Catalog allow/deny
```

The application itself communicates only with Keycloak. Microsoft Entra remains the authentication authority and the AD/Entra group remains the access source of truth.

## 1. Create the Keycloak realm

Create:

```text
Realm: api-catalog
```

Do not configure application users in the `master` realm.

## 2. Create the application client in Keycloak

Create a confidential OIDC client:

```text
Client ID: api-catalog-web
Client authentication: On
Standard flow: On
Implicit flow: Off
Direct access grants: Off
Service accounts roles: Off
```

Production callbacks:

```text
https://api-catalog.internal.company.com/auth/callback
https://api-catalog.internal.company.com/auth/logged-out
```

Add a Group Membership protocol mapper:

```text
Token claim name: groups
Full group path: On
Add to ID token: On
Add to access token: On
Add to UserInfo: On
```

## 3. Add Microsoft Entra as an Identity Provider

In the `api-catalog` realm:

```text
Identity Providers → Add provider → OpenID Connect v1.0
Alias: entra
```

Copy the Redirect URI displayed by Keycloak. That URI is the callback for the **Entra App Registration**, not the Flask callback.

Create/configure a single-tenant Entra Web App Registration and paste the Keycloak broker Redirect URI into its Web redirect URIs. Create a client secret.

Configure the Keycloak OIDC provider from the tenant-specific Entra discovery document:

```text
https://login.microsoftonline.com/<TENANT-ID>/v2.0/.well-known/openid-configuration
```

Enter the Entra client ID and client-secret value and request `openid profile email`. The generic OIDC provider is used so Entra OIDC claims, including the configured `groups` claim, are available to Keycloak Identity Provider mappers.

Recommended Keycloak provider behavior:

```text
Enabled: On
Sync Mode: Force
Store Tokens: Off unless a defined use case requires them
```

`Force` causes identity-provider mappers to update user data on each broker login.

## 4. Configure the AD/Entra access group

Use a security group such as:

```text
API-Catalog-Users
```

Record its immutable Microsoft Entra Object ID.

Configure the Entra application to emit group membership in a `groups` claim. Prefer limiting emitted groups to those relevant to the application where possible; Microsoft documents JWT group-claim limits, so sending every corporate group is undesirable for large memberships.

## 5. Map the Entra group to a Keycloak group

Create the realm group:

```text
/api-catalog-users
```

On the `entra` Identity Provider:

```text
Mappers → Add mapper
Mapper type: Advanced Claim to Group
Sync Mode Override: Force
Claim: groups
Expected value: <Entra Object ID of API-Catalog-Users>
Regex Claim Values: Off
Group: /api-catalog-users
```

The application never needs the Entra group GUID. Keycloak converts it into the stable application-facing group `/api-catalog-users`.

## 6. Automatically send users to Microsoft

The application build supports:

```env
KEYCLOAK_IDP_HINT=entra
```

During `/auth/login`, Flask sends `kc_idp_hint=entra` to Keycloak. Keycloak then delegates authentication to the Identity Provider with alias `entra` without stopping on its normal login selector.

The same behavior can alternatively be configured as Keycloak's default Identity Provider through the Browser authentication flow.

## 7. EKS application configuration

```env
AUTH_MODE=keycloak
PUBLIC_BASE_URL=https://api-catalog.internal.company.com
SESSION_COOKIE_SECURE=true
TRUST_PROXY_HEADERS=true
KEYCLOAK_ISSUER_URL=https://keycloak.company.com/realms/api-catalog
KEYCLOAK_CLIENT_ID=api-catalog-web
KEYCLOAK_GROUP_CLAIM=groups
KEYCLOAK_REQUIRED_GROUPS=/api-catalog-users
KEYCLOAK_SCOPES=openid profile email
KEYCLOAK_IDP_HINT=entra
```

Secrets:

```text
KEYCLOAK_CLIENT_SECRET
SESSION_SECRET
GITHUB_ACCESS_TOKEN
```

The Entra client secret belongs to Keycloak's configuration, not the API Catalog pod.

## Authorization decision

After Keycloak returns the normalized user information, Flask requires exact membership in `/api-catalog-users` before it creates the application session.

```text
Entra authenticates the employee
      ↓
Entra groups contains target Object ID?
      ↓
Keycloak maps /api-catalog-users
      ↓
Flask receives groups
      ↓
Present → allow
Absent  → 403
```
