# Keycloak and Microsoft Entra Configuration

The API Catalog uses **application-level Keycloak OIDC**, with Keycloak brokering corporate authentication to **Microsoft Entra ID**. The AD/Entra security group remains the source of truth for access.

Start with [`entra-broker.md`](entra-broker.md) for the production end-to-end configuration. Use [`../local-sso/README.md`](../local-sso/README.md) to test locally.

## Required realm objects

1. A Microsoft Entra OIDC Identity Provider with alias `entra`
2. An OpenID Connect confidential client named `api-catalog-web`
3. A Keycloak realm group `/api-catalog-users`
4. An Identity Provider mapper that maps the approved Entra group Object ID to `/api-catalog-users`
5. A Group Membership protocol mapper that emits `/api-catalog-users` in the `groups` claim

## Client settings

Use `deploy/keycloak/client-template.json` as a starting point or configure the client in the Keycloak Admin Console.

Capability settings:

```text
Client authentication: On
Standard flow: On
Implicit flow: Off
Direct access grants: Off
Service account roles: Off
Authorization: Off
```

For the production hostname:

```text
Root URL:
https://api-catalog.internal.company.com

Valid redirect URI:
https://api-catalog.internal.company.com/auth/callback

Valid post logout redirect URI:
https://api-catalog.internal.company.com/auth/logged-out
```

Use exact URIs. Do not use `*` in production.

## Groups mapper

In the client dedicated scope, add a mapper by configuration:

```text
Mapper type: Group Membership
Name: groups
Token claim name: groups
Full group path: On
Add to ID token: On
Add to access token: On
Add to UserInfo: On
```

The application defaults to:

```env
KEYCLOAK_GROUP_CLAIM=groups
KEYCLOAK_REQUIRED_GROUPS=/api-catalog-users
```

Group matching is exact and case-sensitive. Multiple allowed groups can be supplied as a comma-separated list; membership in any configured group grants access.

## Client secret

After creating/importing the client, copy the generated client secret into the Kubernetes Secret as `KEYCLOAK_CLIENT_SECRET`. Never commit the real secret.

## Verify claims

Use Keycloak's client-scope evaluation feature or complete a test login. The ID token/UserInfo response must contain a claim similar to:

```json
{
  "groups": [
    "/api-catalog-users"
  ]
}
```

If the claim is absent or the required group is missing, the application returns its own access-denied page and does not create an application session.
