@echo off
setlocal EnableExtensions
cd /d "%~dp0"

title Postman API Catalog - Development Server

if not exist ".venv\Scripts\python.exe" (
    echo ERROR: The Python virtual environment is missing.
    echo Run setup.bat first.
    echo.
    pause
    exit /b 1
)

if not exist "frontend\node_modules" (
    echo ERROR: Frontend dependencies are missing.
    echo Run setup.bat first.
    echo.
    pause
    exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0start-dev.ps1"
set "START_EXIT=%ERRORLEVEL%"

if not "%START_EXIT%"=="0" (
    echo.
    echo Development startup failed.
    pause
)

exit /b %START_EXIT%
