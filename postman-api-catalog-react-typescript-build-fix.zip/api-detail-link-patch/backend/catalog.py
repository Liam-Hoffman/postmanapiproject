from __future__ import annotations

import json
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any

import yaml

import config
from postman_client import PostmanAPIError, PostmanClient, Workspace

HTTP_METHODS = {
    "get", "post", "put", "patch", "delete", "head", "options", "trace"
}


class _OpenAPISafeLoader(yaml.SafeLoader):
    """Safe YAML loader that keeps timestamp-like values JSON serializable."""


_OpenAPISafeLoader.yaml_implicit_resolvers = {
    key: [
        (tag, expression)
        for tag, expression in resolvers
        if tag != "tag:yaml.org,2002:timestamp"
    ]
    for key, resolvers in yaml.SafeLoader.yaml_implicit_resolvers.items()
}


def _unwrap_definition_payload(payload: Any) -> Any:
    """Unwrap Postman definition envelopes without unwrapping an OpenAPI document."""
    value = payload

    for _ in range(4):
        if not isinstance(value, dict):
            break

        # An actual OpenAPI/Swagger document can legally contain arbitrary
        # extension fields, so stop unwrapping once it looks like a spec.
        if any(key in value for key in ("openapi", "swagger", "paths")):
            break

        wrapper_key = next(
            (
                key
                for key in ("definition", "data", "content")
                if key in value and isinstance(value[key], (dict, str))
            ),
            None,
        )
        if wrapper_key is None:
            break
        value = value[wrapper_key]

    return value


def _parse_definition(
    payload: Any,
) -> tuple[dict[str, Any] | None, str, str | None]:
    value = _unwrap_definition_payload(payload)

    if isinstance(value, dict):
        return value, "json", None

    if isinstance(value, str):
        source_text = value.lstrip("\ufeff")

        try:
            parsed_json = json.loads(source_text)
            if isinstance(parsed_json, dict):
                return parsed_json, "json", value
        except json.JSONDecodeError:
            pass

        try:
            parsed_yaml = yaml.load(source_text, Loader=_OpenAPISafeLoader)
            if isinstance(parsed_yaml, dict):
                return parsed_yaml, "yaml", value
        except yaml.YAMLError:
            pass

        return None, "text", value

    return None, "unknown", None


def _resolve_schema(schema: dict[str, Any], document: dict[str, Any]) -> dict[str, Any]:
    if not isinstance(schema, dict):
        return {}
    ref = schema.get("$ref")
    if not isinstance(ref, str) or not ref.startswith("#/"):
        return schema
    current: Any = document
    for part in ref[2:].split("/"):
        part = part.replace("~1", "/").replace("~0", "~")
        if not isinstance(current, dict) or part not in current:
            return schema
        current = current[part]
    return current if isinstance(current, dict) else schema


def _example_from_schema(schema: dict[str, Any], document: dict[str, Any], depth: int = 0) -> Any:
    if depth > 6 or not isinstance(schema, dict):
        return None
    schema = _resolve_schema(schema, document)
    if "example" in schema:
        return schema["example"]
    if "default" in schema:
        return schema["default"]
    if isinstance(schema.get("enum"), list) and schema["enum"]:
        return schema["enum"][0]
    for key in ("oneOf", "anyOf"):
        if isinstance(schema.get(key), list) and schema[key]:
            return _example_from_schema(schema[key][0], document, depth + 1)
    if isinstance(schema.get("allOf"), list):
        merged = {}
        for option in schema["allOf"]:
            value = _example_from_schema(option, document, depth + 1)
            if isinstance(value, dict):
                merged.update(value)
        if merged:
            return merged
    schema_type = schema.get("type")
    if not schema_type:
        schema_type = "object" if "properties" in schema else "array" if "items" in schema else None
    if schema_type == "object":
        result = {}
        for name, child in (schema.get("properties") or {}).items():
            value = _example_from_schema(child, document, depth + 1)
            if value is not None:
                result[name] = value
        return result
    if schema_type == "array":
        item = _example_from_schema(schema.get("items", {}), document, depth + 1)
        return [] if item is None else [item]
    if schema_type in ("integer", "number"):
        return 0
    if schema_type == "boolean":
        return False
    if schema_type == "string":
        return {"date-time":"2026-01-01T00:00:00Z","date":"2026-01-01","uuid":"00000000-0000-0000-0000-000000000000","email":"user@example.com"}.get(schema.get("format"), "string")
    return None


def _extract_request_body_example(operation: dict[str, Any], document: dict[str, Any]) -> dict[str, Any] | None:
    request_body = operation.get("requestBody")
    if isinstance(request_body, dict):
        request_body = _resolve_schema(request_body, document)
        content = request_body.get("content") or {}
        if isinstance(content, dict) and content:
            media_type = next((x for x in ("application/json","application/*+json","multipart/form-data","application/x-www-form-urlencoded") if x in content), next(iter(content)))
            media = content.get(media_type) or {}
            if "example" in media:
                return {"contentType": media_type, "example": media["example"]}
            examples = media.get("examples")
            if isinstance(examples, dict) and examples:
                first = next(iter(examples.values()))
                if isinstance(first, dict) and "value" in first:
                    return {"contentType": media_type, "example": first["value"]}
            schema = media.get("schema")
            if isinstance(schema, dict):
                value = _example_from_schema(schema, document)
                if value is not None:
                    return {"contentType": media_type, "example": value}
    for parameter in operation.get("parameters", []) or []:
        if not isinstance(parameter, dict):
            continue
        parameter = _resolve_schema(parameter, document)
        if parameter.get("in") == "body" and isinstance(parameter.get("schema"), dict):
            value = _example_from_schema(parameter["schema"], document)
            if value is not None:
                consumes = operation.get("consumes") or document.get("consumes") or ["application/json"]
                return {"contentType": consumes[0] if consumes else "application/json", "example": value}
    return None


def _normalize_spec(
    spec: dict[str, Any],
    workspace: Workspace,
    definition_payload: Any,
) -> dict[str, Any]:
    definition, definition_format, definition_source = _parse_definition(definition_payload)
    info = definition.get("info", {}) if definition else {}

    spec_id = str(spec.get("id") or spec.get("uid") or "")
    name = info.get("title") or spec.get("name") or "Unnamed API"
    description = info.get("description") or spec.get("description") or ""
    version = info.get("version") or ""

    operations: list[dict[str, Any]] = []
    tags: set[str] = set()
    servers: list[str] = []
    security_schemes: list[str] = []

    if definition:
        for server in definition.get("servers", []) or []:
            if isinstance(server, dict) and server.get("url"):
                servers.append(str(server["url"]))

        for tag in definition.get("tags", []) or []:
            if isinstance(tag, dict) and tag.get("name"):
                tags.add(str(tag["name"]))

        paths = definition.get("paths", {})
        if isinstance(paths, dict):
            for path, path_item in paths.items():
                if not isinstance(path_item, dict):
                    continue
                for method, operation in path_item.items():
                    if method.lower() not in HTTP_METHODS:
                        continue
                    operation = operation if isinstance(operation, dict) else {}
                    operation_tags = [
                        str(value) for value in operation.get("tags", []) or []
                    ]
                    tags.update(operation_tags)
                    responses = operation.get("responses", {})
                    operations.append(
                        {
                            "method": method.upper(),
                            "path": str(path),
                            "summary": operation.get("summary") or "",
                            "description": operation.get("description") or "",
                            "operationId": operation.get("operationId") or "",
                            "deprecated": bool(operation.get("deprecated", False)),
                            "tags": operation_tags,
                            "requestBodyExample": _extract_request_body_example(operation, definition),
                            "requestFields": _extract_request_fields(operation, definition),
                            "responseCodes": list(responses.keys())
                            if isinstance(responses, dict)
                            else [],
                        }
                    )

        components = definition.get("components", {})
        if isinstance(components, dict):
            schemes = components.get("securitySchemes", {})
            if isinstance(schemes, dict):
                security_schemes = list(schemes.keys())

    owner = (
        info.get("x-owner-team")
        or info.get("x-owner")
        or info.get("x-team")
        or ""
    )
    lifecycle = (
        info.get("x-lifecycle")
        or info.get("x-api-lifecycle")
        or "unspecified"
    )
    repository = (
        info.get("x-repository")
        or info.get("x-repository-url")
        or info.get("x-github")
        or ""
    )
    support = info.get("x-support-channel") or info.get("x-support") or ""
    domain = (
        info.get("x-domain")
        or info.get("x-business-domain")
        or info.get("x-api-domain")
        or re.sub(r"^\[CSAA\]\s*[-:–—]?\s*", "", workspace.name, flags=re.IGNORECASE).strip()
        or "Unspecified"
    )

    if definition_source is not None:
        # Preserve the original source format in the specification tab.
        definition_text = definition_source
    elif definition is not None:
        definition_text = json.dumps(definition, ensure_ascii=False, indent=2)
    else:
        definition_text = json.dumps(definition_payload, ensure_ascii=False, indent=2)

    return {
        "definitionText": definition_text,
        "name": name,
        "description": description,
        "version": version,
        "type": spec.get("type") or "",
        "fileFormat": spec.get("fileFormat") or definition_format,
        "createdAt": spec.get("createdAt"),
        "updatedAt": spec.get("updatedAt"),
        "workspace": {
            "id": workspace.id,
            "name": workspace.name,
            "type": workspace.type,
        },
        "owner": owner,
        "lifecycle": lifecycle,
        "repository": repository,
        "support": support,
        "domain": domain,
        "tags": sorted(tags, key=str.lower),
        "servers": servers,
        "securitySchemes": security_schemes,
        "operationCount": len(operations),
        "operations": operations,
        "definitionParsed": definition is not None,
        "definitionFormat": definition_format,
    }


def _name_tokens(value: str) -> set[str]:
    return {
        token.casefold()
        for token in re.findall(r"[A-Za-z0-9]+", value)
        if len(token) >= 3
    }


def _user_name_tokens(users: list[dict[str, Any]]) -> set[str]:
    tokens: set[str] = set()
    for user in users:
        full_name = str(user.get("name") or "").strip()
        parts = re.findall(r"[A-Za-z0-9]+", full_name)
        if not parts:
            continue
        # Only first and last names are used, as requested. Exact token matching
        # avoids substring false positives such as Ann matching Analytics.
        for part in {parts[0], parts[-1]}:
            if len(part) >= 3:
                tokens.add(part.casefold())
    return tokens


def _workspace_matches_user(workspace_name: str, user_tokens: set[str]) -> bool:
    return bool(_name_tokens(workspace_name) & user_tokens)



def _schema_type_label(schema: dict[str, Any], document: dict[str, Any]) -> str:
    if not isinstance(schema, dict):
        return "unknown"

    resolved = _resolve_schema(schema, document)
    schema_type = resolved.get("type")

    if not schema_type:
        if "properties" in resolved:
            schema_type = "object"
        elif "items" in resolved:
            schema_type = "array"
        elif "$ref" in schema:
            schema_type = "object"
        else:
            schema_type = "unknown"

    if schema_type == "array":
        item_schema = resolved.get("items", {})
        return f"array<{_schema_type_label(item_schema, document)}>"

    fmt = resolved.get("format")
    return f"{schema_type} ({fmt})" if fmt else str(schema_type)


def _collect_schema_fields(
    schema: dict[str, Any],
    document: dict[str, Any],
    path_prefix: str = "",
    inherited_required: bool = True,
    depth: int = 0,
    seen_refs: set[str] | None = None,
) -> list[dict[str, Any]]:
    if depth > 8 or not isinstance(schema, dict):
        return []

    seen_refs = set() if seen_refs is None else set(seen_refs)
    ref = schema.get("$ref")
    if isinstance(ref, str):
        if ref in seen_refs:
            return []
        seen_refs.add(ref)

    resolved = _resolve_schema(schema, document)
    schema_type = resolved.get("type")
    if not schema_type:
        schema_type = "object" if "properties" in resolved else "array" if "items" in resolved else "unknown"

    fields: list[dict[str, Any]] = []

    if path_prefix:
        fields.append({
            "name": path_prefix.split(".")[-1],
            "path": path_prefix,
            "type": _schema_type_label(resolved, document),
            "required": bool(inherited_required),
            "description": resolved.get("description", ""),
        })

    if schema_type == "object":
        properties = resolved.get("properties", {})
        required_names = set(resolved.get("required", []) or [])
        if isinstance(properties, dict):
            for name, child_schema in properties.items():
                child_path = f"{path_prefix}.{name}" if path_prefix else name
                fields.extend(
                    _collect_schema_fields(
                        child_schema,
                        document,
                        child_path,
                        name in required_names,
                        depth + 1,
                        seen_refs,
                    )
                )

    elif schema_type == "array":
        items = resolved.get("items", {})
        if isinstance(items, dict):
            item_path = f"{path_prefix}[]" if path_prefix else "[]"
            item_resolved = _resolve_schema(items, document)
            item_type = item_resolved.get("type")
            if item_type == "object" or "properties" in item_resolved or "$ref" in items:
                fields.extend(
                    _collect_schema_fields(
                        items,
                        document,
                        item_path,
                        inherited_required,
                        depth + 1,
                        seen_refs,
                    )
                )

    # allOf can contribute fields from multiple schemas.
    all_of = resolved.get("allOf")
    if isinstance(all_of, list):
        for option in all_of:
            fields.extend(
                _collect_schema_fields(
                    option,
                    document,
                    path_prefix,
                    inherited_required,
                    depth + 1,
                    seen_refs,
                )
            )

    # Remove duplicate field paths while preserving order.
    deduped: list[dict[str, Any]] = []
    seen_paths: set[str] = set()
    for field in fields:
        path = field.get("path", "")
        if path and path not in seen_paths:
            seen_paths.add(path)
            deduped.append(field)
    return deduped


def _extract_request_fields(operation: dict[str, Any], document: dict[str, Any]) -> list[dict[str, Any]]:
    fields: list[dict[str, Any]] = []

    request_body = operation.get("requestBody")
    if isinstance(request_body, dict):
        request_body = _resolve_schema(request_body, document)
        content = request_body.get("content", {})
        if isinstance(content, dict) and content:
            preferred = (
                "application/json",
                "application/*+json",
                "multipart/form-data",
                "application/x-www-form-urlencoded",
            )
            media_type = next((item for item in preferred if item in content), None)
            if media_type is None:
                media_type = next(iter(content))
            media = content.get(media_type, {})
            if isinstance(media, dict):
                schema = media.get("schema", {})
                if isinstance(schema, dict):
                    fields.extend(_collect_schema_fields(schema, document, inherited_required=True))

    # OpenAPI 2 body parameters and ordinary path/query/header/cookie parameters.
    parameters = operation.get("parameters", [])
    if isinstance(parameters, list):
        for raw_parameter in parameters:
            if not isinstance(raw_parameter, dict):
                continue
            parameter = _resolve_schema(raw_parameter, document)
            location = str(parameter.get("in") or "parameter")

            if location == "body":
                schema = parameter.get("schema", {})
                if isinstance(schema, dict):
                    body_fields = _collect_schema_fields(
                        schema,
                        document,
                        inherited_required=bool(parameter.get("required", False)),
                    )
                    fields.extend(body_fields)
                continue

            name = str(parameter.get("name") or "unnamed")
            schema = parameter.get("schema") if isinstance(parameter.get("schema"), dict) else parameter
            fields.append({
                "name": name,
                "path": name,
                "type": _schema_type_label(schema, document),
                "required": bool(parameter.get("required", False) or location == "path"),
                "description": parameter.get("description", ""),
                "location": location,
            })

    deduped: list[dict[str, Any]] = []
    seen: set[tuple[str, str]] = set()
    for field in fields:
        key = (str(field.get("location", "body")), str(field.get("path", "")))
        if key not in seen:
            seen.add(key)
            field.setdefault("location", "body")
            deduped.append(field)
    return deduped


class CatalogService:
    def __init__(self, client: PostmanClient):
        self.client = client
        self._lock = threading.Lock()
        self._cached: dict[str, Any] | None = None
        self._cached_at = 0.0
        self._spec_index: dict[str, tuple[Workspace, dict[str, Any]]] = {}
        self._detail_cache: dict[str, dict[str, Any]] = {}

    def get_catalog(self, force: bool = False) -> dict[str, Any]:
        now = time.time()
        if (
            not force
            and self._cached is not None
            and now - self._cached_at < config.CACHE_TTL_SECONDS
        ):
            result = dict(self._cached)
            result["cache"] = {"hit": True, "ageSeconds": int(now - self._cached_at)}
            return result

        with self._lock:
            now = time.time()
            if (
                not force
                and self._cached is not None
                and now - self._cached_at < config.CACHE_TTL_SECONDS
            ):
                result = dict(self._cached)
                result["cache"] = {"hit": True, "ageSeconds": int(now - self._cached_at)}
                return result

            catalog = self._build_catalog()
            self._cached = catalog
            self._cached_at = time.time()
            result = dict(catalog)
            result["cache"] = {"hit": False, "ageSeconds": 0}
            return result

    def get_spec_detail(self, spec_id: str, force: bool = False) -> dict[str, Any]:
        if not force and spec_id in self._detail_cache:
            result = dict(self._detail_cache[spec_id])
            result["detailCacheHit"] = True
            return result

        # Build the lightweight catalog first if this process has not loaded it yet.
        if spec_id not in self._spec_index:
            self.get_catalog(force=False)

        item = self._spec_index.get(spec_id)
        if item is None:
            raise KeyError(f"Specification not found: {spec_id}")

        workspace, spec = item
        print(
            f"[Catalog] Loading definition on demand: "
            f"{spec.get('name') or spec_id}",
            flush=True,
        )
        definition = self.client.get_spec_definition(spec_id)
        detail = _normalize_spec(spec, workspace, definition)
        self._detail_cache[spec_id] = detail
        result = dict(detail)
        result["detailCacheHit"] = False
        return result

    @staticmethod
    def _metadata_spec(spec: dict[str, Any], workspace: Workspace) -> dict[str, Any]:
        return {
            "id": str(spec.get("id") or spec.get("uid") or ""),
            "name": spec.get("name") or "Unnamed API",
            "description": spec.get("description") or "",
            "version": spec.get("version") or "",
            "type": spec.get("type") or "",
            "fileFormat": spec.get("fileFormat") or "",
            "createdAt": spec.get("createdAt"),
            "updatedAt": spec.get("updatedAt"),
            "workspace": {
                "id": workspace.id,
                "name": workspace.name,
                "type": workspace.type,
            },
            # Definition-derived values are intentionally deferred.
            "owner": "",
            "lifecycle": "details not loaded",
            "repository": "",
            "support": "",
            "domain": re.sub(r"^\[CSAA\]\s*[-:–—]?\s*", "", workspace.name, flags=re.IGNORECASE).strip() or "Unspecified",
            "tags": [],
            "servers": [],
            "securitySchemes": [],
            "operationCount": None,
            "operations": [],
            "definitionParsed": None,
            "detailsLoaded": False,
        }

    def _build_catalog(self) -> dict[str, Any]:
        started = time.time()
        print("[Catalog] Loading accessible workspaces...", flush=True)
        workspaces = self.client.get_workspaces()
        print(f"[Catalog] Found {len(workspaces)} workspaces before user filtering", flush=True)

        user_filter_warning: dict[str, Any] | None = None
        try:
            users = self.client.get_team_users(force=False)
            user_tokens = _user_name_tokens(users)
            retained: list[Workspace] = []
            for workspace in workspaces:
                matched = _name_tokens(workspace.name) & user_tokens
                if matched:
                    print(
                        f"[Catalog] Excluding personal-name workspace: "
                        f"{workspace.name} (matched: {', '.join(sorted(matched))})",
                        flush=True,
                    )
                    continue
                retained.append(workspace)
            workspaces = retained
            print(
                f"[Catalog] {len(workspaces)} workspaces remain after user filtering",
                flush=True,
            )
        except PostmanAPIError as exc:
            user_filter_warning = {
                "stage": "list-users",
                "error": str(exc),
            }
            print(
                f"[Catalog] WARNING: Could not load team users; "
                f"name filtering disabled: {exc}",
                flush=True,
            )

        apis: list[dict[str, Any]] = []
        errors: list[dict[str, Any]] = (
            [user_filter_warning] if user_filter_warning is not None else []
        )
        next_index: dict[str, tuple[Workspace, dict[str, Any]]] = {}
        nonempty_workspaces: list[Workspace] = []

        def list_workspace_specs(workspace: Workspace) -> tuple[Workspace, list[dict[str, Any]]]:
            specs = self.client.get_specs_for_workspace(workspace.id)
            return workspace, specs

        worker_count = min(max(config.DEFINITION_WORKERS, 1), max(len(workspaces), 1))
        print(
            f"[Catalog] Listing workspace specs with {worker_count} workers...",
            flush=True,
        )

        with ThreadPoolExecutor(max_workers=worker_count) as executor:
            future_map = {
                executor.submit(list_workspace_specs, workspace): workspace
                for workspace in workspaces
            }

            completed = 0
            for future in as_completed(future_map):
                workspace = future_map[future]
                completed += 1
                try:
                    _, specs = future.result()
                    print(
                        f"[Catalog] Workspace {completed}/{len(workspaces)}: "
                        f"{workspace.name} — {len(specs)} specs",
                        flush=True,
                    )
                    if not specs:
                        print(
                            f"[Catalog] Excluding empty workspace: {workspace.name}",
                            flush=True,
                        )
                        continue
                    nonempty_workspaces.append(workspace)
                    for spec in specs:
                        spec_id = str(spec.get("id") or spec.get("uid") or "")
                        if not spec_id:
                            continue
                        next_index[spec_id] = (workspace, spec)
                        apis.append(self._metadata_spec(spec, workspace))
                except PostmanAPIError as exc:
                    print(
                        f"[Catalog] Workspace {workspace.name} ERROR: {exc}",
                        flush=True,
                    )
                    errors.append(
                        {
                            "workspaceId": workspace.id,
                            "workspaceName": workspace.name,
                            "stage": "list-specs",
                            "error": str(exc),
                        }
                    )

        apis.sort(
            key=lambda item: (
                item["name"].lower(),
                item["workspace"]["name"].lower(),
            )
        )
        self._spec_index = next_index

        elapsed_ms = int((time.time() - started) * 1000)
        print(
            f"[Catalog] Initial catalog ready: {len(apis)} APIs in "
            f"{elapsed_ms} ms. Definitions load only when opened.",
            flush=True,
        )

        return {
            "generatedAt": int(time.time()),
            "loadMilliseconds": elapsed_ms,
            "workspaceCount": len(nonempty_workspaces),
            "apiCount": len(apis),
            "workspaces": [
                {"id": ws.id, "name": ws.name, "type": ws.type}
                for ws in sorted(nonempty_workspaces, key=lambda item: item.name.casefold())
            ],
            "apis": apis,
            "errors": errors,
            "lazyDefinitions": True,
        }
