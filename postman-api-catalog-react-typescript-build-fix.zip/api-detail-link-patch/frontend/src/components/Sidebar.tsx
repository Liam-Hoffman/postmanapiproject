import type { CatalogFacetFilters, CatalogFacetKey, CatalogFacetOptions } from '../types'

interface Props {
  summary: string
  search: string
  workspace: string
  sort: string
  filters: CatalogFacetFilters
  facetOptions: CatalogFacetOptions
  workspaces: { id: string; name: string }[]
  apiCount: number
  workspaceCount: number
  loading: boolean
  onSearch(value: string): void
  onWorkspace(value: string): void
  onSort(value: string): void
  onFacet(key: CatalogFacetKey, value: string): void
  onClearFacets(): void
  onRefresh(): void
  onTheme(): void
}

const FACETS: Array<{ key: CatalogFacetKey; label: string; allLabel: string }> = [
  { key: 'method', label: 'HTTP method', allLabel: 'All methods' },
  { key: 'lifecycle', label: 'Lifecycle', allLabel: 'All lifecycles' },
  { key: 'domain', label: 'Business domain', allLabel: 'All domains' },
  { key: 'owner', label: 'Owning team', allLabel: 'All owners' },
  { key: 'auth', label: 'Authentication', allLabel: 'All authentication' },
  { key: 'tag', label: 'Tag', allLabel: 'All tags' },
]

export function Sidebar(props: Props) {
  const activeFacets = FACETS.filter(facet => props.filters[facet.key])

  return <aside className="catalog-sidebar">
    <header className="brand-block">
      <div className="eyebrow">Internal Developer Portal</div>
      <h1>API Catalog</h1>
      <p>{props.summary}</p>
      <div className="actions">
        <button onClick={props.onRefresh} disabled={props.loading}>{props.loading ? 'Loading…' : 'Refresh Postman'}</button>
        <button className="secondary" onClick={props.onTheme}>Theme</button>
      </div>
    </header>

    <section className="sidebar-panel">
      <label>
        <span>Search APIs and endpoints</span>
        <input
          value={props.search}
          onChange={event => props.onSearch(event.target.value)}
          type="search"
          placeholder="API, endpoint, owner, tag…"
        />
      </label>

      <label>
        <span>CSAA workspace</span>
        <select value={props.workspace} onChange={event => props.onWorkspace(event.target.value)}>
          <option value="">All matching workspaces ({props.workspaces.length})</option>
          {props.workspaces.map(workspace => <option key={workspace.id} value={workspace.id}>{workspace.name}</option>)}
        </select>
      </label>

      <label>
        <span>Sort APIs</span>
        <select value={props.sort} onChange={event => props.onSort(event.target.value)}>
          <option value="name">Name</option>
          <option value="updated">Recently updated</option>
          <option value="operations">Most operations</option>
        </select>
      </label>

      <div className="facet-panel">
        <div className="facet-panel__header">
          <div>
            <strong>Filter APIs</strong>
            <span>Options update as API details load.</span>
          </div>
          {!!activeFacets.length && <button type="button" className="clear-facets" onClick={props.onClearFacets}>Clear all</button>}
        </div>

        <div className="facet-controls">
          {FACETS.map(facet => <label key={facet.key}>
            <span>{facet.label}</span>
            <select value={props.filters[facet.key]} onChange={event => props.onFacet(facet.key, event.target.value)}>
              <option value="">{facet.allLabel}</option>
              {props.facetOptions[facet.key].map(option => <option key={option.value} value={option.value}>
                {option.label} ({option.count})
              </option>)}
            </select>
          </label>)}
        </div>

        {!!activeFacets.length && <div className="active-filter-chips" aria-label="Active filters">
          {activeFacets.map(facet => <button
            type="button"
            className="filter-chip"
            key={facet.key}
            onClick={() => props.onFacet(facet.key, '')}
            aria-label={`Remove ${facet.label} filter ${props.filters[facet.key]}`}
          >
            <span>{facet.label}: {props.filters[facet.key]}</span>
            <span aria-hidden="true">×</span>
          </button>)}
        </div>}
      </div>

      <div className="sidebar-help">
        <strong>Catalog scope</strong>
        <span>Only Postman workspaces beginning with <code>[CSAA]</code> are included.</span>
      </div>

      <div className="stats">
        <div><strong>{props.apiCount}</strong><span>Matching APIs</span></div>
        <div><strong>{props.workspaceCount}</strong><span>Workspaces</span></div>
      </div>
    </section>
  </aside>
}
