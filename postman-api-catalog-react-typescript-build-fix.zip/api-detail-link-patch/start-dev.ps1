$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ProjectRoot

$VenvPython = Join-Path $ProjectRoot ".venv\Scripts\python.exe"
if (-not (Test-Path $VenvPython)) {
    throw "The Python virtual environment is missing. Run setup.bat first."
}
if (-not (Test-Path "frontend\node_modules")) {
    throw "Frontend dependencies are missing. Run setup.bat first."
}

$backendCommand = "& '$VenvPython' backend\run.py"
$backendProcess = Start-Process powershell.exe `
    -ArgumentList @("-NoExit", "-NoProfile", "-Command", "Set-Location '$ProjectRoot'; $backendCommand") `
    -PassThru

try {
    Push-Location frontend
    npm run dev
    if ($LASTEXITCODE -ne 0) {
        throw "The frontend development server exited with code $LASTEXITCODE."
    }
} finally {
    Pop-Location
    if ($backendProcess -and -not $backendProcess.HasExited) {
        Stop-Process -Id $backendProcess.Id -ErrorAction SilentlyContinue
    }
}
