interface Props {
  summary: string
  search: string
  workspace: string
  sort: string
  workspaces: { id: string; name: string }[]
  apiCount: number
  workspaceCount: number
  loading: boolean
  onSearch(value: string): void
  onWorkspace(value: string): void
  onSort(value: string): void
  onRefresh(): void
  onTheme(): void
}

export function Sidebar(props: Props) {
  return <aside className="catalog-sidebar">
    <header className="brand-block">
      <div className="eyebrow">Internal Developer Portal</div>
      <h1>API Catalog</h1>
      <p>{props.summary}</p>
      <div className="actions sidebar-actions">
        <button className="sidebar-action-button sidebar-action-button--primary" onClick={props.onRefresh} disabled={props.loading}>
          {props.loading ? 'Refreshing…' : 'Refresh'}
        </button>
        <button className="sidebar-action-button sidebar-action-button--secondary" onClick={props.onTheme}>
          Theme
        </button>
      </div>
    </header>

    <section className="sidebar-panel">
      <label>
        <span>Search APIs and endpoints</span>
        <input
          value={props.search}
          onChange={event => props.onSearch(event.target.value)}
          type="search"
          placeholder="API, endpoint, owner, tag…"
        />
      </label>

      <label>
        <span>Repository folder</span>
        <select value={props.workspace} onChange={event => props.onWorkspace(event.target.value)}>
          <option value="">All matching folders ({props.workspaces.length})</option>
          {props.workspaces.map(workspace => <option key={workspace.id} value={workspace.id}>{workspace.name}</option>)}
        </select>
      </label>

      <label>
        <span>Sort APIs</span>
        <select value={props.sort} onChange={event => props.onSort(event.target.value)}>
          <option value="name">Name</option>
          <option value="updated">Recently updated</option>
          <option value="operations">Most operations</option>
        </select>
      </label>

      <div className="sidebar-help">
        <strong>Catalog scope</strong>
        <span>JSON and YAML files are checked recursively and included only when their contents are valid OpenAPI documents.</span>
      </div>

      <div className="stats">
        <div><strong>{props.apiCount}</strong><span>Matching APIs</span></div>
        <div><strong>{props.workspaceCount}</strong><span>Source folders</span></div>
      </div>
    </section>
  </aside>
}
