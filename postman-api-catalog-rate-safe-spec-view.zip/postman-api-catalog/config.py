import os

POSTMAN_BASE_URL = os.environ.get("POSTMAN_BASE_URL", "https://api.postman.com").rstrip("/")
POSTMAN_API_KEY = os.environ.get("POSTMAN_API_KEY", "").strip()
HOST = os.environ.get("CATALOG_HOST", "127.0.0.1")
PORT = int(os.environ.get("CATALOG_PORT", "8080"))
CACHE_TTL_SECONDS = int(os.environ.get("CATALOG_CACHE_TTL_SECONDS", "900"))
REQUEST_TIMEOUT_SECONDS = int(os.environ.get("POSTMAN_REQUEST_TIMEOUT_SECONDS", "30"))
SPEC_PAGE_LIMIT = min(max(int(os.environ.get("POSTMAN_SPEC_PAGE_LIMIT", "100")), 1), 100)

WORKSPACE_ALLOWLIST = {
    value.strip()
    for value in os.environ.get("POSTMAN_WORKSPACE_ALLOWLIST", "").split(",")
    if value.strip()
}

DEFINITION_WORKERS = min(max(int(os.environ.get("POSTMAN_DEFINITION_WORKERS", "8")), 1), 32)

POSTMAN_REQUESTS_PER_MINUTE = min(max(int(os.environ.get("POSTMAN_REQUESTS_PER_MINUTE", "240")), 1), 300)
POSTMAN_RATE_LIMIT_RETRIES = min(max(int(os.environ.get("POSTMAN_RATE_LIMIT_RETRIES", "5")), 0), 10)
POSTMAN_RATE_LIMIT_BUFFER_SECONDS = max(float(os.environ.get("POSTMAN_RATE_LIMIT_BUFFER_SECONDS", "1")), 0.0)
