import type { ApiItem, CatalogPayload } from '../types'

export interface AuthUser {
  subject: string
  username: string
  name: string
  email: string
  authorizedGroups: string[]
}

export interface AuthState {
  enabled: boolean
  authenticated: boolean
  user: AuthUser | null
  requiredGroups?: string[]
  loginUrl?: string
}

function redirectToLogin(): void {
  const next = `${window.location.pathname}${window.location.search}${window.location.hash}`
  window.location.assign(`/auth/login?next=${encodeURIComponent(next)}`)
}

async function getJson<T>(url: string): Promise<T> {
  const response = await fetch(url, {
    headers: { Accept: 'application/json' },
    credentials: 'same-origin',
  })

  let payload: Record<string, unknown> = {}
  try {
    payload = await response.json() as Record<string, unknown>
  } catch {
    payload = {}
  }

  if (response.status === 401) {
    redirectToLogin()
    throw new Error('Authentication required')
  }

  if (!response.ok) {
    throw new Error(
      String(payload.details || payload.error || `HTTP ${response.status}`),
    )
  }
  return payload as T
}

export const catalogApi = {
  getAuth: () => getJson<AuthState>('/api/auth/me'),
  getCatalog: (refresh = false) => getJson<CatalogPayload>(`/api/catalog${refresh ? '?refresh=true' : ''}`),
  getSpec: (id: string) => getJson<ApiItem>(`/api/specs/${encodeURIComponent(id)}`),
}
