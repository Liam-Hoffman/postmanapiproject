import { useEffect, useMemo, useRef, useState } from 'react'
import { Navigate, Route, Routes, useLocation, useNavigate, useParams } from 'react-router-dom'
import { Sidebar } from './components/Sidebar'
import { ApiExplorer } from './components/ApiExplorer'
import { catalogApi, type AuthState } from './lib/api'
import { apiSearchable } from './lib/text'
import type {
  ApiItem,
  CatalogPayload,
  Operation,
} from './types'


function apiDisplayName(api: ApiItem): string {
  const name = api.name || 'Unnamed API'
  const version = String(api.version || '').trim()
  const majorVersion = version.match(/\d+/)?.[0]

  if (!majorVersion) return name

  const normalizedName = name.toLowerCase()
  if (
    new RegExp(`\\bv\\s*${majorVersion}\\b`, 'i').test(name) ||
    new RegExp(`\\bversion\\s*${majorVersion}\\b`, 'i').test(name)
  ) {
    return name
  }

  return `${name} V${majorVersion}`
}

function slugFor(api: ApiItem) {
  return `${apiDisplayName(api).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')}-${api.id}`
}

function operationAnchor(operation: Operation, index: number) {
  return `${operation.method.toLowerCase()}-${(operation.operationId || operation.summary || operation.path || String(index))
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '')}`
}
function operationSearchText(operation: Operation): string {
  return [
    operation.method,
    operation.path,
    operation.summary,
    operation.description,
    operation.operationId,
    ...(operation.tags || []),
  ]
    .filter(Boolean)
    .join(' ')
    .toLowerCase()
}

function matchingOperations(api: ApiItem, query: string): Operation[] {
  if (!query) return []
  return (api.operations || []).filter(operation => operationSearchText(operation).includes(query))
}

function HighlightText({ text, query }: { text: string; query: string }) {
  if (!query) return <>{text}</>

  const normalizedText = text.toLowerCase()
  const parts: Array<{ value: string; match: boolean }> = []
  let cursor = 0
  let matchIndex = normalizedText.indexOf(query, cursor)

  while (matchIndex !== -1) {
    if (matchIndex > cursor) parts.push({ value: text.slice(cursor, matchIndex), match: false })
    parts.push({ value: text.slice(matchIndex, matchIndex + query.length), match: true })
    cursor = matchIndex + query.length
    matchIndex = normalizedText.indexOf(query, cursor)
  }

  if (cursor < text.length) parts.push({ value: text.slice(cursor), match: false })
  if (!parts.length) return <>{text}</>

  return <>{parts.map((part, index) => part.match
    ? <mark className="search-highlight" key={`${part.value}-${index}`}>{part.value}</mark>
    : <span key={`${part.value}-${index}`}>{part.value}</span>)}</>
}

export default function App() {
  const [payload, setPayload] = useState<CatalogPayload>({ apis: [], apiCount: 0, workspaceCount: 0 })
  const [auth, setAuth] = useState<AuthState>({ enabled: false, authenticated: true, user: null })
  const [apiSearch, setApiSearch] = useState('')
  const [endpointSearch, setEndpointSearch] = useState('')
  const [sort, setSort] = useState('name')
  const [loading, setLoading] = useState(true)
  const [status, setStatus] = useState('Scanning GitHub monorepo…')
  const [detailProgress, setDetailProgress] = useState({ loaded: 0, total: 0, failed: 0 })
  const hydrationRun = useRef(0)
  const detailRequests = useRef(new Map<string, Promise<ApiItem>>())

  async function hydrateDetails(apis: ApiItem[], runId: number) {
    const pending = apis.filter(api => !api.detailsLoaded)
    setDetailProgress({ loaded: 0, total: pending.length, failed: 0 })
    if (!pending.length) return

    let cursor = 0
    let loaded = 0
    let failed = 0
    const workerCount = Math.min(4, pending.length)

    async function worker() {
      while (cursor < pending.length && hydrationRun.current === runId) {
        const api = pending[cursor++]
        try {
          await ensureDetails(api)
          if (hydrationRun.current !== runId) return
          loaded += 1
        } catch {
          failed += 1
        }

        if (hydrationRun.current === runId) {
          setDetailProgress({ loaded, total: pending.length, failed })
          setStatus(
            loaded + failed < pending.length
              ? `Loading API details ${loaded + failed}/${pending.length}…`
              : failed
                ? `Loaded details for ${loaded} APIs · ${failed} could not be loaded`
                : `All ${loaded} API details are ready`,
          )
        }
      }
    }

    await Promise.all(Array.from({ length: workerCount }, worker))
  }

  async function load(refresh = false) {
    const runId = ++hydrationRun.current
    setLoading(true)
    setStatus('Scanning GitHub monorepo…')

    try {
      const data = await catalogApi.getCatalog(refresh)
      const apis = data.apis
      setPayload({
        ...data,
        apis,
        apiCount: apis.length,
      })
      setStatus(`Found ${apis.length} OpenAPI files · loading endpoint details…`)
      void hydrateDetails(apis, runId)
    } catch (error) {
      setStatus(error instanceof Error ? error.message : 'Unable to load catalog')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    void catalogApi.getAuth().then(setAuth).catch(() => undefined)
    void load()
  }, [])

  const apiQuery = apiSearch.trim().toLowerCase()
  const endpointQuery = endpointSearch.trim().toLowerCase()

  const apiMatches = useMemo(
    () => payload.apis.filter(api => !apiQuery || apiSearchable(api).includes(apiQuery)),
    [payload.apis, apiQuery],
  )

  const endpointMatches = useMemo(
    () => apiMatches.filter(api => !endpointQuery || matchingOperations(api, endpointQuery).length > 0),
    [apiMatches, endpointQuery],
  )

  const items = useMemo(() => {
    return [...endpointMatches].sort((a, b) => sort === 'updated'
      ? String(b.updatedAt || '').localeCompare(String(a.updatedAt || ''))
      : sort === 'operations'
        ? (b.operationCount ?? -1) - (a.operationCount ?? -1)
        : a.name.localeCompare(b.name))
  }, [endpointMatches, sort])

  const visibleEndpointCount = useMemo(
    () => items.reduce(
      (total, api) => total + (
        endpointQuery
          ? matchingOperations(api, endpointQuery).length
          : (api.operationCount ?? api.operations?.length ?? 0)
      ),
      0,
    ),
    [items, endpointQuery],
  )

  async function ensureDetails(api: ApiItem) {
    const currentApi = payload.apis.find(item => item.id === api.id) ?? api
    if (currentApi.detailsLoaded) return currentApi

    const existingRequest = detailRequests.current.get(api.id)
    if (existingRequest) return existingRequest

    const request = catalogApi.getSpec(api.id).then(detail => {
      const merged: ApiItem = {
        ...currentApi,
        ...detail,
        catalogDescription: currentApi.catalogDescription ?? currentApi.description,
        detailsLoaded: true,
      }
      setPayload(current => ({
        ...current,
        apis: current.apis.map(item => item.id === api.id ? merged : item),
      }))
      return merged
    }).finally(() => detailRequests.current.delete(api.id))

    detailRequests.current.set(api.id, request)
    return request
  }


  const sourceName = payload.source?.repository || 'configured GitHub monorepo'
  const sourceRef = payload.source?.ref ? ` @ ${payload.source.ref}` : ''
  const summary = `${sourceName}${sourceRef}${payload.loadMilliseconds != null ? ` · scanned in ${payload.loadMilliseconds} ms` : ''}`
  const location = useLocation()
  const isCatalogHome = location.pathname === '/'

  return <div className={`catalog-shell app-shell ${isCatalogHome ? 'catalog-route' : 'detail-route'}`}>
    {isCatalogHome && <Sidebar
      summary={summary}
      apiSearch={apiSearch}
      endpointSearch={endpointSearch}
      sort={sort}
      apiCount={items.length}
      endpointCount={visibleEndpointCount}
      loading={loading}
      auth={auth}
      onLogout={() => window.location.assign('/auth/logout')}
      onApiSearch={setApiSearch}
      onEndpointSearch={setEndpointSearch}
      onSort={setSort}
      onRefresh={() => void load(true)}
      onTheme={() => {
        document.documentElement.classList.toggle('dark')
        localStorage.setItem('catalog-theme', document.documentElement.classList.contains('dark') ? 'dark' : 'light')
      }}
    />}

    <Routes>
      <Route path="/" element={<CatalogHome
        items={items}
        apiQuery={apiQuery}
        endpointQuery={endpointQuery}
        status={status}
        detailProgress={detailProgress}
        slugFor={slugFor}
        ensureDetails={ensureDetails}
      />} />
      <Route path="/catalog/:apiSlug" element={<ApiRoute
        apis={payload.apis}
        ensureDetails={ensureDetails}
        auth={auth}
        onLogout={() => window.location.assign('/auth/logout')}
      />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  </div>
}

function CatalogHome({
  items,
  apiQuery,
  endpointQuery,
  status,
  detailProgress,
  slugFor: makeSlug,
  ensureDetails,
}: {
  items: ApiItem[]
  apiQuery: string
  endpointQuery: string
  status: string
  detailProgress: { loaded: number; total: number; failed: number }
  slugFor(api: ApiItem): string
  ensureDetails(api: ApiItem): Promise<ApiItem>
}) {
  const navigate = useNavigate()
  const [expandedApiId, setExpandedApiId] = useState<string | null>(null)
  const [previewLoadingId, setPreviewLoadingId] = useState<string | null>(null)
  const [previewError, setPreviewError] = useState<Record<string, string>>({})

  useEffect(() => {
    setExpandedApiId(null)
  }, [endpointQuery])

  async function togglePreview(api: ApiItem) {
    if (expandedApiId === api.id) {
      setExpandedApiId(null)
      return
    }

    setExpandedApiId(api.id)
    setPreviewError(current => ({ ...current, [api.id]: '' }))
    if (api.detailsLoaded) return

    setPreviewLoadingId(api.id)
    try {
      await ensureDetails(api)
    } catch (error) {
      setPreviewError(current => ({
        ...current,
        [api.id]: error instanceof Error ? error.message : 'Unable to load endpoint preview',
      }))
    } finally {
      setPreviewLoadingId(current => current === api.id ? null : current)
    }
  }

  return <main className="catalog-main">
    <div className="main-header sticky-topbar dashboard-main-header">
      <div className="dashboard-main-header__title">
        <div className="eyebrow">API Directory</div>
        <h2>Available APIs</h2>
        <p>Browse specifications, owners, lifecycle status, and endpoints.</p>
      </div>
      <div className="dashboard-main-header__status">
        <span className="dashboard-status-pill">{status}</span>
        <span className="dashboard-visible-count">{items.length} visible</span>
        {endpointQuery && <span className="dashboard-filter-pill">Endpoint filter active</span>}
        {detailProgress.total > 0 && detailProgress.loaded + detailProgress.failed < detailProgress.total &&
          <span className="dashboard-loading-count">{detailProgress.loaded}/{detailProgress.total} details ready</span>}
      </div>
    </div>

    <div className="page-scroll-body catalog-scroll-body catalog-scroll-frame">
      <section className="flat-api-catalog">
        <div className="flat-api-horizontal-scroll">
          <div className="flat-api-grid">
            <div className="api-list-header">
              <span>API</span><span>Lifecycle</span><span>Owner</span><span>Updated</span><span>Operations</span>
            </div>

            <div className="api-list-vertical-scroll">
              <div className="api-list-table flat-api-list-table">
                {items.map(api => {
                  const expanded = expandedApiId === api.id
                  const loadingPreview = previewLoadingId === api.id || (expanded && !api.detailsLoaded && !previewError[api.id])
                  const operationMatches = matchingOperations(api, endpointQuery)
                  const previewOperations = endpointQuery ? operationMatches : (api.operations || [])
                  const totalOperations = api.operationCount ?? api.operations?.length ?? 0
                  const disclosureCount = endpointQuery ? operationMatches.length : totalOperations
                  const disclosureNoun = endpointQuery
                    ? `match${disclosureCount === 1 ? '' : 'es'}`
                    : `endpoint${disclosureCount === 1 ? '' : 's'}`

                  return <div className={`api-list-entry${expanded ? ' preview-open' : ''}`} key={api.id}>
                    <div
                      className="api-list-row"
                      role="link"
                      tabIndex={0}
                      onClick={() => navigate(`/catalog/${makeSlug(api)}`)}
                      onKeyDown={event => {
                        if (event.key === 'Enter' || event.key === ' ') navigate(`/catalog/${makeSlug(api)}`)
                      }}
                    >
                      <span className="api-list-name">
                        <strong><HighlightText text={apiDisplayName(api)} query={apiQuery} /></strong>
                        <small className="api-source-path" title={api.sourcePath || undefined}>
                          <HighlightText text={api.sourcePath || 'Repository path unavailable'} query={apiQuery} />
                        </small>
                      </span>
                      <span><span className="lifecycle-pill"><HighlightText text={api.lifecycle || 'Loading…'} query={apiQuery} /></span></span>
                      <span><HighlightText text={api.owner || (api.detailsLoaded ? 'Not specified' : 'Loading…')} query={apiQuery} /></span>
                      <span>{api.updatedAt ? new Date(api.updatedAt).toLocaleDateString() : 'Unknown'}</span>
                      <span className="operation-disclosure-cell">
                        <button
                          type="button"
                          className="operation-disclosure"
                          aria-expanded={expanded}
                          aria-controls={`api-preview-${api.id}`}
                          aria-label={`${expanded ? 'Collapse' : 'Expand'} ${endpointQuery ? 'matching ' : ''}operations for ${apiDisplayName(api)}`}
                          onClick={event => {
                            event.stopPropagation()
                            void togglePreview(api)
                          }}
                        >
                          <span className="operation-disclosure__label">
                            <span className="operation-disclosure__count">{disclosureCount}</span>
                            <span className="operation-disclosure__noun">{disclosureNoun}</span>
                          </span>
                          <span className={`operation-disclosure__chevron${expanded ? ' expanded' : ''}`} aria-hidden="true">⌄</span>
                        </button>
                      </span>
                    </div>

                    {expanded && <div className="api-operation-preview" id={`api-preview-${api.id}`}>
                      {loadingPreview && <p className="preview-status">Loading operations and endpoints…</p>}
                      {previewError[api.id] && <p className="preview-status error">{previewError[api.id]}</p>}
                      {api.detailsLoaded && !previewOperations.length && <p className="preview-status">
                        {endpointQuery ? 'No matching endpoints were found.' : 'No operations were found in this specification.'}
                      </p>}
                      {!!previewOperations.length && <>
                        {endpointQuery && <div className="operation-filter-summary">
                          Showing {previewOperations.length} matching endpoint{previewOperations.length === 1 ? '' : 's'} for “{endpointQuery}”
                        </div>}
                        <div className="preview-operation-list">
                          {previewOperations.map((operation, index) => {
                            const operationIndex = (api.operations || []).indexOf(operation)
                            return <button
                              type="button"
                              className="preview-operation-row"
                              key={`${operation.method}-${operation.path}-${index}`}
                              onClick={() => navigate(`/catalog/${makeSlug(api)}#${operationAnchor(operation, operationIndex)}`)}
                            >
                              <span className={`preview-method method-${operation.method.toLowerCase()}`}>
                                <HighlightText text={operation.method} query={endpointQuery} />
                              </span>
                              <code><HighlightText text={operation.path} query={endpointQuery} /></code>
                              <span className="preview-operation-summary">
                                <HighlightText text={operation.summary || operation.description || 'View endpoint details'} query={endpointQuery} />
                              </span>
                            </button>
                          })}
                        </div>
                      </>}
                    </div>}
                  </div>
                })}

                {!items.length && <p className="notice flat-api-empty">
                  {endpointQuery
                    ? 'No APIs contain endpoints matching the current endpoint search.'
                    : 'No APIs match the current API search.'}
                </p>}
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </main>
}


function ApiRoute({
  apis,
  ensureDetails,
  auth,
  onLogout,
}: {
  apis: ApiItem[]
  ensureDetails(api: ApiItem): Promise<ApiItem>
  auth: AuthState
  onLogout(): void
}) {
  const { apiSlug = '' } = useParams()
  const navigate = useNavigate()
  const location = useLocation()
  const id = apiSlug.split('-').at(-1) || ''
  const baseApi = apis.find(api => api.id === id) || apis.find(api => apiSlug.endsWith(api.id))
  const [api, setApi] = useState<ApiItem | null>(baseApi || null)
  const [loading, setLoading] = useState(Boolean(baseApi && !baseApi.detailsLoaded))
  const [error, setError] = useState('')

  useEffect(() => {
    if (!baseApi) return
    setApi(baseApi)
    if (baseApi.detailsLoaded) return

    setLoading(true)
    setError('')
    ensureDetails(baseApi)
      .then(setApi)
      .catch(errorValue => setError(errorValue instanceof Error ? errorValue.message : 'Unable to load API'))
      .finally(() => setLoading(false))
  }, [baseApi?.id])

  if (!baseApi && apis.length) return <Navigate to="/" replace />

  return <main className="catalog-main explorer-main">
    <div className="main-header sticky-topbar detail-page-header">
      <div className="detail-page-header__content">
        <div className="detail-page-header__nav-row">
          <button className="detail-back-button" onClick={() => navigate('/')}>
            <span aria-hidden="true">←</span>
            <span>Back to Catalog</span>
          </button>
          <nav className="detail-breadcrumbs" aria-label="Breadcrumb">
            <button className="breadcrumb-link" onClick={() => navigate('/')}>Catalog</button>
            <span aria-hidden="true">/</span>
            <span aria-current="page">{api ? apiDisplayName(api) : 'Loading API…'}</span>
          </nav>
        </div>
        <h2>{api ? apiDisplayName(api) : 'Loading API…'}</h2>
      </div>
      <div className="detail-page-header__actions">
        <p>{location.hash ? 'Linked operation' : 'API reference'}</p>
        {auth.enabled && auth.user && <button type="button" className="detail-auth-control" onClick={onLogout}>
          <span>{auth.user.name || auth.user.username}</span>
          <strong>Sign out</strong>
        </button>}
      </div>
    </div>

    <div className="page-scroll-body detail-scroll-body">
      {loading && <p className="notice">Loading this API definition from GitHub…</p>}
      {error && <p className="notice error">{error}</p>}
      {api && !loading && !error && <ApiExplorer api={api} />}
    </div>
  </main>
}
