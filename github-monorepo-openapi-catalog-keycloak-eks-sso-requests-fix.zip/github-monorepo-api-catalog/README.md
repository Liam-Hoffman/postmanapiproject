# GitHub Monorepo API Catalog

## Full documentation

Complete product and runtime documentation is available in [`docs/README.md`](docs/README.md), including the user guide, OpenAPI authoring guidance, local setup, runtime architecture, AWS/SSO deployment, security model, operations runbook, API reference, and troubleshooting.

A local React, TypeScript, Vite, Flask, and Python API catalog that discovers OpenAPI documents from one GitHub monorepo.

## Discovery behavior

The backend scans every `.json`, `.yml`, and `.yaml` file at any repository depth. A file is included only when its parsed contents contain an OpenAPI version marker (or Swagger `2.0`), an `info.title`, and a `paths` object.

Filenames do not matter. Examples such as `payments-api.yaml`, `service-definition.json`, and `v2.yml` are accepted when their contents are OpenAPI.

The main catalog is flat: every OpenAPI document is one API row. The row title uses `info.title` plus its major version, such as `Payments API V2`, and a smaller subtitle shows the exact repository file path.

When GitHub reports that a recursive tree response is truncated, the provider walks every subtree explicitly so deeply nested specification files are still discovered.

## Supported OpenAPI metadata

Standard fields are read from `info`, `paths`, `components`, and related OpenAPI structures. These optional extensions improve catalog metadata:

```yaml
info:
  title: Payments API
  version: 2.0.0
  description: Payment processing operations
  x-owner-team: Payments Platform
  x-lifecycle: production
  x-domain: Payments
  x-support-channel: "#payments-api-support"
```

The parser supports OpenAPI JSON and YAML, including OpenAPI 2/Swagger-style body parameters. Local JSON Pointer references such as `#/components/schemas/Payment` are resolved. External relative `$ref` files are not bundled in this version.

## GitHub repository configuration

Only two required values are needed:

```env
GITHUB_REPOSITORY_URL=https://github.com/organization/platform-monorepo
GITHUB_ACCESS_TOKEN=your-token
```

Use the repository root URL, not a branch, folder, or file URL. The application accepts standard HTTPS clone URLs ending in `.git` and SSH clone URLs as well.

For `github.com`, the backend automatically uses `https://api.github.com`. For a GitHub Enterprise URL such as `https://github.example.com/organization/platform-monorepo`, it automatically uses `https://github.example.com/api/v3`.

The token must have read-only access to repository contents. It is stored only in the root `.env`, excluded by `.gitignore`, added to backend GitHub requests as a Bearer token, and never sent to the browser.

Optional settings remain available:

```env
GITHUB_SEARCH_ROOT=
GITHUB_SPEC_EXTENSIONS=.json,.yml,.yaml
GITHUB_SCAN_WORKERS=8
CATALOG_CACHE_TTL_SECONDS=900
```

## First-time Windows setup

Run:

```bat
setup.bat
```

Setup now asks only for the GitHub repository URL and access token. It parses the owner, repository, GitHub host, API endpoint, and default branch automatically. It then installs dependencies, verifies token-authenticated repository access, and runs the frontend production build.

The repository URL is entered normally, while the token prompt is hidden so the token is not echoed to the terminal.

Then start the local application:

```bat
start-dev.bat
```

The frontend remains at `http://127.0.0.1:5173`, and Flask remains at `http://127.0.0.1:8080`.

## API routes

- `GET /api/health`
- `GET /api/source-health`
- `GET /api/catalog`
- `GET /api/catalog?refresh=true`
- `GET /api/discovery?refresh=true`
- `GET /api/specs/{catalogId}`
- `GET /api/workspaces` — compatibility route returning repository folders

## Source layout

```text
backend/
  app.py
  catalog.py
  config.py
  github_client.py
frontend/
  src/
setup.bat
setup.ps1
start-dev.bat
start-dev.ps1
```

The frontend still consumes the same normalized catalog contract, so search, endpoint previews, operation navigation, nested request fields, theming, and the detailed API view do not depend on GitHub-specific response shapes.

## Versioned API names

Once an OpenAPI definition is loaded, the application extracts the first numeric segment from `info.version` and appends it as an uppercase major version, such as `Payments API V2`. If the title already contains `V2` or `Version 2`, it is not appended again.

## Token use and verification

When `GITHUB_ACCESS_TOKEN` is configured, the backend adds it to outbound GitHub API requests as an `Authorization: Bearer ...` header. The token is stored only in the root `.env`, which is ignored by Git, and is never returned to the browser. A token is required by this build so startup and refreshes always use authenticated access.

`start-dev.bat` verifies both the local Flask health endpoint and GitHub repository access before starting Vite. It reports whether access is token-authenticated or anonymous without revealing the token.

Run this at any time to re-check backend imports, GitHub access, retained UI features, TypeScript, and the Vite production build:

```bat
verify.bat
```

## Windows setup quoting fix

Setup and verification now call `backend/verify_installation.py` directly instead of passing Python programs through `python -c`. This prevents Windows PowerShell from stripping embedded quotes and also prevents the secondary null-value error when URL validation fails.

## Discovery diagnostics

There is no fixed API display limit. The scanner evaluates every configured JSON/YAML extension on the repository default branch and inside `GITHUB_SEARCH_ROOT`, when one is configured. Non-OpenAPI configuration files are rejected after content inspection.

Run:

```bat
discovery-report.bat
```

The report shows:

- Branch/ref scanned
- Total tree entries and blobs
- Every JSON/YAML candidate path
- Every validated OpenAPI specification path
- Rejected files and the reason each was not considered OpenAPI
- Candidate files excluded by `GITHUB_SEARCH_ROOT`
- Whether GitHub truncated the recursive tree response
- Whether recursive discovery or explicit subtree traversal was used

The same report is available from:

```text
GET /api/discovery?refresh=true
```

## Main catalog table refinements

The flat catalog now keeps its column headers visible while the catalog body scrolls. The description column was removed so the API title and major version have substantially more room and can wrap without truncation. Operations use a compact endpoint-count disclosure instead of a large button, and the expanded preview no longer includes a redundant **View API in detail** action; clicking the API row still opens the full detailed view.

## Catalog navigation refinements

The catalog column labels are rendered as a fixed grid row above a separately scrolling API list, eliminating the slight movement associated with CSS sticky positioning. Endpoint counts are left-aligned from a consistent column edge, with the disclosure chevrons aligned separately.

Catalog search is split into **Search APIs** and **Search endpoints**. API search filters metadata only. Endpoint search filters the API rows by operation method, path, summary, operation ID, and tags. Search results never expand operation lists automatically; users explicitly open one API at a time, and an active endpoint search shows only the matching operations inside that preview.

## Endpoint count alignment

Operation disclosures use separate count and label columns rather than inserted spaces. Counts are right-aligned with tabular numerals, while `endpoint`, `endpoints`, `match`, or `matches` begins at one consistent position.

## Clean dashboard catalog layout

The catalog home screen uses the existing theme tokens in a cleaner dashboard hierarchy: branded control rail, API and endpoint summary cards, separate API/endpoint searches, sort control, status pills, and the existing fixed-header API table. Repository-folder/workspace selection and its frontend filtering state have been removed.


## Keycloak SSO and EKS

Application-level Keycloak OIDC and Keycloak-group authorization are included in `backend/auth.py`. Production EKS templates are available in `deploy/eks/`, and Keycloak client guidance/template are in `deploy/keycloak/`.

Hosted configuration uses:

```env
AUTH_MODE=keycloak
PUBLIC_BASE_URL=https://api-catalog.internal.company.com
KEYCLOAK_ISSUER_URL=https://keycloak.company.com/realms/company
KEYCLOAK_CLIENT_ID=api-catalog
KEYCLOAK_REQUIRED_GROUPS=/api-catalog-users
```

Store `KEYCLOAK_CLIENT_SECRET`, `SESSION_SECRET`, and `GITHUB_ACCESS_TOKEN` as Kubernetes/external secrets.
