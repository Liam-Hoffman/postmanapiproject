# Deployment Assets

- [`eks/`](eks/) contains the Kubernetes manifests and EKS deployment guide.
- [`keycloak/`](keycloak/) contains the confidential-client template and Keycloak group-mapper guide.

The application performs OIDC authentication and Keycloak group authorization inside Flask. The EKS Ingress/ALB terminates TLS and forwards traffic only; it does not perform authentication.
