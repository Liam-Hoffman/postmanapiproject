import os

GITHUB_REPOSITORY_URL = os.environ.get("GITHUB_REPOSITORY_URL", "").strip()
# GITHUB_TOKEN remains a backwards-compatible alias for an existing .env.
GITHUB_ACCESS_TOKEN = (
    os.environ.get("GITHUB_ACCESS_TOKEN", "").strip()
    or os.environ.get("GITHUB_TOKEN", "").strip()
)
GITHUB_API_VERSION = os.environ.get("GITHUB_API_VERSION", "2022-11-28").strip()
GITHUB_SEARCH_ROOT = os.environ.get("GITHUB_SEARCH_ROOT", "").strip().strip("/")
GITHUB_SPEC_EXTENSIONS = {
    value if value.startswith(".") else f".{value}"
    for value in (
        item.strip().casefold()
        for item in os.environ.get(
            "GITHUB_SPEC_EXTENSIONS",
            ".json,.yml,.yaml",
        ).split(",")
    )
    if value
}
GITHUB_SCAN_WORKERS = min(
    max(int(os.environ.get("GITHUB_SCAN_WORKERS", "8")), 1),
    24,
)
GITHUB_REQUEST_TIMEOUT_SECONDS = max(
    int(os.environ.get("GITHUB_REQUEST_TIMEOUT_SECONDS", "30")),
    1,
)
GITHUB_MAX_RETRIES = min(
    max(int(os.environ.get("GITHUB_MAX_RETRIES", "3")), 0),
    8,
)
GITHUB_RETRY_BUFFER_SECONDS = max(
    float(os.environ.get("GITHUB_RETRY_BUFFER_SECONDS", "1")),
    0.0,
)



def _bool_env(name: str, default: bool = False) -> bool:
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().casefold() in {"1", "true", "yes", "on"}


def _csv_env(name: str) -> tuple[str, ...]:
    return tuple(
        item.strip()
        for item in os.environ.get(name, "").split(",")
        if item.strip()
    )


AUTH_MODE = os.environ.get("AUTH_MODE", "disabled").strip().casefold()
AUTH_ENABLED = AUTH_MODE == "keycloak"
PUBLIC_BASE_URL = os.environ.get("PUBLIC_BASE_URL", "").strip().rstrip("/")
SESSION_SECRET = os.environ.get("SESSION_SECRET", "").strip()
SESSION_COOKIE_NAME = os.environ.get(
    "SESSION_COOKIE_NAME",
    "api_catalog_session",
).strip()
SESSION_COOKIE_SECURE = _bool_env(
    "SESSION_COOKIE_SECURE",
    default=AUTH_ENABLED,
)
SESSION_LIFETIME_SECONDS = max(
    int(os.environ.get("SESSION_LIFETIME_SECONDS", "28800")),
    300,
)
TRUST_PROXY_HEADERS = _bool_env(
    "TRUST_PROXY_HEADERS",
    default=AUTH_ENABLED,
)

KEYCLOAK_ISSUER_URL = os.environ.get("KEYCLOAK_ISSUER_URL", "").strip().rstrip("/")
KEYCLOAK_CLIENT_ID = os.environ.get("KEYCLOAK_CLIENT_ID", "").strip()
KEYCLOAK_CLIENT_SECRET = os.environ.get("KEYCLOAK_CLIENT_SECRET", "").strip()
KEYCLOAK_GROUP_CLAIM = os.environ.get(
    "KEYCLOAK_GROUP_CLAIM",
    "groups",
).strip()
KEYCLOAK_REQUIRED_GROUPS = _csv_env("KEYCLOAK_REQUIRED_GROUPS")
KEYCLOAK_SCOPES = os.environ.get(
    "KEYCLOAK_SCOPES",
    "openid profile email",
).strip()
KEYCLOAK_PROMPT = os.environ.get("KEYCLOAK_PROMPT", "").strip()


def validate_auth_configuration() -> None:
    if AUTH_MODE not in {"disabled", "keycloak"}:
        raise ValueError("AUTH_MODE must be either 'disabled' or 'keycloak'.")
    if not AUTH_ENABLED:
        return

    missing: list[str] = []
    required_values = {
        "PUBLIC_BASE_URL": PUBLIC_BASE_URL,
        "SESSION_SECRET": SESSION_SECRET,
        "KEYCLOAK_ISSUER_URL": KEYCLOAK_ISSUER_URL,
        "KEYCLOAK_CLIENT_ID": KEYCLOAK_CLIENT_ID,
        "KEYCLOAK_CLIENT_SECRET": KEYCLOAK_CLIENT_SECRET,
        "KEYCLOAK_GROUP_CLAIM": KEYCLOAK_GROUP_CLAIM,
        "KEYCLOAK_REQUIRED_GROUPS": KEYCLOAK_REQUIRED_GROUPS,
    }
    for name, value in required_values.items():
        if not value:
            missing.append(name)

    if missing:
        raise ValueError(
            "Keycloak authentication is enabled but these settings are missing: "
            + ", ".join(missing)
        )
    if len(SESSION_SECRET) < 32 or SESSION_SECRET.startswith("replace-with"):
        raise ValueError(
            "SESSION_SECRET must be a generated value of at least 32 characters."
        )
    if KEYCLOAK_CLIENT_SECRET.startswith("replace-with"):
        raise ValueError("KEYCLOAK_CLIENT_SECRET must contain the real client secret.")
    if not PUBLIC_BASE_URL.startswith(("https://", "http://")):
        raise ValueError("PUBLIC_BASE_URL must be an absolute HTTP or HTTPS URL.")
    if not KEYCLOAK_ISSUER_URL.startswith(("https://", "http://")):
        raise ValueError("KEYCLOAK_ISSUER_URL must be an absolute HTTP or HTTPS URL.")
    if PUBLIC_BASE_URL.startswith("https://") and not SESSION_COOKIE_SECURE:
        raise ValueError(
            "SESSION_COOKIE_SECURE must be true when PUBLIC_BASE_URL uses HTTPS."
        )
    if "openid" not in KEYCLOAK_SCOPES.split():
        raise ValueError("KEYCLOAK_SCOPES must include the openid scope.")

HOST = os.environ.get("CATALOG_HOST", "127.0.0.1")
PORT = int(os.environ.get("CATALOG_PORT", "8080"))
CACHE_TTL_SECONDS = max(
    int(os.environ.get("CATALOG_CACHE_TTL_SECONDS", "900")),
    0,
)
