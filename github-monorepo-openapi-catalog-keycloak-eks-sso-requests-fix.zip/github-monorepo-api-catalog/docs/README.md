# API Catalog Documentation

This folder contains the end-user, developer, runtime, deployment, security, and operational documentation for the GitHub Monorepo API Catalog.

## Start here

| Audience | Recommended document |
|---|---|
| Catalog users | [User guide](user-guide.md) |
| API specification authors | [OpenAPI authoring guide](openapi-authoring-guide.md) |
| Developers running the app locally | [Local setup and development](local-development.md) |
| Application engineers | [Runtime architecture](runtime-architecture.md) |
| Platform and cloud engineers | [EKS deployment and Keycloak SSO](aws-deployment-sso.md) |
| Operations and support | [Operations runbook](operations-runbook.md) |
| Security reviewers | [Security model](security.md) |
| Troubleshooters | [Troubleshooting](troubleshooting.md) |

## Documentation map

1. [User guide](user-guide.md)
2. [OpenAPI authoring guide](openapi-authoring-guide.md)
3. [Local setup and development](local-development.md)
4. [Runtime architecture](runtime-architecture.md)
5. [Configuration reference](configuration-reference.md)
6. [GitHub integration](github-integration.md)
7. [Application-level Keycloak SSO](keycloak-sso.md)
8. [Backend API reference](api-reference.md)
9. [EKS deployment and company SSO](aws-deployment-sso.md)
10. [Security model](security.md)
11. [Operations runbook](operations-runbook.md)
12. [Troubleshooting](troubleshooting.md)
13. [Maintenance and releases](maintenance.md)

## Product summary

The catalog scans a configured GitHub or GitHub Enterprise repository for `.json`, `.yml`, and `.yaml` files. It parses each candidate and includes only valid OpenAPI 3.x or Swagger 2.0 documents.

The catalog provides:

- One top-level row per API specification
- API title with major version, such as `Payments API V2`
- Exact repository path beneath the title
- API metadata and ownership
- Separate API and endpoint searches
- Endpoint counts and expandable operation previews
- Detailed operation, request-field, schema, example, server, security, and raw-spec views
- Light and dark themes
- GitHub source links
- Discovery diagnostics and health endpoints

## Important current limitations

- External relative `$ref` files are not bundled or resolved. Local JSON Pointer references such as `#/components/schemas/Payment` are supported.
- The catalog cache is stored in application memory. It is not shared between Gunicorn workers, containers, or EKS pods.
- The hosted application implements Keycloak OIDC in Flask and grants access only to configured Keycloak groups. Local development can explicitly disable authentication.
- The scanner reads the repository default branch. A runtime branch selector is not currently provided.
- The application is read-only. It does not modify GitHub content.
