# Application-Level Keycloak SSO

## Security model

The API Catalog is protected in Flask rather than by ALB authentication:

```mermaid
sequenceDiagram
    participant U as Employee browser
    participant I as EKS Ingress/ALB
    participant A as API Catalog Flask app
    participant K as Keycloak

    U->>I: GET /
    I->>A: Forward request
    A-->>U: Redirect /auth/login
    U->>K: OIDC authorization request
    K->>U: Company sign-in / existing SSO session
    K-->>A: Authorization code at /auth/callback
    A->>K: Exchange code using confidential client secret
    K-->>A: ID/access token
    A->>K: UserInfo request
    K-->>A: Identity + groups claim
    A->>A: Require configured group
    A-->>U: Signed HTTP-only app session
    U->>A: Protected UI and API requests
```

Authlib uses Keycloak's OIDC discovery document at:

```text
<issuer>/.well-known/openid-configuration
```

The Authorization Code flow is handled entirely by Flask. The browser React application never receives Keycloak tokens.

## Protected resources

When `AUTH_MODE=keycloak`, every route is protected except:

```text
/api/health
/auth/login
/auth/callback
/auth/logout
/auth/logged-out
```

Unauthenticated browser routes redirect to login. Unauthenticated `/api/*` requests return HTTP 401; the frontend then redirects to `/auth/login`.

## Group authorization

The callback reads the configured claim:

```env
KEYCLOAK_GROUP_CLAIM=groups
```

It requires membership in any exact configured value:

```env
KEYCLOAK_REQUIRED_GROUPS=/api-catalog-users
```

Multiple groups:

```env
KEYCLOAK_REQUIRED_GROUPS=/api-catalog-users,/platform-engineering
```

Users who authenticate but are not in an allowed group receive an application access-denied page. No application session is issued.

## Session contents

The signed Flask cookie contains only:

- Keycloak subject identifier
- Username
- Display name
- Email
- Matched allowed group(s)
- Application session expiration

It does not contain:

- Access token
- Refresh token
- ID token
- Keycloak client secret
- GitHub token
- All Keycloak group memberships

The cookie is HTTP-only, `SameSite=Lax`, and Secure in EKS.

## Session revocation

Access is reevaluated at the next application login. If a user is removed from the Keycloak group, an existing application session remains valid until logout or `SESSION_LIFETIME_SECONDS` expires. The default is eight hours.

For immediate central revocation or Keycloak backchannel logout, move sessions to a shared server-side store and implement a logout-token endpoint in a future release.

## Logout

`/auth/logout` clears the application cookie and starts Keycloak RP-initiated logout using:

```text
client_id
post_logout_redirect_uri
```

Register this exact post-logout URI in Keycloak:

```text
https://<catalog-host>/auth/logged-out
```

## Local development

Authentication defaults to disabled. To test Keycloak with Vite:

```env
AUTH_MODE=keycloak
PUBLIC_BASE_URL=http://127.0.0.1:5173
SESSION_SECRET=<32+ character value>
SESSION_COOKIE_SECURE=false
TRUST_PROXY_HEADERS=false
KEYCLOAK_ISSUER_URL=https://keycloak.company.com/realms/company
KEYCLOAK_CLIENT_ID=api-catalog-local
KEYCLOAK_CLIENT_SECRET=<secret>
KEYCLOAK_REQUIRED_GROUPS=/api-catalog-users
```

Register this callback:

```text
http://127.0.0.1:5173/auth/callback
```

Vite proxies both `/api` and `/auth` to Flask.

## Official references

- [Keycloak OpenID Connect endpoints](https://www.keycloak.org/securing-apps/oidc-layers)
- [Keycloak client and protocol-mapper administration](https://www.keycloak.org/docs/latest/server_admin/index.html)
- [Authlib Flask OAuth and OpenID Connect client](https://docs.authlib.org/en/latest/oauth2/client/web/flask.html)

## Python OIDC HTTP dependency

The Keycloak integration uses Authlib's Flask client, which performs OIDC discovery, authorization-code exchange, and UserInfo requests through the Python `requests` HTTP stack. Both dependencies must be installed:

```text
Authlib>=1.7,<2
requests>=2.32,<3
```

`setup.bat` installs both from `backend/requirements.txt` and verifies them before importing the Flask application.
