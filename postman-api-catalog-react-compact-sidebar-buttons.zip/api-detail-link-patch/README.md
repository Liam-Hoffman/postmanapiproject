# Postman API Catalog — React + Python

An internal API catalog with a React/TypeScript/Vite frontend and a Python/Flask backend. The backend keeps the Postman API key private, filters employee workspaces, applies rate limiting, caches catalog data, and lazily loads full API definitions.

## Local development

### Requirements

- Node.js 22+ with NPM
- Python 3.11+
- A Postman API key

### Quick first-time setup

The setup scripts validate Node.js and Python, create `.env`, securely prompt for your Postman API key, create `.venv`, and install all backend and frontend dependencies.

**Windows:** double-click `setup.bat`, or run:

```powershell
.\setup.ps1
```

**macOS/Linux:**

```bash
./setup.sh
```

Add `--start` to launch both development servers immediately after setup. Existing `.env` files are preserved.

### Manual setup

1. Copy `.env.example` to `.env` and set `POSTMAN_API_KEY`.
2. Install backend dependencies:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r backend/requirements.txt
```

3. Install frontend dependencies:

```bash
cd frontend
npm install
```

4. Run both development servers from the repository root:

```bash
npm run dev
```

Or run them separately. Run the backend from the repository root:

```bash
python backend/run.py
```

5. In another terminal, run the frontend:

```bash
cd frontend
npm run dev
```

Open `http://localhost:5173`. Vite proxies `/api` requests to `http://127.0.0.1:8080`.

Windows users can also run `./start-dev.ps1`. macOS/Linux users can run `./start-dev.sh`.

## Production-style local test

Build the React application and let Flask serve it:

```bash
cd frontend
npm run build
cd ..
python backend/run.py
```

Open `http://localhost:8080`.

## Docker test

```bash
docker compose up --build
```

Open `http://localhost:8080`.

## AWS-ready deployment path

The included multi-stage Dockerfile builds the React frontend and runs Flask behind Gunicorn. The image can be pushed to Amazon ECR and deployed to ECS Fargate behind an Application Load Balancer. In AWS, inject the Postman key from Secrets Manager rather than committing `.env`.

Ordinary web-app users do not need access to the AWS account. Authentication can later be added at the Application Load Balancer using your company OIDC provider, or through Cognito for SAML federation. Local development remains independent of SSO.

## Project layout

```text
backend/             Flask API and Postman integration
frontend/            React + TypeScript + Vite application
Dockerfile           Production container build
docker-compose.yml   Local production-style container test
.env.example         Local configuration template
```

## Frontend behavior retained

- Stripe-inspired left sidebar
- Main API search
- Search-aware workspace dropdown
- Workspace, lifecycle, and sorting controls
- Stable API cards
- Lazy detail loading
- Detail search
- Overview and specification tabs
- Request fields and generated request examples
- No request-body warning for GET, HEAD, OPTIONS, or TRACE
- Dark theme


## Operation and field navigation

- Operations are grouped in a fixed HTTP-method order and each method group can be collapsed.
- Required request fields use a red left accent, red asterisk, and explicit Required badge.
- Object and array-object request fields can be expanded to reveal nested properties.
- Searching inside an API automatically reveals nested matching field content.

## Documentation explorer redesign

The React frontend now uses React Router and a denser documentation-oriented layout:

- Only workspaces whose names start with `[CSAA]` are included in the catalog.
- The main sidebar and catalog header remain sticky while API rows scroll.
- APIs are grouped into collapsible workspace sections instead of large cards.
- Each API has a route such as `/catalog/payment-api-<id>`, so browser history, bookmarks, and shared links work.
- API pages use a split pane with a sticky operation navigation tree and reference content.
- Operations remain consistently grouped and collapsible by HTTP method.
- Individual operations have URL fragments that can be copied and shared.
- Nested object fields remain expandable, and required fields retain red emphasis.

During local development, Vite handles route fallback automatically. In production, the Flask fallback route returns `index.html` for application routes, so direct links work in Docker and ECS as well.

## Navigation cleanup

- Removed the lifecycle dropdown from the main catalog sidebar.
- The catalog sidebar now focuses on API search, `[CSAA]` workspace filtering, sorting, scope, and counts.
- The global catalog sidebar is hidden on individual API routes so it does not compete with the API-specific operation search.
- API routes use the operation navigator as their only left-side navigation.
- Sticky main headers now use a safe viewport offset, full border, and rounded corners to prevent clipping at the top of the page.


## Reduced field hover noise

API request-field rows no longer highlight on mouse hover. Visual hover feedback is limited to explicitly interactive object-expansion controls, while required-field emphasis remains unchanged.


## Detail-page sticky header fix

The detailed API view now reserves space below its sticky top header. Operation sections and URL-fragment targets use matching scroll offsets, so headings and content remain visible rather than scrolling underneath the header.


## Enhanced API detail navigation

The detailed API view now includes a prominent Back to Catalog button, breadcrumb context, and a compact API summary above the operation navigation. The summary and operation tree stay visible together on desktop while the main specification content scrolls independently.


## Shared UI design system

The frontend now uses a centralized set of design tokens and reusable UI primitives for surfaces, buttons, inputs, badges, and section headers. Existing catalog and API-detail components inherit the same colors, spacing, borders, focus states, and dark-theme behavior. New components can import from `frontend/src/components/ui`.

## Final theme corrections

Catalog and API-detail surfaces now use the application's actual `--panel`, `--text`, `--muted`, and `--border` tokens. The catalog/detail headers are restored to `position: sticky; top: 0`, and dark-mode form controls explicitly use the dark color scheme.


## Background API detail loading and endpoint previews

After the lightweight catalog metadata loads, the frontend now hydrates API definitions in the background with a four-request concurrency limit. Each API row includes an **Endpoints** control that expands an inline preview of operation methods, paths, and summaries without leaving the catalog. Opening a preview immediately requests that API if its background load has not completed yet.


## Endpoint-aware catalog search

The main catalog search includes prefetched operation metadata, so users can search by API name, workspace, HTTP method, endpoint path, operation summary, description, operation ID, and tags.

## Search match explanations and faceted filters

The catalog search now explains endpoint-level matches directly beneath each matching API. It shows up to three matching operations, highlights the matching text, and links each result directly to the corresponding operation in the detailed API view.

The sidebar also includes faceted filters for:

- HTTP method
- Lifecycle
- Business domain
- Owning team
- Authentication scheme
- Tags

Each facet includes API counts, active filters appear as removable chips, and the available values update as API definitions finish loading in the background. Business domain can be provided through `info.x-domain`, `info.x-business-domain`, or `info.x-api-domain`; otherwise the `[CSAA]` workspace name is used as a fallback.

## JSON and YAML OpenAPI support

Specification definitions can be supplied as JSON or YAML. The backend automatically detects the source format, parses it into the same normalized catalog model, and preserves the original source text for the specification viewer. YAML parsing uses `PyYAML`'s safe loader with timestamp coercion disabled so unquoted OpenAPI date examples remain JSON-serializable strings.

The existing setup scripts install the required YAML dependency from `backend/requirements.txt`.

## Windows first-time setup

Double-click `setup.bat`, or run it from Command Prompt:

```bat
setup.bat
```

The setup now validates Node.js and Python, creates `.env`, configures the Postman API key, creates `.venv`, installs backend and frontend dependencies, verifies Flask and YAML imports, imports the backend application, and runs a production frontend build. It stops immediately when any command fails.

Optional arguments are passed to `setup.ps1`:

```bat
setup.bat -SkipInstall
setup.bat -SkipBuild
setup.bat -Start
```

After setup, double-click `start-dev.bat` to start the backend and frontend.


## TypeScript build corrections

The frontend includes Vite's client type reference so CSS side-effect imports are recognized by TypeScript. API operation groups use the supported HTML `open` property instead of the invalid React `defaultOpen` property.

## Synchronized local proxy

Vite now reads `CATALOG_HOST` and `CATALOG_PORT` from the same root `.env` file as Flask. The duplicate `frontend/vite.config.js` file was removed to prevent an old generated config from overriding `vite.config.ts`.

`start-dev.bat` waits for `/api/health` before starting Vite. If the backend cannot start, setup reports the backend error instead of leaving Vite running with repeated `ECONNREFUSED` proxy messages.

After replacing an older project copy, close every existing Vite/Node terminal before starting the new build so an old dev server does not continue using a cached port.

## Simplified discovery interface

The catalog sidebar now contains only search, workspace selection, sorting, scope information, and summary statistics. Faceted-filter controls were removed.

The catalog table no longer displays an operation-count column. Each API has a **View operations** dropdown that lists methods, endpoint paths, and summaries without leaving the catalog. The full detailed API view remains available from the API row and from the preview footer.

The detailed API header uses a more compact two-line layout, and the left API-summary card now has consistent space above and inside it.


## Compact sidebar actions

The Refresh and Theme controls use compact utility-button sizing instead of full-width primary action styling. The refresh label is shortened to `Refresh`, and the loading state displays `Refreshing…`.
